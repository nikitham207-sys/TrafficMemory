export type Severity = 'Normal' | 'Moderate' | 'Severe' | 'Critical';
export type Weather = 'Rain' | 'Clear' | 'Fog' | 'Overcast' | 'Heavy Rain';
export type IncidentType = 'Accident' | 'Waterlogging' | 'Signal Failure' | 'Construction' | 'Peak Congestion' | 'VIP Movement';
export type InterventionType = 'Signal retiming' | 'Traffic diversion' | 'Manual traffic control' | 'Corridor metering';
export type OutcomeStatus = 'Successful' | 'Partially successful' | 'Failed';

export interface TrafficMemoryItem {
  id: string;
  location: string;
  zone: string;
  coordinates: [number, number]; // [lng, lat]
  timestamp: string;
  day: string;
  time: string;
  weather: Weather;
  incident: IncidentType;
  severity: Severity;
  intervention: InterventionType;
  outcome: OutcomeStatus;
  success: boolean;
  delayBeforeMin: number;
  delayAfterMin: number;
  context: string;
  source: string;
}

export interface ZoneInfo {
  id: string;
  name: string;
  code: string;
  center: [number, number];
  description: string;
  activeIncidentsCount: number;
  corridors: string[];
}

export interface HospitalInfo {
  id: string;
  name: string;
  zone: string;
  coordinates: [number, number];
  traumaLevel: string;
  icuBedsAvailable: number;
  emergencyContact: string;
}

export interface IncidentMarker {
  id: string;
  location: string;
  zone: string;
  coordinates: [number, number];
  day: string;
  time: string;
  weather: Weather;
  incident: IncidentType;
  severity: Severity;
  similarMemoriesCount: number;
  bestIntervention: InterventionType;
  bestInterventionSuccessRatio: string;
  description: string;
}

export interface TrafficCorridor {
  id: string;
  name: string;
  zone: string;
  status: 'Smooth' | 'Moderate' | 'Heavy' | 'Severe';
  coordinates: [number, number][]; // LineString
  currentSpeedKmh: number;
  baselineSpeedKmh: number;
}

export interface AnalyzeRequest {
  location: string;
  zone?: string;
  day: string;
  time: string;
  weather: Weather;
  incident: IncidentType;
  severity: Severity;
}

export interface InterventionOutcomeStat {
  intervention: InterventionType;
  totalAttempts: number;
  successCount: number;
  partialCount: number;
  failCount: number;
  successRate: number; // 0-100
  avgDelayReductionMin: number;
}

export interface AnalyzeResponse {
  eventReceived: {
    location: string;
    day: string;
    time: string;
    weather: Weather;
    incident: IncidentType;
    severity: Severity;
  };
  hindsightRecall: {
    totalRecalled: number;
    memoryMode: 'HINDSIGHT_LIVE' | 'DEMO_MOCK';
    recalledMemories: TrafficMemoryItem[];
    similarityBasis: string;
  };
  historicalEvidence: {
    statsByIntervention: InterventionOutcomeStat[];
    avgHistoricalDelay: number;
    recommendedIntervention: InterventionType;
    confidenceScore: number;
  };
  recommendation: {
    primaryAction: InterventionType;
    successRateDisplay: string;
    explanation: string;
    reasoningBullets: string[];
    fallbackAction?: InterventionType;
  };
  comparison: {
    withoutMemory: {
      action: string;
      rationale: string;
      risk: string;
    };
    withTrafficMemory: {
      action: string;
      rationale: string;
      historicalProof: string;
    };
  };
  agentSteps: {
    step: string;
    detail: string;
    timestamp: string;
    status: 'completed' | 'active' | 'pending';
  }[];
}

export interface EmergencyRouteOption {
  routeId: string;
  name: string;
  via: string[];
  coordinates: [number, number][];
  isRecommended: boolean;
  distanceKm: number;
  estimatedTimeMin: number;
  historicalTrips: number;
  avgHistoricalTimeMin: number;
  historicalSuccessRate: number; // 0-100
  successfulFasterTrips: number;
  riskBottlenecks: string[];
  whyRecommended: string;
}

export interface EmergencyAnalysisResponse {
  origin: string;
  destination: string;
  urgency: 'Standard' | 'Urgent' | 'Critical';
  weather: Weather;
  hospital: HospitalInfo;
  routes: EmergencyRouteOption[];
  hindsightSummary: {
    totalPastEmergencyTrips: number;
    recommendedRouteId: string;
    reason: string;
    memoryMode: 'HINDSIGHT_LIVE' | 'DEMO_MOCK';
  };
  agentSteps: {
    step: string;
    detail: string;
    timestamp: string;
  }[];
}

export interface RecordOutcomeRequest {
  memoryId?: string;
  location: string;
  zone: string;
  day: string;
  time: string;
  weather: Weather;
  incident: IncidentType;
  severity: Severity;
  intervention: InterventionType;
  outcome: OutcomeStatus;
  delayBeforeMin: number;
  delayAfterMin: number;
  notes?: string;
}

export interface SystemStats {
  totalMemories: number;
  successfulInterventionsCount: number;
  failedInterventionsCount: number;
  interventionsSuccessRate: number;
  emergencyTripsRecorded: number;
  activeIncidentsCount: number;
  memoryRetainCount: number;
  memoryRecallCount: number;
  memoryMode: 'HINDSIGHT_LIVE' | 'DEMO_MOCK';
  hindsightConnected: boolean;
}
