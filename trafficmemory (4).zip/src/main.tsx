import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
// Gracefully intercept benign cross-origin script errors
if (typeof window !== 'undefined') {
  window.addEventListener('error', (event) => {
    if (event.message === 'Script error.' || (typeof event.message === 'string' && event.message.includes('Script error'))) {
      event.preventDefault();
      console.warn('Suppressed external cross-origin script error:', event);
    }
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
