import { TrafficMemoryItem, ZoneInfo, HospitalInfo, IncidentMarker, TrafficCorridor, EmergencyRouteOption } from '../types/traffic.ts';

// Hyderabad Geographic Center: [78.4772, 17.4065] (lng, lat)
export const HYDERABAD_ZONES: ZoneInfo[] = [
  {
    id: 'secunderabad',
    name: 'Secunderabad',
    code: 'SEC',
    center: [78.5015, 17.4399],
    description: 'Railway hub & arterial transit nexus connecting Paradise & Marredpally',
    activeIncidentsCount: 1,
    corridors: ['MG Road', 'SP Road', 'Rani Gunj', 'Paradise Flyover']
  },
  {
    id: 'begumpet',
    name: 'Begumpet',
    code: 'BGP',
    center: [78.4682, 17.4448],
    description: 'Central transport corridor linking airport express & Rashtrapati Road',
    activeIncidentsCount: 1,
    corridors: ['Begumpet Main Road', 'Prakash Nagar Flyover', 'Shoppers Stop Junction']
  },
  {
    id: 'ameerpet',
    name: 'Ameerpet',
    code: 'AMP',
    center: [78.4482, 17.4375],
    description: 'High-density commercial interchange connecting SR Nagar and Panjagutta',
    activeIncidentsCount: 2,
    corridors: ['Ameerpet Cross Roads', 'Maitrivanam Nexus', 'SR Nagar Main Road']
  },
  {
    id: 'banjara_jubilee',
    name: 'Banjara Hills / Jubilee Hills',
    code: 'BJH',
    center: [78.4328, 17.4243],
    description: 'Major medical center corridor & prime residential commercial arterial',
    activeIncidentsCount: 1,
    corridors: ['Road No. 1 Banjara Hills', 'Road No. 36 Jubilee Hills', 'Check Post Junction']
  },
  {
    id: 'hitec_gachibowli',
    name: 'HITEC City / Gachibowli',
    code: 'HTC',
    center: [78.3685, 17.4474],
    description: 'IT corridor & Financial District express bypass network',
    activeIncidentsCount: 2,
    corridors: ['Cyber Towers Junction', 'Biodiversity Park Flyover', 'Gachibowli ORR Nexus']
  }
];

export const HYDERABAD_HOSPITALS: HospitalInfo[] = [
  {
    id: 'hosp-apollo',
    name: 'Apollo Hospitals Jubilee Hills',
    zone: 'Banjara Hills / Jubilee Hills',
    coordinates: [78.4124, 17.4278],
    traumaLevel: 'Level 1 Trauma & Cardiac Emergency',
    icuBedsAvailable: 14,
    emergencyContact: '+91 40 2360 7777'
  },
  {
    id: 'hosp-care-banjara',
    name: 'CARE Hospitals Banjara Hills',
    zone: 'Banjara Hills / Jubilee Hills',
    coordinates: [78.4412, 17.4168],
    traumaLevel: 'Level 1 Emergency & Multispecialty',
    icuBedsAvailable: 9,
    emergencyContact: '+91 40 3041 8000'
  },
  {
    id: 'hosp-yashoda-sec',
    name: 'Yashoda Hospitals Secunderabad',
    zone: 'Secunderabad',
    coordinates: [78.4984, 17.4412],
    traumaLevel: 'Level 1 Comprehensive Trauma',
    icuBedsAvailable: 12,
    emergencyContact: '+91 40 4567 4567'
  },
  {
    id: 'hosp-kims',
    name: 'KIMS Hospitals Secunderabad / Begumpet',
    zone: 'Begumpet',
    coordinates: [78.4842, 17.4385],
    traumaLevel: 'Level 1 Cardiac & Trauma Center',
    icuBedsAvailable: 18,
    emergencyContact: '+91 40 4488 5000'
  },
  {
    id: 'hosp-yashoda-somajiguda',
    name: 'Yashoda Hospitals Somajiguda',
    zone: 'Ameerpet',
    coordinates: [78.4578, 17.4241],
    traumaLevel: 'Level 1 Critical Care Center',
    icuBedsAvailable: 11,
    emergencyContact: '+91 40 2331 9999'
  },
  {
    id: 'hosp-aig-gachibowli',
    name: 'AIG Hospitals Gachibowli',
    zone: 'HITEC City / Gachibowli',
    coordinates: [78.3615, 17.4418],
    traumaLevel: 'Level 1 Multi-Organ Emergency',
    icuBedsAvailable: 22,
    emergencyContact: '+91 40 4244 4222'
  },
  {
    id: 'hosp-care-hitec',
    name: 'CARE Hospitals HITEC City',
    zone: 'HITEC City / Gachibowli',
    coordinates: [78.3752, 17.4529],
    traumaLevel: 'Level 2 Trauma Care',
    icuBedsAvailable: 8,
    emergencyContact: '+91 40 6165 6565'
  }
];

export const INITIAL_INCIDENTS: IncidentMarker[] = [
  {
    id: 'inc-01',
    location: 'Ameerpet Cross Roads',
    zone: 'Ameerpet',
    coordinates: [78.4482, 17.4375],
    day: 'Friday',
    time: '6:30 PM',
    weather: 'Rain',
    incident: 'Accident',
    severity: 'Severe',
    similarMemoriesCount: 6,
    bestIntervention: 'Signal retiming',
    bestInterventionSuccessRatio: '4 / 6 successful (67%)',
    description: 'Collision between two buses at Maitrivanam turn, blocking inbound Begumpet slip road.'
  },
  {
    id: 'inc-02',
    location: 'Gachibowli ORR Junction',
    zone: 'HITEC City / Gachibowli',
    coordinates: [78.3635, 17.4402],
    day: 'Monday',
    time: '8:45 AM',
    weather: 'Fog',
    incident: 'Peak Congestion',
    severity: 'Severe',
    similarMemoriesCount: 8,
    bestIntervention: 'Traffic diversion',
    bestInterventionSuccessRatio: '6 / 8 successful (75%)',
    description: 'Heavy bumper-to-bumper queue extending towards Financial District under dense fog.'
  },
  {
    id: 'inc-03',
    location: 'Paradise Flyover Incline',
    zone: 'Secunderabad',
    coordinates: [78.4895, 17.4429],
    day: 'Friday',
    time: '7:15 PM',
    weather: 'Rain',
    incident: 'Waterlogging',
    severity: 'Moderate',
    similarMemoriesCount: 5,
    bestIntervention: 'Manual traffic control',
    bestInterventionSuccessRatio: '4 / 5 successful (80%)',
    description: 'Low-lying water accumulation on northbound ramp slowing vehicle clearance.'
  },
  {
    id: 'inc-04',
    location: 'Cyber Towers Junction',
    zone: 'HITEC City / Gachibowli',
    coordinates: [78.3792, 17.4508],
    day: 'Wednesday',
    time: '6:15 PM',
    weather: 'Clear',
    incident: 'Signal Failure',
    severity: 'Critical',
    similarMemoriesCount: 7,
    bestIntervention: 'Manual traffic control',
    bestInterventionSuccessRatio: '5 / 7 successful (71%)',
    description: 'Primary controller power surge caused 3-phase flashing yellows during evening shift exit.'
  },
  {
    id: 'inc-05',
    location: 'Road No. 36 Jubilee Hills',
    zone: 'Banjara Hills / Jubilee Hills',
    coordinates: [78.4239, 17.4328],
    day: 'Saturday',
    time: '9:00 PM',
    weather: 'Clear',
    incident: 'Construction',
    severity: 'Moderate',
    similarMemoriesCount: 4,
    bestIntervention: 'Traffic diversion',
    bestInterventionSuccessRatio: '3 / 4 successful (75%)',
    description: 'Metro pillar reinforcement occupying left carriage lane.'
  }
];

export const INITIAL_CORRIDORS: TrafficCorridor[] = [
  {
    id: 'corr-01',
    name: 'Secunderabad - Begumpet - Ameerpet Arterial',
    zone: 'Ameerpet',
    status: 'Severe',
    coordinates: [
      [78.5015, 17.4399],
      [78.4895, 17.4429],
      [78.4682, 17.4448],
      [78.4550, 17.4390],
      [78.4482, 17.4375]
    ],
    currentSpeedKmh: 11,
    baselineSpeedKmh: 38
  },
  {
    id: 'corr-02',
    name: 'Ameerpet - Panjagutta - Banjara Hills Corridor',
    zone: 'Banjara Hills / Jubilee Hills',
    status: 'Moderate',
    coordinates: [
      [78.4482, 17.4375],
      [78.4520, 17.4290],
      [78.4412, 17.4168],
      [78.4328, 17.4243]
    ],
    currentSpeedKmh: 24,
    baselineSpeedKmh: 42
  },
  {
    id: 'corr-03',
    name: 'Jubilee Hills - Madhapur - Cyber Towers',
    zone: 'HITEC City / Gachibowli',
    status: 'Moderate',
    coordinates: [
      [78.4239, 17.4328],
      [78.4010, 17.4410],
      [78.3792, 17.4508]
    ],
    currentSpeedKmh: 26,
    baselineSpeedKmh: 45
  },
  {
    id: 'corr-04',
    name: 'Gachibowli - HITEC City Financial Bypass',
    zone: 'HITEC City / Gachibowli',
    status: 'Heavy',
    coordinates: [
      [78.3635, 17.4402],
      [78.3685, 17.4474],
      [78.3792, 17.4508]
    ],
    currentSpeedKmh: 16,
    baselineSpeedKmh: 50
  },
  {
    id: 'corr-05',
    name: 'Begumpet - Somajiguda - Raj Bhavan Road',
    zone: 'Begumpet',
    status: 'Smooth',
    coordinates: [
      [78.4682, 17.4448],
      [78.4578, 17.4241],
      [78.4620, 17.4180]
    ],
    currentSpeedKmh: 36,
    baselineSpeedKmh: 40
  }
];

// Pre-calculated emergency routes between Secunderabad / Ameerpet and Apollo Jubilee Hills
export const DEMO_EMERGENCY_ROUTES: Record<string, EmergencyRouteOption[]> = {
  'secunderabad-apollo': [
    {
      routeId: 'route-a',
      name: 'Route A — Standard Arterial (via Begumpet & Panjagutta)',
      via: ['Paradise Flyover', 'Begumpet Main Road', 'Panjagutta Junction', 'Road No. 2 Banjara Hills'],
      coordinates: [
        [78.5015, 17.4399],
        [78.4895, 17.4429],
        [78.4682, 17.4448],
        [78.4520, 17.4290],
        [78.4328, 17.4243],
        [78.4124, 17.4278]
      ],
      isRecommended: false,
      distanceKm: 13.8,
      estimatedTimeMin: 22,
      historicalTrips: 9,
      avgHistoricalTimeMin: 22.4,
      historicalSuccessRate: 44,
      successfulFasterTrips: 4,
      riskBottlenecks: ['Panjagutta Flyover bottle-neck during Friday peak', 'Severe signal delay at Begumpet'],
      whyRecommended: 'Shortest nominal distance but high Friday variance.'
    },
    {
      routeId: 'route-b',
      name: 'Route B — Recommended Hindsight Path (via Minister Road & Jubilee Hills Link)',
      via: ['Minister Road', 'Ranigunj Outer Slip', 'Banjara Hills Inner Road 10', 'Apollo Emergency Gate'],
      coordinates: [
        [78.5015, 17.4399],
        [78.4830, 17.4320],
        [78.4650, 17.4230],
        [78.4420, 17.4200],
        [78.4239, 17.4260],
        [78.4124, 17.4278]
      ],
      isRecommended: true,
      distanceKm: 14.6,
      estimatedTimeMin: 14,
      historicalTrips: 8,
      avgHistoricalTimeMin: 14.2,
      historicalSuccessRate: 87.5,
      successfulFasterTrips: 7,
      riskBottlenecks: ['Single sharp turn at Minister Road underpass'],
      whyRecommended: 'Route B has historically performed 8.2 minutes faster under Friday evening rain conditions across 8 recorded trips with 87.5% critical arrival rate.'
    }
  ],
  'ameerpet-care': [
    {
      routeId: 'route-care-a',
      name: 'Route 1 — Direct via Nagarjuna Circle',
      via: ['Maitrivanam', 'Nagarjuna Circle', 'Road No. 1'],
      coordinates: [
        [78.4482, 17.4375],
        [78.4500, 17.4280],
        [78.4412, 17.4168]
      ],
      isRecommended: false,
      distanceKm: 4.8,
      estimatedTimeMin: 18,
      historicalTrips: 6,
      avgHistoricalTimeMin: 19.1,
      historicalSuccessRate: 50,
      successfulFasterTrips: 3,
      riskBottlenecks: ['Heavy left-turn gridlock at Panjagutta intersection'],
      whyRecommended: 'Direct line but frequently congested during wet conditions.'
    },
    {
      routeId: 'route-care-b',
      name: 'Route 2 — Green Corridored Slip Road (Recommended)',
      via: ['SR Nagar Back Bypass', 'Banjara Link Flyover', 'Emergency Bay'],
      coordinates: [
        [78.4482, 17.4375],
        [78.4420, 17.4300],
        [78.4380, 17.4210],
        [78.4412, 17.4168]
      ],
      isRecommended: true,
      distanceKm: 5.4,
      estimatedTimeMin: 9,
      historicalTrips: 7,
      avgHistoricalTimeMin: 9.6,
      historicalSuccessRate: 85.7,
      successfulFasterTrips: 6,
      riskBottlenecks: ['Narrow residential feeder for 200 meters'],
      whyRecommended: 'Bypasses major junction signals with dedicated emergency corridor retiming.'
    }
  ]
};

// 68 Seed Historical Traffic Memories across Hyderabad's 5 major operational zones
export const SEED_HISTORICAL_MEMORIES: TrafficMemoryItem[] = [
  // 1. Ameerpet Cluster (Friday Rain Accident Focus)
  {
    id: 'mem-amp-01',
    location: 'Ameerpet Cross Roads',
    zone: 'Ameerpet',
    coordinates: [78.4482, 17.4375],
    timestamp: '2026-08-14T18:35:00Z',
    day: 'Friday',
    time: '6:30 PM',
    weather: 'Rain',
    incident: 'Accident',
    severity: 'Severe',
    intervention: 'Signal retiming',
    outcome: 'Successful',
    success: true,
    delayBeforeMin: 22,
    delayAfterMin: 11,
    context: 'Evening peak rain accident near Maitrivanam. Signal retiming extended green phase on outbound corridor by 45s, draining queue.',
    source: 'Hindsight Retained'
  },
  {
    id: 'mem-amp-02',
    location: 'Ameerpet Cross Roads',
    zone: 'Ameerpet',
    coordinates: [78.4482, 17.4375],
    timestamp: '2026-07-24T18:42:00Z',
    day: 'Friday',
    time: '6:45 PM',
    weather: 'Rain',
    incident: 'Accident',
    severity: 'Severe',
    intervention: 'Signal retiming',
    outcome: 'Successful',
    success: true,
    delayBeforeMin: 20,
    delayAfterMin: 9,
    context: 'Bus breakdown causing 2-lane choke. Dynamically lengthened north-south clearance interval, resolving backup in 18 minutes.',
    source: 'Hindsight Retained'
  },
  {
    id: 'mem-amp-03',
    location: 'Ameerpet Cross Roads',
    zone: 'Ameerpet',
    coordinates: [78.4482, 17.4375],
    timestamp: '2026-06-19T18:25:00Z',
    day: 'Friday',
    time: '6:20 PM',
    weather: 'Rain',
    incident: 'Accident',
    severity: 'Severe',
    intervention: 'Signal retiming',
    outcome: 'Successful',
    success: true,
    delayBeforeMin: 19,
    delayAfterMin: 10,
    context: 'Multi-vehicle collision during thunderstorm. Phased green corridor clearing prevented spillback into SR Nagar.',
    source: 'Hindsight Retained'
  },
  {
    id: 'mem-amp-04',
    location: 'Ameerpet Cross Roads',
    zone: 'Ameerpet',
    coordinates: [78.4482, 17.4375],
    timestamp: '2026-05-29T18:50:00Z',
    day: 'Friday',
    time: '6:50 PM',
    weather: 'Rain',
    incident: 'Accident',
    severity: 'Severe',
    intervention: 'Signal retiming',
    outcome: 'Successful',
    success: true,
    delayBeforeMin: 24,
    delayAfterMin: 12,
    context: 'Heavy downpour plus rear-end incident. Retiming combined with cycle time adjustment halved passenger delays.',
    source: 'Hindsight Retained'
  },
  {
    id: 'mem-amp-05',
    location: 'Ameerpet Cross Roads',
    zone: 'Ameerpet',
    coordinates: [78.4482, 17.4375],
    timestamp: '2026-04-17T18:30:00Z',
    day: 'Friday',
    time: '6:30 PM',
    weather: 'Rain',
    incident: 'Accident',
    severity: 'Severe',
    intervention: 'Traffic diversion',
    outcome: 'Failed',
    success: false,
    delayBeforeMin: 21,
    delayAfterMin: 28,
    context: 'Diverted traffic through Balkampet internal lanes; narrow feeder streets immediately locked down with localized floodwater.',
    source: 'Hindsight Retained'
  },
  {
    id: 'mem-amp-06',
    location: 'Ameerpet Cross Roads',
    zone: 'Ameerpet',
    coordinates: [78.4482, 17.4375],
    timestamp: '2026-03-13T18:15:00Z',
    day: 'Friday',
    time: '6:15 PM',
    weather: 'Rain',
    incident: 'Accident',
    severity: 'Severe',
    intervention: 'Traffic diversion',
    outcome: 'Failed',
    success: false,
    delayBeforeMin: 18,
    delayAfterMin: 26,
    context: 'Attempted side-street rerouting towards Yellareddyguda; blocked residential ingress and failed to relieve main carriageway.',
    source: 'Hindsight Retained'
  },

  // 2. Gachibowli / HITEC City Cluster (Foggy Monday Congestion Focus)
  {
    id: 'mem-gac-01',
    location: 'Gachibowli ORR Junction',
    zone: 'HITEC City / Gachibowli',
    coordinates: [78.3635, 17.4402],
    timestamp: '2026-08-10T08:40:00Z',
    day: 'Monday',
    time: '8:45 AM',
    weather: 'Fog',
    incident: 'Peak Congestion',
    severity: 'Severe',
    intervention: 'Signal retiming',
    outcome: 'Failed',
    success: false,
    delayBeforeMin: 32,
    delayAfterMin: 36,
    context: 'Dense fog reduced visibility to 40m. Retiming signal failed because downstream slip road to Financial District was saturated.',
    source: 'Hindsight Retained'
  },
  {
    id: 'mem-gac-02',
    location: 'Gachibowli ORR Junction',
    zone: 'HITEC City / Gachibowli',
    coordinates: [78.3635, 17.4402],
    timestamp: '2026-07-13T08:50:00Z',
    day: 'Monday',
    time: '8:50 AM',
    weather: 'Fog',
    incident: 'Peak Congestion',
    severity: 'Severe',
    intervention: 'Signal retiming',
    outcome: 'Failed',
    success: false,
    delayBeforeMin: 30,
    delayAfterMin: 34,
    context: 'Retiming could not clear the junction because vehicles hesitated on entry due to heavy fog and interchange bottleneck.',
    source: 'Hindsight Retained'
  },
  {
    id: 'mem-gac-03',
    location: 'Gachibowli ORR Junction',
    zone: 'HITEC City / Gachibowli',
    coordinates: [78.3635, 17.4402],
    timestamp: '2026-06-08T08:35:00Z',
    day: 'Monday',
    time: '8:35 AM',
    weather: 'Fog',
    incident: 'Peak Congestion',
    severity: 'Severe',
    intervention: 'Traffic diversion',
    outcome: 'Successful',
    success: true,
    delayBeforeMin: 34,
    delayAfterMin: 14,
    context: 'Diverted 40% of inbound IT commuter traffic via Nanakramguda secondary rotary, clearing junction rapidly.',
    source: 'Hindsight Retained'
  },
  {
    id: 'mem-gac-04',
    location: 'Gachibowli ORR Junction',
    zone: 'HITEC City / Gachibowli',
    coordinates: [78.3635, 17.4402],
    timestamp: '2026-05-11T08:45:00Z',
    day: 'Monday',
    time: '8:45 AM',
    weather: 'Fog',
    incident: 'Peak Congestion',
    severity: 'Severe',
    intervention: 'Traffic diversion',
    outcome: 'Successful',
    success: true,
    delayBeforeMin: 28,
    delayAfterMin: 12,
    context: 'Early rerouting through ISB Road bypass prevented tailback on ORR toll plaza during foggy commuter surge.',
    source: 'Hindsight Retained'
  },
  {
    id: 'mem-gac-05',
    location: 'Gachibowli ORR Junction',
    zone: 'HITEC City / Gachibowli',
    coordinates: [78.3635, 17.4402],
    timestamp: '2026-04-06T08:40:00Z',
    day: 'Monday',
    time: '8:40 AM',
    weather: 'Fog',
    incident: 'Peak Congestion',
    severity: 'Severe',
    intervention: 'Traffic diversion',
    outcome: 'Successful',
    success: true,
    delayBeforeMin: 31,
    delayAfterMin: 13,
    context: 'Dynamic electronic signs directed Wipro Circle traffic via Khajaguda ramp, clearing the main bottleneck.',
    source: 'Hindsight Retained'
  },
  {
    id: 'mem-gac-06',
    location: 'Cyber Towers Junction',
    zone: 'HITEC City / Gachibowli',
    coordinates: [78.3792, 17.4508],
    timestamp: '2026-09-02T18:15:00Z',
    day: 'Wednesday',
    time: '6:15 PM',
    weather: 'Clear',
    incident: 'Signal Failure',
    severity: 'Critical',
    intervention: 'Manual traffic control',
    outcome: 'Successful',
    success: true,
    delayBeforeMin: 38,
    delayAfterMin: 16,
    context: 'Two traffic wardens assigned to prioritize Mindspace outbound stream cleared 4-way intersection gridlock.',
    source: 'Hindsight Retained'
  },
  {
    id: 'mem-gac-07',
    location: 'Cyber Towers Junction',
    zone: 'HITEC City / Gachibowli',
    coordinates: [78.3792, 17.4508],
    timestamp: '2026-08-19T18:30:00Z',
    day: 'Wednesday',
    time: '6:30 PM',
    weather: 'Clear',
    incident: 'Signal Failure',
    severity: 'Critical',
    intervention: 'Manual traffic control',
    outcome: 'Successful',
    success: true,
    delayBeforeMin: 40,
    delayAfterMin: 17,
    context: 'Manual hand signaling with designated bus priority lane restored flow during hardware reboot.',
    source: 'Hindsight Retained'
  },

  // 3. Secunderabad Cluster (Paradise, Rani Gunj, Waterlogging & Route Data)
  {
    id: 'mem-sec-01',
    location: 'Paradise Flyover Incline',
    zone: 'Secunderabad',
    coordinates: [78.4895, 17.4429],
    timestamp: '2026-08-07T19:15:00Z',
    day: 'Friday',
    time: '7:15 PM',
    weather: 'Rain',
    incident: 'Waterlogging',
    severity: 'Moderate',
    intervention: 'Manual traffic control',
    outcome: 'Successful',
    success: true,
    delayBeforeMin: 26,
    delayAfterMin: 12,
    context: 'Water pooled at flyover ascent. On-site officers channeled vehicles into central elevated lanes safely.',
    source: 'Hindsight Retained'
  },
  {
    id: 'mem-sec-02',
    location: 'Paradise Flyover Incline',
    zone: 'Secunderabad',
    coordinates: [78.4895, 17.4429],
    timestamp: '2026-07-17T19:20:00Z',
    day: 'Friday',
    time: '7:20 PM',
    weather: 'Rain',
    incident: 'Waterlogging',
    severity: 'Moderate',
    intervention: 'Manual traffic control',
    outcome: 'Successful',
    success: true,
    delayBeforeMin: 24,
    delayAfterMin: 11,
    context: 'Pumps deployed while wardens managed alternating lane release past the inundated slip road.',
    source: 'Hindsight Retained'
  },
  {
    id: 'mem-sec-03',
    location: 'Paradise Flyover Incline',
    zone: 'Secunderabad',
    coordinates: [78.4895, 17.4429],
    timestamp: '2026-06-26T19:10:00Z',
    day: 'Friday',
    time: '7:10 PM',
    weather: 'Rain',
    incident: 'Waterlogging',
    severity: 'Moderate',
    intervention: 'Signal retiming',
    outcome: 'Partially successful',
    success: false,
    delayBeforeMin: 25,
    delayAfterMin: 20,
    context: 'Signal timing adjusted at base, but flooded puddle physically constrained vehicle speed regardless of green time.',
    source: 'Hindsight Retained'
  },
  {
    id: 'mem-sec-04',
    location: 'MG Road Junction',
    zone: 'Secunderabad',
    coordinates: [78.5015, 17.4399],
    timestamp: '2026-08-21T18:45:00Z',
    day: 'Friday',
    time: '6:45 PM',
    weather: 'Rain',
    incident: 'Accident',
    severity: 'Severe',
    intervention: 'Traffic diversion',
    outcome: 'Successful',
    success: true,
    delayBeforeMin: 27,
    delayAfterMin: 13,
    context: 'Auto-rickshaw pileup diverted via Clock Tower loop, preventing rail station traffic blockage.',
    source: 'Hindsight Retained'
  },

  // 4. Banjara Hills & Jubilee Hills Cluster
  {
    id: 'mem-bjh-01',
    location: 'Road No. 36 Jubilee Hills',
    zone: 'Banjara Hills / Jubilee Hills',
    coordinates: [78.4239, 17.4328],
    timestamp: '2026-08-22T21:00:00Z',
    day: 'Saturday',
    time: '9:00 PM',
    weather: 'Clear',
    incident: 'Construction',
    severity: 'Moderate',
    intervention: 'Traffic diversion',
    outcome: 'Successful',
    success: true,
    delayBeforeMin: 18,
    delayAfterMin: 7,
    context: 'Night construction crane moved; diverted through Road No. 45 underpass maintained smooth arterial speed.',
    source: 'Hindsight Retained'
  },
  {
    id: 'mem-bjh-02',
    location: 'Road No. 1 Banjara Hills',
    zone: 'Banjara Hills / Jubilee Hills',
    coordinates: [78.4412, 17.4168],
    timestamp: '2026-08-15T17:30:00Z',
    day: 'Friday',
    time: '5:30 PM',
    weather: 'Rain',
    incident: 'Accident',
    severity: 'Severe',
    intervention: 'Signal retiming',
    outcome: 'Successful',
    success: true,
    delayBeforeMin: 29,
    delayAfterMin: 14,
    context: 'Hospital ambulance corridor established by syncing 3 consecutive traffic signals along Taj Krishna stretch.',
    source: 'Hindsight Retained'
  },
  {
    id: 'mem-bjh-03',
    location: 'Check Post Junction Jubilee Hills',
    zone: 'Banjara Hills / Jubilee Hills',
    coordinates: [78.4124, 17.4278],
    timestamp: '2026-07-28T19:00:00Z',
    day: 'Tuesday',
    time: '7:00 PM',
    weather: 'Clear',
    incident: 'VIP Movement',
    severity: 'Moderate',
    intervention: 'Corridor metering',
    outcome: 'Successful',
    success: true,
    delayBeforeMin: 22,
    delayAfterMin: 9,
    context: 'Corridor metering regulated access pulses, preventing total gridlock around Apollo emergency access ramp.',
    source: 'Hindsight Retained'
  },

  // 5. Begumpet / Somajiguda Cluster
  {
    id: 'mem-bgp-01',
    location: 'Begumpet Main Road',
    zone: 'Begumpet',
    coordinates: [78.4682, 17.4448],
    timestamp: '2026-08-05T18:30:00Z',
    day: 'Wednesday',
    time: '6:30 PM',
    weather: 'Clear',
    incident: 'Accident',
    severity: 'Severe',
    intervention: 'Signal retiming',
    outcome: 'Successful',
    success: true,
    delayBeforeMin: 23,
    delayAfterMin: 10,
    context: 'Flyover entrance collision. Lengthened flyover discharge cycle cleared queue before Begumpet railway crossing.',
    source: 'Hindsight Retained'
  },
  {
    id: 'mem-bgp-02',
    location: 'Shoppers Stop Junction Begumpet',
    zone: 'Begumpet',
    coordinates: [78.4630, 17.4430],
    timestamp: '2026-07-10T19:15:00Z',
    day: 'Friday',
    time: '7:15 PM',
    weather: 'Rain',
    incident: 'Waterlogging',
    severity: 'Moderate',
    intervention: 'Traffic diversion',
    outcome: 'Failed',
    success: false,
    delayBeforeMin: 26,
    delayAfterMin: 32,
    context: 'Diverted traffic into Prakash Nagar gullies; waterlogged residential underpass caused cascading blockages.',
    source: 'Hindsight Retained'
  },
  {
    id: 'mem-bgp-03',
    location: 'Somajiguda Raj Bhavan Road',
    zone: 'Begumpet',
    coordinates: [78.4578, 17.4241],
    timestamp: '2026-08-18T18:10:00Z',
    day: 'Tuesday',
    time: '6:10 PM',
    weather: 'Clear',
    incident: 'Peak Congestion',
    severity: 'Moderate',
    intervention: 'Corridor metering',
    outcome: 'Successful',
    success: true,
    delayBeforeMin: 17,
    delayAfterMin: 8,
    context: 'Metered inflow from Panjagutta flyover, maintaining free flow past Yashoda Somajiguda emergency gate.',
    source: 'Hindsight Retained'
  }
];

// Generate additional 45 programmatic memories to reach 65+ total realistic memories across all 5 zones
const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const WEATHERS: ('Rain' | 'Clear' | 'Fog' | 'Overcast' | 'Heavy Rain')[] = ['Rain', 'Clear', 'Fog', 'Overcast', 'Heavy Rain'];
const INCIDENTS: ('Accident' | 'Waterlogging' | 'Signal Failure' | 'Construction' | 'Peak Congestion' | 'VIP Movement')[] = [
  'Accident', 'Waterlogging', 'Signal Failure', 'Construction', 'Peak Congestion', 'VIP Movement'
];
const INTERVENTIONS: ('Signal retiming' | 'Traffic diversion' | 'Manual traffic control' | 'Corridor metering')[] = [
  'Signal retiming', 'Traffic diversion', 'Manual traffic control', 'Corridor metering'
];

for (let i = 1; i <= 48; i++) {
  const zoneObj = HYDERABAD_ZONES[i % HYDERABAD_ZONES.length];
  const day = DAYS[i % DAYS.length];
  const weather = WEATHERS[i % WEATHERS.length];
  const incident = INCIDENTS[i % INCIDENTS.length];
  const intervention = INTERVENTIONS[i % INTERVENTIONS.length];
  
  // Realistic correlation: Signal retiming works well on Accidents & Clear/Rain peak hours;
  // Diversion works well in Fog/Construction on broad corridors, but fails in waterlogging.
  let isSuccess = false;
  if (intervention === 'Signal retiming' && incident === 'Accident') {
    isSuccess = i % 3 !== 0; // 67% success
  } else if (intervention === 'Traffic diversion' && weather === 'Fog') {
    isSuccess = i % 4 !== 0; // 75% success
  } else if (intervention === 'Manual traffic control' && (incident === 'Signal Failure' || incident === 'Waterlogging')) {
    isSuccess = i % 5 !== 0; // 80% success
  } else if (intervention === 'Traffic diversion' && weather === 'Rain') {
    isSuccess = i % 3 === 0; // only 33% success (rain floods diversions)
  } else {
    isSuccess = i % 2 === 0;
  }

  const delayBefore = 18 + (i % 18);
  const delayAfter = isSuccess ? Math.max(6, Math.round(delayBefore * 0.45)) : delayBefore + Math.round((i % 7) + 2);
  const outcome: 'Successful' | 'Partially successful' | 'Failed' = isSuccess 
    ? 'Successful' 
    : (i % 3 === 0 ? 'Partially successful' : 'Failed');

  const hour = 8 + (i % 13);
  const minute = (i * 12) % 60;
  const timeStr = `${hour > 12 ? hour - 12 : hour}:${minute < 10 ? '0' : ''}${minute} ${hour >= 12 ? 'PM' : 'AM'}`;

  // Slightly jitter coordinate around zone center
  const jitterLng = (Math.sin(i * 99) * 0.015);
  const jitterLat = (Math.cos(i * 77) * 0.012);

  SEED_HISTORICAL_MEMORIES.push({
    id: `mem-synth-${i.toString().padStart(3, '0')}`,
    location: `${zoneObj.corridors[i % zoneObj.corridors.length]}`,
    zone: zoneObj.name,
    coordinates: [Number((zoneObj.center[0] + jitterLng).toFixed(5)), Number((zoneObj.center[1] + jitterLat).toFixed(5))],
    timestamp: `2026-0${(i % 8) + 1}-${((i % 25) + 1).toString().padStart(2, '0')}T${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}:00Z`,
    day,
    time: timeStr,
    weather,
    incident,
    severity: (i % 3 === 0 ? 'Critical' : (i % 2 === 0 ? 'Severe' : 'Moderate')),
    intervention,
    outcome,
    success: isSuccess,
    delayBeforeMin: delayBefore,
    delayAfterMin: delayAfter,
    context: `Historical logged incident at ${zoneObj.name}. Intervention ${intervention} resulted in ${outcome}. Delay changed from ${delayBefore}m to ${delayAfter}m.`,
    source: 'Hindsight Retained'
  });
}
