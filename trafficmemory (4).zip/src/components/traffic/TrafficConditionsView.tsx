import React, { useState } from 'react';
import { 
  AnalyzeRequest, 
  AnalyzeResponse, 
  IncidentType, 
  InterventionType, 
  OutcomeStatus, 
  Severity, 
  Weather,
  TrafficMemoryItem,
  ZoneInfo
} from '../../types/traffic.ts';
import { 
  Activity, 
  Sparkles, 
  Cpu, 
  CheckCircle2, 
  AlertTriangle, 
  Database, 
  ArrowRight, 
  Clock, 
  Layers, 
  TrendingUp, 
  SendHorizontal, 
  Compass, 
  Ambulance, 
  Map as MapIcon,
  ShieldCheck,
  Zap,
  Sliders
} from 'lucide-react';
import { RecordOutcomeModal } from './RecordOutcomeModal.tsx';

interface TrafficConditionsViewProps {
  initialForm: AnalyzeRequest;
  analysis: AnalyzeResponse | null;
  isAnalyzing: boolean;
  onAnalyzeAndShowMap: (form: AnalyzeRequest) => void;
  onRecordOutcome: (data: {
    outcome: OutcomeStatus;
    notes: string;
    delayBeforeMin: number;
    delayAfterMin: number;
  }) => Promise<void>;
  lastRetainedMemory?: TrafficMemoryItem | null;
  zones: ZoneInfo[];
  activeZoneId: string;
  onZoneChange: (zone: ZoneInfo) => void;
  onNavigate: (tab: 'overview' | 'traffic-ops' | 'emergency' | 'map' | 'memory' | 'intelligence' | 'demo') => void;
}

// Convert "6:30 PM" to "18:30"
function to24HourTime(timeStr: string): string {
  if (!timeStr) return '18:30';
  const match = timeStr.match(/(\d{1,2}):(\d{2})\s*(AM|PM)?/i);
  if (!match) return '18:30';
  let hours = parseInt(match[1], 10);
  const minutes = match[2];
  const modifier = match[3]?.toUpperCase();

  if (modifier === 'PM' && hours < 12) hours += 12;
  if (modifier === 'AM' && hours === 12) hours = 0;

  return `${hours.toString().padStart(2, '0')}:${minutes}`;
}

export const TrafficConditionsView: React.FC<TrafficConditionsViewProps> = ({
  initialForm,
  analysis,
  isAnalyzing,
  onAnalyzeAndShowMap,
  onRecordOutcome,
  lastRetainedMemory,
  zones,
  activeZoneId,
  onZoneChange,
  onNavigate
}) => {
  const [form, setForm] = useState<AnalyzeRequest>(initialForm);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSavingRecord, setIsSavingRecord] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAnalyzeAndShowMap(form);
  };

  const handleZoneSelect = (zoneName: string) => {
    const matched = zones.find(z => z.name === zoneName);
    if (matched) {
      onZoneChange(matched);
      setForm(prev => ({
        ...prev,
        zone: matched.name,
        location: `${matched.name} Junction`
      }));
    }
  };

  const handleRecordSubmit = async (data: {
    outcome: OutcomeStatus;
    notes: string;
    delayBeforeMin: number;
    delayAfterMin: number;
  }) => {
    setIsSavingRecord(true);
    try {
      await onRecordOutcome(data);
      setIsModalOpen(false);
    } finally {
      setIsSavingRecord(false);
    }
  };

  return (
    <div className="flex-1 w-full h-full overflow-y-auto bg-[#071321] text-[#F1F5F9] p-6 lg:p-8 select-none">
      <div className="max-w-7xl mx-auto space-y-8 pb-12">
        {/* Page Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#203752]">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded bg-[#2F80ED]/15 text-[#2F80ED] text-xs font-mono font-bold border border-[#2F80ED]/30">
                TRAFFIC CONDITIONS ENGINE
              </span>
              <span className="text-xs text-[#8EA3BA] uppercase tracking-wider">
                Full Specifications & Simulation
              </span>
            </div>
            <h1 className="text-2xl lg:text-3xl font-bold text-white mt-1">
              Urban Mobility Specifications & Incident Analyzer
            </h1>
            <p className="text-sm text-[#8EA3BA] mt-1">
              Configure precise road conditions across Hyderabad. Analyze incidents with Hindsight episodic memory to generate the response map.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('emergency')}
              className="px-4 py-2 rounded-lg bg-[#EF5B5B]/15 hover:bg-[#EF5B5B]/25 text-[#EF5B5B] border border-[#EF5B5B]/30 text-xs font-semibold flex items-center gap-2 cursor-pointer transition-all"
            >
              <Ambulance className="w-4 h-4" />
              <span>Interlinked Emergency Page</span>
            </button>
            <button
              onClick={() => onNavigate('map')}
              className="px-4 py-2 rounded-lg bg-[#102238] hover:bg-[#152c48] border border-[#203752] text-xs text-white font-medium flex items-center gap-1.5 cursor-pointer transition-all"
            >
              <MapIcon className="w-3.5 h-3.5 text-[#2F80ED]" />
              <span>View Map</span>
            </button>
          </div>
        </div>

        {/* Interlink Alert Banner */}
        <div className="p-4 rounded-xl bg-gradient-to-r from-[#102238] via-[#0d1e33] to-[#121f2f] border border-[#2F80ED]/30 flex flex-col md:flex-row md:items-center justify-between gap-3 shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#2F80ED]/20 text-[#2F80ED] flex items-center justify-center shrink-0">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                Real-Time Interlink Active: Traffic Ops ⇄ Emergency Routing
              </h4>
              <p className="text-xs text-[#8EA3BA]">
                Incident parameters and delays simulated here automatically update the Emergency Dispatch engine to compute optimal detour routes for ambulances.
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigate('emergency')}
            className="px-3 py-1.5 rounded bg-[#2F80ED]/20 hover:bg-[#2F80ED]/30 text-[#2F80ED] border border-[#2F80ED]/40 text-xs font-semibold shrink-0 cursor-pointer transition-all"
          >
            Review Emergency Corridors →
          </button>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* SPECIFICATIONS & FEATURES SECTION */}
        {/* ------------------------------------------------------------- */}
        <div className="rounded-xl bg-[#091728] border border-[#203752] p-6 space-y-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sliders className="w-4 h-4 text-[#2F80ED]" />
              <h3 className="text-base font-bold text-white">System Specifications & Operational Features</h3>
            </div>
            <span className="text-xs font-mono text-[#8EA3BA]">Hyderabad Metropolitan Grid v1.0</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
            <div className="p-4 rounded-lg bg-[#071321] border border-[#203752] space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-white">Sensor Density</span>
                <span className="px-1.5 py-0.5 rounded bg-[#20B77A]/15 text-[#20B77A] font-mono text-[10px]">100% ONLINE</span>
              </div>
              <p className="text-[#8EA3BA]">
                Integrated loop detectors, CCTV computer vision counters, and bus GPS telemetry along 14 key arterials.
              </p>
              <div className="pt-2 border-t border-[#203752]/70 text-[11px] text-[#2F80ED] font-mono">
                Refresh cycle: 30s
              </div>
            </div>

            <div className="p-4 rounded-lg bg-[#071321] border border-[#203752] space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-white">Weather Degradation</span>
                <span className="px-1.5 py-0.5 rounded bg-[#E8A52D]/15 text-[#E8A52D] font-mono text-[10px]">-35% SPEED</span>
              </div>
              <p className="text-[#8EA3BA]">
                Monsoon rain reduces vehicle speeds by 35% and increases junction clearance times by +22s across Ameerpet & Begumpet.
              </p>
              <div className="pt-2 border-t border-[#203752]/70 text-[11px] text-[#E8A52D] font-mono">
                Waterlogging risk active
              </div>
            </div>

            <div className="p-4 rounded-lg bg-[#071321] border border-[#203752] space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-white">Adaptive Signal Cycle</span>
                <span className="px-1.5 py-0.5 rounded bg-[#2F80ED]/15 text-[#2F80ED] font-mono text-[10px]">90s — 150s</span>
              </div>
              <p className="text-[#8EA3BA]">
                Dynamic green phase extension (+20s to +45s) based on vector memory recall of downstream spillback history.
              </p>
              <div className="pt-2 border-t border-[#203752]/70 text-[11px] text-[#2F80ED] font-mono">
                ITMS / SCATS standard
              </div>
            </div>

            <div className="p-4 rounded-lg bg-[#071321] border border-[#203752] space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-white">Hindsight Vector Memory</span>
                <span className="px-1.5 py-0.5 rounded bg-[#8B6FE8]/15 text-[#8B6FE8] font-mono text-[10px]">24 EPISODES</span>
              </div>
              <p className="text-[#8EA3BA]">
                Stores weather-indexed outcomes. Prevents the agent from re-executing failed traffic diversions in heavy rain.
              </p>
              <div className="pt-2 border-t border-[#203752]/70 text-[11px] text-[#8B6FE8] font-mono">
                Cosine similarity k=6
              </div>
            </div>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* INCIDENT CONFIGURATOR & ANALYZE FORM */}
        {/* ------------------------------------------------------------- */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Form: Configurator */}
          <div className="lg:col-span-7 rounded-xl bg-[#091728] border border-[#203752] p-6 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-[#203752]">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-[#2F80ED]" />
                <h3 className="text-base font-bold text-white">Traffic Condition Simulator</h3>
              </div>
              <span className="text-xs text-[#8EA3BA]">Specify scenario parameters</span>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Zone Selector */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#8EA3BA] uppercase tracking-wider">
                  Operational Zone
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {zones.map(z => {
                    const isSelected = form.zone === z.name;
                    return (
                      <button
                        type="button"
                        key={z.id}
                        onClick={() => handleZoneSelect(z.name)}
                        className={`px-3 py-2 rounded-lg text-xs font-medium text-left truncate transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-[#2F80ED] text-white shadow-sm font-semibold'
                            : 'bg-[#071321] text-[#8EA3BA] hover:text-white border border-[#203752]'
                        }`}
                      >
                        {z.name}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Exact Location Input */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#8EA3BA] uppercase tracking-wider">
                  Intersection / Road Name
                </label>
                <input
                  type="text"
                  value={form.location}
                  onChange={e => setForm(prev => ({ ...prev, location: e.target.value }))}
                  className="w-full px-3 py-2 rounded-lg bg-[#071321] border border-[#203752] text-white text-xs focus:border-[#2F80ED] focus:outline-none"
                  placeholder="e.g. Ameerpet Cross Roads"
                  required
                />
              </div>

              {/* Day & Time */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-[#8EA3BA] uppercase tracking-wider">
                    Day of Week
                  </label>
                  <select
                    value={form.day}
                    onChange={e => setForm(prev => ({ ...prev, day: e.target.value }))}
                    className="w-full px-3 py-2 rounded-lg bg-[#071321] border border-[#203752] text-white text-xs focus:border-[#2F80ED] focus:outline-none"
                  >
                    {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map(d => (
                      <option key={d} value={d} className="bg-[#071321] text-white">{d}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-[#8EA3BA] uppercase tracking-wider">
                    Time (24-Hour)
                  </label>
                  <input
                    type="time"
                    value={to24HourTime(form.time)}
                    onChange={e => {
                      const val = e.target.value;
                      if (!val) return;
                      const [hStr, mStr] = val.split(':');
                      let h = parseInt(hStr, 10);
                      const ampm = h >= 12 ? 'PM' : 'AM';
                      if (h > 12) h -= 12;
                      if (h === 0) h = 12;
                      setForm(prev => ({ ...prev, time: `${h}:${mStr} ${ampm}` }));
                    }}
                    className="w-full px-3 py-2 rounded-lg bg-[#071321] border border-[#203752] text-white text-xs focus:border-[#2F80ED] focus:outline-none"
                  />
                </div>
              </div>

              {/* Weather & Incident */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-[#8EA3BA] uppercase tracking-wider">
                    Weather Condition
                  </label>
                  <select
                    value={form.weather}
                    onChange={e => setForm(prev => ({ ...prev, weather: e.target.value as Weather }))}
                    className="w-full px-3 py-2 rounded-lg bg-[#071321] border border-[#203752] text-white text-xs focus:border-[#2F80ED] focus:outline-none"
                  >
                    {['Clear', 'Rain', 'Heavy Rain', 'Fog'].map(w => (
                      <option key={w} value={w} className="bg-[#071321] text-white">{w}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-[#8EA3BA] uppercase tracking-wider">
                    Incident Type
                  </label>
                  <select
                    value={form.incident}
                    onChange={e => setForm(prev => ({ ...prev, incident: e.target.value as IncidentType }))}
                    className="w-full px-3 py-2 rounded-lg bg-[#071321] border border-[#203752] text-white text-xs focus:border-[#2F80ED] focus:outline-none"
                  >
                    {['Accident', 'Waterlogging', 'Peak Congestion', 'VIP Movement', 'Signal Failure'].map(i => (
                      <option key={i} value={i} className="bg-[#071321] text-white">{i}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Severity */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#8EA3BA] uppercase tracking-wider">
                  Severity Level
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {(['Minor', 'Moderate', 'Severe'] as Severity[]).map(sev => {
                    const isSelected = form.severity === sev;
                    return (
                      <button
                        type="button"
                        key={sev}
                        onClick={() => setForm(prev => ({ ...prev, severity: sev }))}
                        className={`py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                          isSelected
                            ? sev === 'Severe'
                              ? 'bg-[#EF5B5B] text-white shadow-sm'
                              : sev === 'Moderate'
                              ? 'bg-[#E8A52D] text-white shadow-sm'
                              : 'bg-[#20B77A] text-white shadow-sm'
                            : 'bg-[#071321] text-[#8EA3BA] border border-[#203752] hover:text-white'
                        }`}
                      >
                        {sev}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Submit Button */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isAnalyzing}
                  className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-[#2F80ED] to-[#1E6FD9] hover:from-[#3a8bf0] hover:to-[#2277e3] text-white font-bold text-sm shadow-lg shadow-[#2F80ED]/25 flex items-center justify-center gap-2 cursor-pointer transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50"
                >
                  <Sparkles className="w-4 h-4 fill-white" />
                  <span>
                    {isAnalyzing ? 'Recalling Experiences & Generating Map...' : '⚡ Analyze & Generate Map'}
                  </span>
                </button>
                <p className="text-[11px] text-[#8EA3BA] text-center mt-2">
                  Queries Hindsight memory, computes the optimal intervention, and navigates directly to the full-canvas map.
                </p>
              </div>
            </form>
          </div>

          {/* Right Column: Active Analysis & Recalled Memories */}
          <div className="lg:col-span-5 space-y-4">
            {analysis ? (
              <div className="rounded-xl bg-[#091728] border border-[#203752] p-5 space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-[#203752]">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-[#20B77A] animate-pulse"></span>
                    <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                      Analysis Results
                    </h3>
                  </div>
                  <button
                    onClick={() => onNavigate('map')}
                    className="text-xs text-[#2F80ED] hover:underline font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    <span>View On Map</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Primary Recommendation */}
                <div className="p-4 rounded-lg bg-[#0e2136] border border-[#20B77A]/40 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-[#20B77A]/20 text-[#20B77A]">
                      PRIMARY RECOMMENDED ACTION
                    </span>
                    <span className="text-xs font-mono font-bold text-white">
                      {Math.round((analysis.historicalEvidence?.confidenceScore || 0.85) * 100)}% Confidence
                    </span>
                  </div>
                  <h4 className="text-base font-bold text-white">
                    {analysis.recommendation.primaryAction}
                  </h4>
                  <p className="text-xs text-[#8EA3BA] leading-relaxed">
                    {analysis.recommendation.explanation}
                  </p>
                </div>

                {/* Recalled Memory Insights */}
                <div className="space-y-2 text-xs">
                  <div className="flex items-center justify-between text-[#8EA3BA]">
                    <span className="font-semibold uppercase text-[10px] tracking-wider">
                      Recalled Past Experiences
                    </span>
                    <span className="font-mono text-[#8B6FE8]">
                      {analysis.hindsightRecall.totalRecalled} similar events
                    </span>
                  </div>

                  <div className="p-3 rounded-lg bg-[#071321] border border-[#203752] space-y-1.5 text-xs">
                    <div className="text-[#8EA3BA]">
                      Why this action won: <span className="text-white font-medium">{analysis.recommendation.reasoningBullets?.[0] || analysis.recommendation.explanation}</span>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="pt-2 flex gap-3">
                  <button
                    onClick={() => onNavigate('map')}
                    className="flex-1 py-2.5 rounded-lg bg-[#2F80ED] hover:bg-[#3b8af0] text-white text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-all shadow-sm"
                  >
                    <MapIcon className="w-3.5 h-3.5" />
                    <span>Open Live Map View</span>
                  </button>
                  <button
                    onClick={() => setIsModalOpen(true)}
                    className="px-4 py-2.5 rounded-lg bg-[#102238] hover:bg-[#152c48] border border-[#203752] text-xs text-[#8EA3BA] hover:text-white font-medium cursor-pointer transition-all"
                  >
                    Record Outcome
                  </button>
                </div>
              </div>
            ) : (
              <div className="rounded-xl bg-[#091728] border border-[#203752] p-6 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-[#102238] border border-[#203752] flex items-center justify-center mx-auto text-[#8EA3BA]">
                  <Activity className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-bold text-white">No Incident Analyzed Yet</h4>
                <p className="text-xs text-[#8EA3BA]">
                  Select your zone and parameters on the left, then click <strong>Analyze & Generate Map</strong> to query Hindsight memory and view the results on the map.
                </p>
              </div>
            )}

            {/* Quick Corridor Snapshot */}
            <div className="rounded-xl bg-[#091728] border border-[#203752] p-4 space-y-3">
              <span className="text-xs font-bold text-white uppercase tracking-wider block">
                Hyderabad Key Corridors
              </span>
              <div className="space-y-2 text-xs">
                {[
                  { name: 'Ameerpet - Maitrivanam', speed: '14 km/h', status: 'Congested', color: 'text-[#EF5B5B]' },
                  { name: 'HITEC City - Mindspace', speed: '22 km/h', status: 'Moderate', color: 'text-[#E8A52D]' },
                  { name: 'Secunderabad - Paradise', speed: '34 km/h', status: 'Normal', color: 'text-[#20B77A]' },
                ].map(c => (
                  <div key={c.name} className="flex items-center justify-between p-2 rounded bg-[#071321] border border-[#203752]">
                    <span className="text-white font-medium">{c.name}</span>
                    <div className="flex items-center gap-3">
                      <span className="text-[#8EA3BA] font-mono">{c.speed}</span>
                      <span className={`font-semibold font-mono ${c.color}`}>{c.status}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Record Outcome Modal */}
      {analysis && (
        <RecordOutcomeModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onSubmit={handleRecordSubmit}
          incidentContext={{
            location: analysis.eventReceived.location,
            zone: form.zone || 'Ameerpet',
            day: analysis.eventReceived.day,
            time: analysis.eventReceived.time,
            weather: analysis.eventReceived.weather,
            incident: analysis.eventReceived.incident,
            severity: analysis.eventReceived.severity,
            intervention: analysis.recommendation.primaryAction
          }}
          isSaving={isSavingRecord}
        />
      )}
    </div>
  );
};
