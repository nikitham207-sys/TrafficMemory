import React, { useState } from 'react';
import { 
  AnalyzeRequest, 
  AnalyzeResponse, 
  IncidentType, 
  InterventionType, 
  OutcomeStatus, 
  Severity, 
  Weather,
  TrafficMemoryItem,
  ZoneInfo
} from '../../types/traffic.ts';
import { 
  ArrowRight, 
  Sparkles, 
  BrainCircuit, 
  CheckCircle2, 
  AlertCircle, 
  ChevronRight, 
  Database, 
  Layers,
  History,
  TrendingUp,
  Clock,
  SendHorizontal
} from 'lucide-react';
import { RecordOutcomeModal } from './RecordOutcomeModal.tsx';

interface TrafficOperationsPanelProps {
  initialForm?: AnalyzeRequest;
  analysis: AnalyzeResponse | null;
  isAnalyzing: boolean;
  onAnalyze: (form: AnalyzeRequest) => void;
  onRecordOutcome: (data: {
    outcome: OutcomeStatus;
    notes: string;
    delayBeforeMin: number;
    delayAfterMin: number;
  }) => Promise<void>;
  lastRetainedMemory?: TrafficMemoryItem | null;
  zones?: ZoneInfo[];
  activeZoneId?: string;
  onZoneChange?: (zone: ZoneInfo) => void;
  onFormChange?: (form: AnalyzeRequest) => void;
}

// Convert "6:30 PM" to "18:30" for <input type="time">
function to24HourTime(timeStr: string): string {
  if (!timeStr) return '18:30';
  const match = timeStr.match(/(\d{1,2}):(\d{2})\s*(AM|PM)?/i);
  if (!match) return '18:30';
  let hours = parseInt(match[1], 10);
  const minutes = match[2];
  const modifier = match[3]?.toUpperCase();

  if (modifier === 'PM' && hours < 12) hours += 12;
  if (modifier === 'AM' && hours === 12) hours = 0;

  return `${hours.toString().padStart(2, '0')}:${minutes}`;
}

// Convert "18:30" to "6:30 PM"
function to12HourTime(time24: string): string {
  if (!time24) return '6:30 PM';
  const parts = time24.split(':');
  if (parts.length < 2) return time24;
  let hours = parseInt(parts[0], 10);
  const minutes = parts[1];
  const ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  if (hours === 0) hours = 12;
  return `${hours}:${minutes} ${ampm}`;
}

// Get current system time formatted as 12-hour string
function getCurrentLocalTime(): string {
  const now = new Date();
  let hours = now.getHours();
  const minutes = now.getMinutes().toString().padStart(2, '0');
  const ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  if (hours === 0) hours = 12;
  return `${hours}:${minutes} ${ampm}`;
}

const ZONE_CORRIDOR_MAP: Record<string, string[]> = {
  'Ameerpet': ['Ameerpet Cross Roads', 'Maitrivanam Nexus', 'SR Nagar Main Road', 'Panjagutta Junction'],
  'Begumpet': ['Begumpet Main Road', 'Somajiguda Raj Bhavan Road', 'Prakash Nagar Flyover', 'Shoppers Stop Junction'],
  'Secunderabad': ['Paradise Flyover Incline', 'MG Road', 'SP Road', 'Rani Gunj'],
  'Banjara Hills / Jubilee Hills': ['Road No. 36 Jubilee Hills', 'Road No. 1 Banjara Hills', 'Check Post Junction'],
  'HITEC City / Gachibowli': ['Cyber Towers Junction', 'Gachibowli ORR Junction', 'Biodiversity Park Flyover']
};

export const TrafficOperationsPanel: React.FC<TrafficOperationsPanelProps> = ({
  initialForm,
  analysis,
  isAnalyzing,
  onAnalyze,
  onRecordOutcome,
  lastRetainedMemory,
  zones = [],
  activeZoneId,
  onZoneChange,
  onFormChange
}) => {
  const [form, setForm] = useState<AnalyzeRequest>(initialForm || {
    location: 'Ameerpet Cross Roads',
    zone: 'Ameerpet',
    day: 'Friday',
    time: '6:30 PM',
    weather: 'Rain',
    incident: 'Accident',
    severity: 'Severe'
  });

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSavingOutcome, setIsSavingOutcome] = useState(false);
  const [isManualTimeInput, setIsManualTimeInput] = useState(false);

  // Sync when initialForm changes (e.g., clicking popup, scenario, or zone selection)
  React.useEffect(() => {
    if (initialForm) {
      setForm(initialForm);
    }
  }, [initialForm]);

  // Update a form field and notify parent
  const updateForm = (patch: Partial<AnalyzeRequest>) => {
    const updated = { ...form, ...patch };
    setForm(updated);
    onFormChange?.(updated);
  };

  // Handle explicit Operational Zone change
  const handleZoneSelect = (newZoneName: string) => {
    const matchedZone = zones.find(z => z.name.toLowerCase() === newZoneName.toLowerCase() || z.name.includes(newZoneName) || newZoneName.includes(z.name));
    const corridorsForZone = ZONE_CORRIDOR_MAP[newZoneName] || (matchedZone ? matchedZone.corridors : ['Ameerpet Cross Roads']);
    const defaultLocation = corridorsForZone[0] || form.location;

    updateForm({
      zone: newZoneName,
      location: defaultLocation
    });

    if (matchedZone && onZoneChange) {
      onZoneChange(matchedZone);
    }
  };

  // Handle Location change and auto-detect zone
  const handleLocationSelect = (newLocation: string) => {
    let targetZone: string = form.zone || 'Ameerpet';
    if (newLocation.includes('Secunderabad') || newLocation.includes('Paradise') || newLocation.includes('MG Road') || newLocation.includes('SP Road') || newLocation.includes('Rani Gunj')) {
      targetZone = 'Secunderabad';
    } else if (newLocation.includes('Begumpet') || newLocation.includes('Somajiguda') || newLocation.includes('Prakash Nagar') || newLocation.includes('Shoppers Stop')) {
      targetZone = 'Begumpet';
    } else if (newLocation.includes('Banjara') || newLocation.includes('Jubilee') || newLocation.includes('Check Post')) {
      targetZone = 'Banjara Hills / Jubilee Hills';
    } else if (newLocation.includes('Gachibowli') || newLocation.includes('Cyber Towers') || newLocation.includes('Biodiversity')) {
      targetZone = 'HITEC City / Gachibowli';
    } else if (newLocation.includes('Ameerpet') || newLocation.includes('Maitrivanam') || newLocation.includes('SR Nagar') || newLocation.includes('Panjagutta')) {
      targetZone = 'Ameerpet';
    }

    updateForm({
      location: newLocation,
      zone: targetZone
    });

    if (targetZone !== form.zone) {
      const matchedZone = zones.find(z => z.name.toLowerCase() === targetZone.toLowerCase() || z.name.includes(targetZone) || targetZone.includes(z.name));
      if (matchedZone && onZoneChange) {
        onZoneChange(matchedZone);
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAnalyze(form);
  };

  const handleOutcomeSubmit = async (data: {
    outcome: OutcomeStatus;
    notes: string;
    delayBeforeMin: number;
    delayAfterMin: number;
  }) => {
    setIsSavingOutcome(true);
    try {
      await onRecordOutcome(data);
      setIsModalOpen(false);
    } finally {
      setIsSavingOutcome(false);
    }
  };

  return (
    <div className="w-[340px] xl:w-[380px] bg-[#0B1929] border-l border-[#203752] flex flex-col justify-between h-full shrink-0 select-none overflow-y-auto z-20">
      <div className="p-4 space-y-4">
        {/* Header */}
        <div className="pb-3 border-b border-[#203752]">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold tracking-tight text-[#F1F5F9]">Traffic Operations</h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#2F80ED]/15 text-[#2F80ED] border border-[#2F80ED]/30">
              OPERATIONAL
            </span>
          </div>
          <p className="text-[11px] text-[#8EA3BA] mt-0.5">
            Use historical experience to decide what to do next.
          </p>
        </div>

        {/* Input Form */}
        <form onSubmit={handleSubmit} className="space-y-2.5 bg-[#081522] p-3 rounded-lg border border-[#203752]">
          <div className="grid grid-cols-2 gap-2">
            {/* Operational Zone Selector */}
            <div className="col-span-2">
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10px] font-semibold text-[#8EA3BA] uppercase tracking-wider flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-[#2F80ED] animate-pulse"></span>
                  <span>Operational Zone</span>
                </label>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#2F80ED]/15 text-[#2F80ED] border border-[#2F80ED]/30">
                  {form.zone}
                </span>
              </div>
              <select
                value={form.zone}
                onChange={(e) => handleZoneSelect(e.target.value)}
                className="w-full bg-[#102238] border border-[#203752] rounded px-2.5 py-1.5 text-xs text-[#F1F5F9] focus:outline-none focus:border-[#2F80ED]"
              >
                <option value="Ameerpet">Ameerpet (AMP) — Commercial Hub & Metro Interchange</option>
                <option value="Begumpet">Begumpet (BGP) — Rashtrapati Road & Airport Express</option>
                <option value="Secunderabad">Secunderabad (SEC) — Railway Nexus & Paradise Flyover</option>
                <option value="Banjara Hills / Jubilee Hills">Banjara Hills / Jubilee Hills (BJH) — Medical Corridor</option>
                <option value="HITEC City / Gachibowli">HITEC City / Gachibowli (HTC) — Cyber Towers & IT Corridor</option>
              </select>
            </div>

            {/* Location / Corridor Selector */}
            <div className="col-span-2">
              <label className="block text-[10px] font-semibold text-[#8EA3BA] uppercase tracking-wider mb-1">
                Location / Corridor (in {form.zone || 'Ameerpet'})
              </label>
              <select
                value={form.location}
                onChange={(e) => handleLocationSelect(e.target.value)}
                className="w-full bg-[#102238] border border-[#203752] rounded px-2.5 py-1.5 text-xs text-[#F1F5F9] focus:outline-none focus:border-[#2F80ED]"
              >
                <optgroup label={`${form.zone || 'Ameerpet'} Corridors`}>
                  {(ZONE_CORRIDOR_MAP[form.zone || 'Ameerpet'] || []).map((loc: string) => (
                    <option key={loc} value={loc}>{loc}</option>
                  ))}
                </optgroup>
                <optgroup label="Other Zones">
                  {Object.entries(ZONE_CORRIDOR_MAP)
                    .filter(([z]) => z !== (form.zone || 'Ameerpet'))
                    .flatMap(([z, locs]) => locs.map((loc: string) => (
                      <option key={loc} value={loc}>{loc} ({z})</option>
                    )))
                  }
                </optgroup>
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-semibold text-[#8EA3BA] uppercase tracking-wider mb-1">
                Day
              </label>
              <select
                value={form.day}
                onChange={(e) => updateForm({ day: e.target.value })}
                className="w-full bg-[#102238] border border-[#203752] rounded px-2 py-1.5 text-xs text-[#F1F5F9] focus:outline-none focus:border-[#2F80ED]"
              >
                <option value="Friday">Friday</option>
                <option value="Monday">Monday</option>
                <option value="Tuesday">Tuesday</option>
                <option value="Wednesday">Wednesday</option>
                <option value="Thursday">Thursday</option>
                <option value="Saturday">Saturday</option>
                <option value="Sunday">Sunday</option>
              </select>
            </div>

            {/* Manual Time Choosing with Dual Mode (Time Picker + Manual Text Input + Live 'Now' button) */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10px] font-semibold text-[#8EA3BA] uppercase tracking-wider">
                  Time
                </label>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => updateForm({ time: getCurrentLocalTime() })}
                    className="text-[9px] px-1 py-0.5 rounded bg-[#2F80ED]/20 text-[#2F80ED] hover:bg-[#2F80ED]/30 cursor-pointer transition-colors"
                    title="Set to current local time"
                  >
                    Now
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsManualTimeInput(!isManualTimeInput)}
                    className="text-[9px] text-[#8EA3BA] hover:text-white underline cursor-pointer"
                  >
                    {isManualTimeInput ? 'Clock' : 'Type'}
                  </button>
                </div>
              </div>

              {isManualTimeInput ? (
                <input
                  type="text"
                  value={form.time}
                  onChange={(e) => updateForm({ time: e.target.value })}
                  placeholder="e.g. 6:30 PM, 14:15, 08:45 AM"
                  className="w-full bg-[#102238] border border-[#203752] rounded px-2 py-1.5 text-xs text-[#F1F5F9] focus:outline-none focus:border-[#2F80ED] font-mono"
                />
              ) : (
                <input
                  type="time"
                  value={to24HourTime(form.time)}
                  onChange={(e) => {
                    if (e.target.value) {
                      updateForm({ time: to12HourTime(e.target.value) });
                    }
                  }}
                  className="w-full bg-[#102238] border border-[#203752] rounded px-2 py-1.5 text-xs text-[#F1F5F9] focus:outline-none focus:border-[#2F80ED] font-mono"
                />
              )}
            </div>

            {/* Quick Time Preset Shortcuts */}
            <div className="col-span-2 flex items-center gap-1 pt-0.5">
              <span className="text-[9px] text-[#8EA3BA]">Quick:</span>
              {[
                { label: '08:45 AM', hint: 'Morning Rush' },
                { label: '02:30 PM', hint: 'Mid-Day' },
                { label: '06:30 PM', hint: 'Peak' },
                { label: '09:00 PM', hint: 'Late' }
              ].map(preset => (
                <button
                  key={preset.label}
                  type="button"
                  onClick={() => updateForm({ time: preset.label })}
                  className={`text-[9px] px-1.5 py-0.5 rounded border transition-colors ${
                    form.time.includes(preset.label) 
                      ? 'bg-[#2F80ED] text-white border-white' 
                      : 'bg-[#102238] text-[#8EA3BA] border-[#203752] hover:text-white'
                  }`}
                  title={preset.hint}
                >
                  {preset.label}
                </button>
              ))}
            </div>

            <div>
              <label className="block text-[10px] font-semibold text-[#8EA3BA] uppercase tracking-wider mb-1">
                Weather
              </label>
              <select
                value={form.weather}
                onChange={(e) => setForm({ ...form, weather: e.target.value as Weather })}
                className="w-full bg-[#102238] border border-[#203752] rounded px-2 py-1.5 text-xs text-[#F1F5F9] focus:outline-none focus:border-[#2F80ED]"
              >
                <option value="Rain">Rain</option>
                <option value="Clear">Clear</option>
                <option value="Fog">Fog</option>
                <option value="Overcast">Overcast</option>
                <option value="Heavy Rain">Heavy Rain</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-semibold text-[#8EA3BA] uppercase tracking-wider mb-1">
                Incident
              </label>
              <select
                value={form.incident}
                onChange={(e) => setForm({ ...form, incident: e.target.value as IncidentType })}
                className="w-full bg-[#102238] border border-[#203752] rounded px-2 py-1.5 text-xs text-[#F1F5F9] focus:outline-none focus:border-[#2F80ED]"
              >
                <option value="Accident">Accident</option>
                <option value="Peak Congestion">Peak Congestion</option>
                <option value="Waterlogging">Waterlogging</option>
                <option value="Signal Failure">Signal Failure</option>
                <option value="Construction">Construction</option>
                <option value="VIP Movement">VIP Movement</option>
              </select>
            </div>

            <div className="col-span-2">
              <label className="block text-[10px] font-semibold text-[#8EA3BA] uppercase tracking-wider mb-1">
                Severity Level
              </label>
              <div className="grid grid-cols-4 gap-1">
                {(['Normal', 'Moderate', 'Severe', 'Critical'] as Severity[]).map(sev => {
                  const isSel = form.severity === sev;
                  return (
                    <button
                      key={sev}
                      type="button"
                      onClick={() => setForm({ ...form, severity: sev })}
                      className={`py-1 text-[10px] font-semibold rounded border cursor-pointer transition-all ${
                        isSel
                          ? sev === 'Critical' ? 'bg-[#EF5B5B] text-white border-[#EF5B5B]'
                            : sev === 'Severe' ? 'bg-[#E8A52D] text-black border-[#E8A52D]'
                            : sev === 'Moderate' ? 'bg-[#2F80ED] text-white border-[#2F80ED]'
                            : 'bg-[#20B77A] text-white border-[#20B77A]'
                          : 'bg-[#102238] text-[#8EA3BA] border-[#203752]'
                      }`}
                    >
                      {sev}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={isAnalyzing}
            className="w-full mt-2 py-2 px-3 bg-[#2F80ED] hover:bg-[#2563EB] disabled:bg-[#203752] text-white font-medium text-xs rounded transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md"
          >
            {isAnalyzing ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                <span>Recalling Hindsight Memory...</span>
              </>
            ) : (
              <>
                <span>Analyze Situation</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </>
            )}
          </button>
        </form>

        {/* Retained Memory Notification Banner */}
        {lastRetainedMemory && (
          <div className="p-2.5 rounded bg-[#8B6FE8]/15 border border-[#8B6FE8]/40 space-y-1 animate-in fade-in duration-200">
            <div className="flex items-center gap-1.5 text-[#8B6FE8] text-[11px] font-bold">
              <Database className="w-3.5 h-3.5" />
              <span>NEW MEMORY CREATED</span>
            </div>
            <p className="text-[11px] text-[#F1F5F9]">
              Retained in persistent Hindsight layer: <span className="font-semibold">{lastRetainedMemory.intervention}</span> → <span className="text-[#20B77A] font-semibold">{lastRetainedMemory.outcome}</span> at {lastRetainedMemory.location}.
            </p>
          </div>
        )}

        {/* AI Analysis Result Section */}
        {analysis && (
          <div className="space-y-3.5 pt-1">
            {/* Header Status */}
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold uppercase tracking-wider text-[#8EA3BA] flex items-center gap-1.5">
                <BrainCircuit className="w-4 h-4 text-[#2F80ED]" />
                AI Analysis & Evidence
              </span>
              <span className="text-[10px] text-[#8B6FE8] font-mono">
                {analysis.hindsightRecall.totalRecalled} similar memories
              </span>
            </div>

            {/* Event Received Badge */}
            <div className="p-2.5 rounded bg-[#102238] border border-[#203752] text-xs space-y-1">
              <div className="text-[10px] uppercase font-semibold text-[#8EA3BA]">Event Received</div>
              <div className="font-medium text-[#F1F5F9]">
                {analysis.eventReceived.location} · {analysis.eventReceived.day} {analysis.eventReceived.time} · <span className="text-[#2F80ED]">{analysis.eventReceived.weather}</span> · {analysis.eventReceived.incident}
              </div>
            </div>

            {/* Hindsight Recall Evidence Breakdown */}
            <div className="p-3 rounded bg-[#102238] border border-[#203752] space-y-2">
              <div className="flex items-center justify-between text-[11px]">
                <span className="font-semibold text-[#8B6FE8] flex items-center gap-1">
                  <Database className="w-3.5 h-3.5" />
                  Hindsight Recall Evidence
                </span>
                <span className="text-[10px] text-[#8EA3BA]">
                  Avg delay: {analysis.historicalEvidence.avgHistoricalDelay}m
                </span>
              </div>

              <div className="space-y-1.5">
                {analysis.historicalEvidence.statsByIntervention.map(stat => (
                  <div key={stat.intervention} className="text-xs bg-[#081522] p-2 rounded border border-[#203752]/60">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-semibold text-[#F1F5F9]">{stat.intervention}</span>
                      <span className={`text-[11px] font-bold ${stat.successRate >= 60 ? 'text-[#20B77A]' : stat.successRate >= 40 ? 'text-[#E8A52D]' : 'text-[#EF5B5B]'}`}>
                        {stat.successCount} / {stat.totalAttempts} successful ({stat.successRate}%)
                      </span>
                    </div>
                    <div className="w-full bg-[#102238] rounded-full h-1.5 overflow-hidden">
                      <div 
                        className={`h-full rounded-full ${stat.successRate >= 60 ? 'bg-[#20B77A]' : stat.successRate >= 40 ? 'bg-[#E8A52D]' : 'bg-[#EF5B5B]'}`}
                        style={{ width: `${stat.successRate}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recommendation Card */}
            <div className="p-3.5 rounded-lg bg-[#102238] border-2 border-[#2F80ED]/60 space-y-2 shadow-lg">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#2F80ED] flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  Recommended Action
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#20B77A]/20 text-[#20B77A] border border-[#20B77A]/40 font-mono">
                  {analysis.recommendation.successRateDisplay}
                </span>
              </div>

              <div className="text-sm font-bold text-[#F1F5F9] uppercase tracking-wide">
                {analysis.recommendation.primaryAction}
              </div>

              <p className="text-xs text-[#8EA3BA] leading-relaxed">
                {analysis.recommendation.explanation}
              </p>

              <div className="pt-2 border-t border-[#203752]/80 space-y-1">
                {analysis.recommendation.reasoningBullets.map((bullet, idx) => (
                  <div key={idx} className="flex items-start gap-1.5 text-[11px] text-[#F1F5F9]/90">
                    <span className="text-[#2F80ED] mt-0.5">•</span>
                    <span>{bullet}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* WITHOUT MEMORY VS WITH TRAFFICMEMORY COMPARISON */}
            <div className="space-y-1.5 pt-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#8EA3BA]">
                Memory Advantage Comparison
              </span>
              <div className="grid grid-cols-1 gap-2">
                {/* Without Memory */}
                <div className="p-2.5 rounded bg-[#081522] border border-[#203752] text-xs space-y-1">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-semibold text-[#8EA3BA]">Without Memory</span>
                    <span className="text-[10px] text-[#EF5B5B] uppercase font-mono">Generic Heuristic</span>
                  </div>
                  <div className="text-[#F1F5F9] font-medium">{analysis.comparison.withoutMemory.action}</div>
                  <p className="text-[11px] text-[#8EA3BA]/80">{analysis.comparison.withoutMemory.risk}</p>
                </div>

                {/* With TrafficMemory */}
                <div className="p-2.5 rounded bg-[#102238] border border-[#20B77A]/50 text-xs space-y-1">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-semibold text-[#20B77A] flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      With TrafficMemory
                    </span>
                    <span className="text-[10px] text-[#20B77A] uppercase font-mono">Hindsight-Grounded</span>
                  </div>
                  <div className="text-[#F1F5F9] font-medium">{analysis.comparison.withTrafficMemory.action}</div>
                  <p className="text-[11px] text-[#8EA3BA]">{analysis.comparison.withTrafficMemory.rationale}</p>
                  <div className="text-[10px] text-[#20B77A] pt-0.5">{analysis.comparison.withTrafficMemory.historicalProof}</div>
                </div>
              </div>
            </div>

            {/* Record Outcome Button */}
            <div className="pt-2">
              <button
                type="button"
                onClick={() => setIsModalOpen(true)}
                className="w-full py-2 px-3 bg-[#102238] hover:bg-[#152d4a] border border-[#8B6FE8]/50 text-[#8B6FE8] hover:text-white font-medium text-xs rounded transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm"
              >
                <Database className="w-3.5 h-3.5" />
                <span>Record Operational Outcome</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Record Outcome Modal */}
      {analysis && (
        <RecordOutcomeModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onSubmit={handleOutcomeSubmit}
          isSaving={isSavingOutcome}
          incidentContext={{
            location: form.location,
            zone: form.zone || 'Ameerpet',
            day: form.day,
            time: form.time,
            weather: form.weather,
            incident: form.incident,
            severity: form.severity,
            intervention: analysis.recommendation.primaryAction
          }}
        />
      )}
    </div>
  );
};
