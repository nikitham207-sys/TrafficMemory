import React, { useState } from 'react';
import { OutcomeStatus, InterventionType, Weather, IncidentType, Severity } from '../../types/traffic.ts';
import { X, CheckCircle2, AlertTriangle, XCircle, Database, Sparkles } from 'lucide-react';

interface RecordOutcomeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: {
    outcome: OutcomeStatus;
    notes: string;
    delayBeforeMin: number;
    delayAfterMin: number;
  }) => Promise<void>;
  incidentContext: {
    location: string;
    zone: string;
    day: string;
    time: string;
    weather: Weather;
    incident: IncidentType;
    severity: Severity;
    intervention: InterventionType;
  };
  isSaving: boolean;
}

export const RecordOutcomeModal: React.FC<RecordOutcomeModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  incidentContext,
  isSaving
}) => {
  const [outcome, setOutcome] = useState<OutcomeStatus>('Successful');
  const [delayBefore, setDelayBefore] = useState<number>(22);
  const [delayAfter, setDelayAfter] = useState<number>(10);
  const [notes, setNotes] = useState<string>('Extended green wave cleared 2-lane choke along main corridor in 18 minutes.');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSubmit({
      outcome,
      notes,
      delayBeforeMin: Number(delayBefore),
      delayAfterMin: Number(delayAfter)
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 select-none animate-in fade-in duration-150">
      <div className="w-full max-w-md bg-[#0B1929] border border-[#203752] rounded-lg shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-[#081522] border-b border-[#203752]">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-[#8B6FE8]/20 text-[#8B6FE8] flex items-center justify-center">
              <Database className="w-3.5 h-3.5" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-[#F1F5F9] uppercase tracking-wide">Record Operational Outcome</h3>
              <p className="text-[10px] text-[#8EA3BA]">Retain ground truth to improve future decision recall</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-[#8EA3BA] hover:text-[#F1F5F9] p-1 rounded transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Form */}
        <form onSubmit={handleSubmit} className="p-4 space-y-3.5 text-xs">
          {/* Incident Snapshot */}
          <div className="p-2.5 rounded bg-[#102238] border border-[#203752] space-y-1">
            <div className="flex items-center justify-between text-[11px]">
              <span className="font-semibold text-[#F1F5F9]">{incidentContext.location}</span>
              <span className="text-[#8EA3BA]">{incidentContext.day}, {incidentContext.time}</span>
            </div>
            <div className="text-[11px] text-[#8EA3BA] flex items-center gap-2">
              <span className="text-[#2F80ED]">{incidentContext.weather}</span>
              <span>•</span>
              <span>{incidentContext.incident} ({incidentContext.severity})</span>
            </div>
            <div className="text-[11px] pt-1 text-[#F1F5F9] border-t border-[#203752]/60">
              Intervention applied: <span className="font-semibold text-[#2F80ED]">{incidentContext.intervention}</span>
            </div>
          </div>

          {/* Outcome Status Selector */}
          <div>
            <label className="block text-[11px] font-semibold text-[#8EA3BA] uppercase tracking-wider mb-1.5">
              Result of Intervention
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { status: 'Successful' as const, label: 'Successful', icon: CheckCircle2, color: 'border-[#20B77A] text-[#20B77A] bg-[#20B77A]/10' },
                { status: 'Partially successful' as const, label: 'Partial', icon: AlertTriangle, color: 'border-[#E8A52D] text-[#E8A52D] bg-[#E8A52D]/10' },
                { status: 'Failed' as const, label: 'Failed', icon: XCircle, color: 'border-[#EF5B5B] text-[#EF5B5B] bg-[#EF5B5B]/10' },
              ].map(opt => {
                const isSelected = outcome === opt.status;
                const Icon = opt.icon;
                return (
                  <button
                    key={opt.status}
                    type="button"
                    onClick={() => {
                      setOutcome(opt.status);
                      if (opt.status === 'Successful') {
                        setDelayAfter(10);
                        setNotes('Signal wave cleared the queue and restored arterial clearance quickly.');
                      } else if (opt.status === 'Failed') {
                        setDelayAfter(26);
                        setNotes('Intervention failed to relieve upstream blockage due to heavy bottlenecks.');
                      } else {
                        setDelayAfter(18);
                        setNotes('Partial clearance achieved on left turn; secondary queue remained.');
                      }
                    }}
                    className={`flex flex-col items-center justify-center p-2 rounded border cursor-pointer transition-all ${
                      isSelected
                        ? opt.color + ' ring-1 ring-white/20'
                        : 'border-[#203752] bg-[#102238] text-[#8EA3BA] hover:text-[#F1F5F9]'
                    }`}
                  >
                    <Icon className="w-4 h-4 mb-1" />
                    <span className="text-[11px] font-semibold">{opt.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Delay Metrics */}
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block text-[10px] uppercase font-semibold text-[#8EA3BA] mb-1">
                Delay Before (min)
              </label>
              <input
                type="number"
                min="0"
                max="120"
                value={delayBefore}
                onChange={(e) => setDelayBefore(Number(e.target.value))}
                className="w-full bg-[#102238] border border-[#203752] rounded px-2.5 py-1.5 text-xs text-[#F1F5F9] focus:outline-none focus:border-[#2F80ED]"
              />
            </div>
            <div>
              <label className="block text-[10px] uppercase font-semibold text-[#8EA3BA] mb-1">
                Delay After (min)
              </label>
              <input
                type="number"
                min="0"
                max="120"
                value={delayAfter}
                onChange={(e) => setDelayAfter(Number(e.target.value))}
                className="w-full bg-[#102238] border border-[#203752] rounded px-2.5 py-1.5 text-xs text-[#F1F5F9] focus:outline-none focus:border-[#2F80ED]"
              />
            </div>
          </div>

          {/* Field Notes */}
          <div>
            <label className="block text-[10px] uppercase font-semibold text-[#8EA3BA] mb-1">
              Field Notes / Observations
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Signal wave successfully cleared queue; no spillover observed."
              className="w-full bg-[#102238] border border-[#203752] rounded p-2 text-xs text-[#F1F5F9] focus:outline-none focus:border-[#2F80ED] resize-none"
            />
          </div>

          {/* Footer Action */}
          <div className="pt-2 flex items-center justify-end gap-2 border-t border-[#203752]">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 rounded border border-[#203752] text-[#8EA3BA] hover:text-[#F1F5F9] transition-colors cursor-pointer text-xs"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-4 py-1.5 rounded bg-[#8B6FE8] hover:bg-[#7859DF] text-white font-medium text-xs transition-colors flex items-center gap-1.5 cursor-pointer shadow-md"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isSaving ? 'Retaining Memory...' : 'Save & Retain Outcome'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
