import React from 'react';
import { SystemStats } from '../../types/traffic.ts';
import { 
  Cpu, 
  Database, 
  ArrowDown, 
  ArrowRight, 
  Sparkles, 
  CheckCircle2, 
  Activity, 
  Route, 
  Layers,
  ShieldCheck,
  Zap,
  GitBranch
} from 'lucide-react';

interface IntelligencePanelProps {
  stats: SystemStats | null;
}

export const IntelligencePanel: React.FC<IntelligencePanelProps> = ({ stats }) => {
  return (
    <div className="w-[340px] xl:w-[420px] bg-[#0B1929] border-l border-[#203752] flex flex-col justify-between h-full shrink-0 select-none overflow-y-auto z-20">
      <div className="p-4 space-y-4">
        {/* Header */}
        <div className="pb-3 border-b border-[#203752]">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded bg-[#2F80ED]/20 text-[#2F80ED] flex items-center justify-center">
                <Cpu className="w-4 h-4" />
              </div>
              <h2 className="text-sm font-bold tracking-tight text-[#F1F5F9]">Intelligence Architecture</h2>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#2F80ED]/15 text-[#2F80ED] border border-[#2F80ED]/30 font-semibold">
              HINDSIGHT CORE
            </span>
          </div>
          <p className="text-[11px] text-[#8EA3BA] mt-1">
            How persistent episodic traffic memory turns past road failures into future precision.
          </p>
        </div>

        {/* Live Engine Telemetry */}
        <div className="p-3 rounded-lg bg-[#081522] border border-[#203752] space-y-2">
          <div className="flex items-center justify-between text-[11px]">
            <span className="font-bold text-[#8EA3BA] uppercase tracking-wider">Engine State</span>
            <span className="flex items-center gap-1.5 text-[#20B77A] font-semibold text-[10px]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#20B77A] animate-pulse"></span>
              {stats?.hindsightConnected ? 'Hindsight Live Vector Store' : 'Active In-Process Store'}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-2 rounded bg-[#102238] border border-[#203752]/70">
              <div className="text-[9px] text-[#8EA3BA] uppercase">Retain Operations</div>
              <div className="text-sm font-bold text-[#8B6FE8] font-mono mt-0.5">
                {stats?.memoryRetainCount || 0} calls
              </div>
            </div>
            <div className="p-2 rounded bg-[#102238] border border-[#203752]/70">
              <div className="text-[9px] text-[#8EA3BA] uppercase">Recall Inferences</div>
              <div className="text-sm font-bold text-[#2F80ED] font-mono mt-0.5">
                {stats?.memoryRecallCount || 0} queries
              </div>
            </div>
          </div>
        </div>

        {/* The Core Intelligence Loop Visualization */}
        <div className="space-y-2">
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#8EA3BA]">
            Autonomous Memory Feedback Loop
          </span>

          <div className="p-3 rounded-lg bg-[#081522] border border-[#203752] space-y-2 text-xs">
            {/* Step 1: Current Event */}
            <div className="p-2 rounded bg-[#102238] border border-[#203752] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 rounded bg-[#EF5B5B]/20 text-[#EF5B5B] flex items-center justify-center font-bold text-[10px]">1</span>
                <div>
                  <div className="font-semibold text-[#F1F5F9] text-[11px]">Traffic / Emergency Event</div>
                  <div className="text-[9px] text-[#8EA3BA]">Real-time corridor shock detection</div>
                </div>
              </div>
            </div>

            <div className="flex justify-center text-[#2F80ED]">
              <ArrowDown className="w-3.5 h-3.5" />
            </div>

            {/* Step 2: Hindsight Recall */}
            <div className="p-2 rounded bg-[#102238] border border-[#8B6FE8]/50 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 rounded bg-[#8B6FE8]/20 text-[#8B6FE8] flex items-center justify-center font-bold text-[10px]">2</span>
                <div>
                  <div className="font-semibold text-[#8B6FE8] text-[11px]">Hindsight Episodic Recall</div>
                  <div className="text-[9px] text-[#8EA3BA]">Finds matching weather, time, geometry & incident patterns</div>
                </div>
              </div>
            </div>

            <div className="flex justify-center text-[#2F80ED]">
              <ArrowDown className="w-3.5 h-3.5" />
            </div>

            {/* Step 3: LLM Reasoning & Comparison */}
            <div className="p-2 rounded bg-[#102238] border border-[#203752] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 rounded bg-[#2F80ED]/20 text-[#2F80ED] flex items-center justify-center font-bold text-[10px]">3</span>
                <div>
                  <div className="font-semibold text-[#F1F5F9] text-[11px]">Outcome Comparison & Reasoning</div>
                  <div className="text-[9px] text-[#8EA3BA]">Evaluates signal vs diversion success ratios</div>
                </div>
              </div>
            </div>

            <div className="flex justify-center text-[#2F80ED]">
              <ArrowDown className="w-3.5 h-3.5" />
            </div>

            {/* Step 4: Recommendation & Operator Action */}
            <div className="p-2 rounded bg-[#102238] border border-[#20B77A]/50 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 rounded bg-[#20B77A]/20 text-[#20B77A] flex items-center justify-center font-bold text-[10px]">4</span>
                <div>
                  <div className="font-semibold text-[#20B77A] text-[11px]">Ground-Truth Action Implemented</div>
                  <div className="text-[9px] text-[#8EA3BA]">Operator executes highest-probability tactic</div>
                </div>
              </div>
            </div>

            <div className="flex justify-center text-[#8B6FE8]">
              <ArrowDown className="w-3.5 h-3.5" />
            </div>

            {/* Step 5: Hindsight Retain */}
            <div className="p-2 rounded bg-[#8B6FE8]/15 border border-[#8B6FE8] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 rounded bg-[#8B6FE8] text-white flex items-center justify-center font-bold text-[10px]">5</span>
                <div>
                  <div className="font-semibold text-[#F1F5F9] text-[11px]">Hindsight RETAIN Ground Truth</div>
                  <div className="text-[9px] text-[#8B6FE8]">New outcome stored → System gets smarter for next incident</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 4 Partitioned Memory Sub-Spaces */}
        <div className="space-y-2">
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#8EA3BA]">
            Persistent Memory Sub-Spaces
          </span>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-2.5 rounded bg-[#102238] border border-[#203752]">
              <div className="text-[#2F80ED] font-semibold text-[11px] mb-1">Event Memory</div>
              <p className="text-[10px] text-[#8EA3BA] leading-snug">
                Records multi-modal conditions: rainfall, road slope, vehicle volume & day-of-week surges.
              </p>
            </div>
            <div className="p-2.5 rounded bg-[#102238] border border-[#203752]">
              <div className="text-[#E8A52D] font-semibold text-[11px] mb-1">Intervention Memory</div>
              <p className="text-[10px] text-[#8EA3BA] leading-snug">
                Tracks specific actions: phase offset, green wave extension, and secondary diversion points.
              </p>
            </div>
            <div className="p-2.5 rounded bg-[#102238] border border-[#203752]">
              <div className="text-[#20B77A] font-semibold text-[11px] mb-1">Outcome Memory</div>
              <p className="text-[10px] text-[#8EA3BA] leading-snug">
                Quantifies clearance minutes gained vs secondary congestion triggered in adjacent zones.
              </p>
            </div>
            <div className="p-2.5 rounded bg-[#102238] border border-[#203752]">
              <div className="text-[#EF5B5B] font-semibold text-[11px] mb-1">Emergency Route Memory</div>
              <p className="text-[10px] text-[#8EA3BA] leading-snug">
                Preserves real-world hospital transit times across historical weather and rush-hour bottlenecks.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
