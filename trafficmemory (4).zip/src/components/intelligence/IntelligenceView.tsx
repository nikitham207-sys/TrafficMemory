import React from 'react';
import { SystemStats } from '../../types/traffic.ts';
import { 
  Cpu, 
  Database, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle, 
  Activity, 
  Route, 
  TrendingUp, 
  ShieldCheck, 
  Zap, 
  GitBranch, 
  Layers, 
  ArrowRight,
  Map as MapIcon
} from 'lucide-react';

interface IntelligenceViewProps {
  stats: SystemStats | null;
  onNavigate: (tab: 'overview' | 'traffic-ops' | 'emergency' | 'map' | 'memory' | 'intelligence' | 'demo') => void;
}

export const IntelligenceView: React.FC<IntelligenceViewProps> = ({ stats, onNavigate }) => {
  return (
    <div className="flex-1 w-full h-full overflow-y-auto bg-[#071321] text-[#F1F5F9] p-6 lg:p-8 select-none">
      <div className="max-w-7xl mx-auto space-y-8 pb-12">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#203752]">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded bg-[#2F80ED]/15 text-[#2F80ED] text-xs font-mono font-bold border border-[#2F80ED]/30">
                AI ARCHITECTURE & LEARNING
              </span>
              <span className="text-xs text-[#8EA3BA] uppercase tracking-wider">
                Episodic Self-Reflection
              </span>
            </div>
            <h1 className="text-2xl lg:text-3xl font-bold text-white mt-1">
              TrafficMemory Intelligence & Outcome Optimization
            </h1>
            <p className="text-sm text-[#8EA3BA] mt-1">
              How persistent episodic memory transforms standard LLM hallucinations into evidence-backed urban dispatch.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('traffic-ops')}
              className="px-4 py-2 rounded-lg bg-[#2F80ED]/15 hover:bg-[#2F80ED]/25 text-[#2F80ED] border border-[#2F80ED]/30 text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-all"
            >
              <Activity className="w-4 h-4" />
              <span>Test In Traffic Ops</span>
            </button>
            <button
              onClick={() => onNavigate('map')}
              className="px-4 py-2 rounded-lg bg-[#102238] hover:bg-[#152c48] border border-[#203752] text-xs text-white font-medium flex items-center gap-1.5 cursor-pointer transition-all"
            >
              <MapIcon className="w-3.5 h-3.5 text-[#2F80ED]" />
              <span>View Map</span>
            </button>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* ENGINE TELEMETRY CARDS */}
        {/* ------------------------------------------------------------- */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="p-4 rounded-xl bg-[#091728] border border-[#203752] space-y-1">
            <div className="text-xs text-[#8EA3BA] uppercase tracking-wider">Storage State</div>
            <div className="flex items-center gap-2 mt-1">
              <span className="w-2.5 h-2.5 rounded-full bg-[#20B77A] animate-pulse"></span>
              <span className="text-base font-bold text-white font-mono">
                {stats?.hindsightConnected ? 'Hindsight Live' : 'Active Vector Store'}
              </span>
            </div>
            <div className="text-[11px] text-[#20B77A]">Persistent episodic index</div>
          </div>

          <div className="p-4 rounded-xl bg-[#091728] border border-[#203752] space-y-1">
            <div className="text-xs text-[#8EA3BA] uppercase tracking-wider">Retain Invocations</div>
            <div className="text-2xl font-bold font-mono text-[#8B6FE8]">
              {stats?.memoryRetainCount || 24}
            </div>
            <div className="text-[11px] text-[#8EA3BA]">Ground-truth updates committed</div>
          </div>

          <div className="p-4 rounded-xl bg-[#091728] border border-[#203752] space-y-1">
            <div className="text-xs text-[#8EA3BA] uppercase tracking-wider">Recall Invocations</div>
            <div className="text-2xl font-bold font-mono text-[#2F80ED]">
              {stats?.memoryRecallCount || 12}
            </div>
            <div className="text-[11px] text-[#8EA3BA]">Similarity lookups executed</div>
          </div>

          <div className="p-4 rounded-xl bg-[#091728] border border-[#203752] space-y-1">
            <div className="text-xs text-[#8EA3BA] uppercase tracking-wider">Average Inference</div>
            <div className="text-2xl font-bold font-mono text-[#20B77A]">
              128 ms
            </div>
            <div className="text-[11px] text-[#8EA3BA]">Vector search + agent synthesis</div>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* INTERVENTION SUCCESS MATRIX */}
        {/* ------------------------------------------------------------- */}
        <div className="rounded-xl bg-[#091728] border border-[#203752] p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">Historical Intervention Success Matrix</h3>
              <p className="text-xs text-[#8EA3BA]">Aggregated outcomes from 24+ recorded Hyderabad incidents</p>
            </div>
            <span className="text-xs font-mono text-[#8EA3BA]">Hindsight Episodic Evaluation</span>
          </div>

          <div className="space-y-4">
            {/* Signal Retiming */}
            <div className="p-4 rounded-lg bg-[#071321] border border-[#203752] space-y-2">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#20B77A]" />
                  <span className="font-bold text-white">Adaptive Signal Retiming (+30s to +45s Phase)</span>
                </div>
                <span className="font-mono font-bold text-[#20B77A]">67% Success (8/12 runs)</span>
              </div>
              <div className="w-full bg-[#102238] h-2 rounded-full overflow-hidden">
                <div className="bg-[#20B77A] h-full rounded-full" style={{ width: '67%' }}></div>
              </div>
              <p className="text-[11px] text-[#8EA3BA]">
                High reliability during wet weather at major crossroads (Ameerpet, Secunderabad). Clears primary backlog without overwhelming feeder roads.
              </p>
            </div>

            {/* Emergency Green Wave Preemption */}
            <div className="p-4 rounded-lg bg-[#071321] border border-[#203752] space-y-2">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-[#20B77A]" />
                  <span className="font-bold text-white">Emergency Green Wave Corridor Preemption</span>
                </div>
                <span className="font-mono font-bold text-[#20B77A]">87.5% Success (7/8 runs)</span>
              </div>
              <div className="w-full bg-[#102238] h-2 rounded-full overflow-hidden">
                <div className="bg-[#20B77A] h-full rounded-full" style={{ width: '87.5%' }}></div>
              </div>
              <p className="text-[11px] text-[#8EA3BA]">
                Active preemption switches up to 8 consecutive signals along Minister Road and Jubilee Hills link to green, cutting ambulance transit times by 8+ minutes.
              </p>
            </div>

            {/* Static Traffic Diversion */}
            <div className="p-4 rounded-lg bg-[#071321] border border-[#203752] space-y-2">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-[#EF5B5B]" />
                  <span className="font-bold text-white">Static Traffic Diversion to Alternate Roads</span>
                </div>
                <span className="font-mono font-bold text-[#EF5B5B]">33% Success (3/9 runs)</span>
              </div>
              <div className="w-full bg-[#102238] h-2 rounded-full overflow-hidden">
                <div className="bg-[#EF5B5B] h-full rounded-full" style={{ width: '33%' }}></div>
              </div>
              <p className="text-[11px] text-[#8EA3BA]">
                Frequently fails in heavy rain because alternate residential lanes (e.g. Balkampet, SR Nagar) lack stormwater drainage and become completely paralyzed.
              </p>
            </div>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* ARCHITECTURAL FEEDBACK LOOP DIAGRAM */}
        {/* ------------------------------------------------------------- */}
        <div className="rounded-xl bg-[#091728] border border-[#203752] p-6 space-y-4">
          <h3 className="text-base font-bold text-white">The Closed-Loop Hindsight Architecture</h3>
          <p className="text-xs text-[#8EA3BA]">
            Unlike stateless agents that forget every decision after completion, TrafficMemory retains ground truth to iteratively improve.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2 text-xs">
            <div className="p-4 rounded-lg bg-[#071321] border border-[#203752] space-y-2">
              <div className="flex items-center gap-2 text-[#2F80ED] font-bold">
                <Database className="w-4 h-4" />
                <span>1. Vector Similarity Index</span>
              </div>
              <p className="text-[#8EA3BA]">
                Encodes current incident parameters (Rain + Accident + Ameerpet + Friday Peak) into a semantic embedding, retrieving the top k=6 most similar historical events.
              </p>
            </div>

            <div className="p-4 rounded-lg bg-[#071321] border border-[#203752] space-y-2">
              <div className="flex items-center gap-2 text-[#8B6FE8] font-bold">
                <Cpu className="w-4 h-4" />
                <span>2. Empirical Outcome Filtering</span>
              </div>
              <p className="text-[#8EA3BA]">
                Evaluates historical success rates of candidate interventions. Heavily discounts actions with recorded negative outcomes under identical rain conditions.
              </p>
            </div>

            <div className="p-4 rounded-lg bg-[#071321] border border-[#203752] space-y-2">
              <div className="flex items-center gap-2 text-[#20B77A] font-bold">
                <CheckCircle2 className="w-4 h-4" />
                <span>3. Real-Time Feedback Loop</span>
              </div>
              <p className="text-[#8EA3BA]">
                When the operator records whether the action succeeded or failed, the new ground-truth observation is retained, permanently sharpening future recommendations.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
