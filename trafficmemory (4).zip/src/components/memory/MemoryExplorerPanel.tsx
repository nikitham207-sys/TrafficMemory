import React, { useState } from 'react';
import { TrafficMemoryItem } from '../../types/traffic.ts';
import { 
  Database, 
  Search, 
  Filter, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Clock, 
  MapPin, 
  Calendar,
  Layers,
  Sparkles
} from 'lucide-react';

interface MemoryExplorerPanelProps {
  memories: TrafficMemoryItem[];
  selectedMemory: TrafficMemoryItem | null;
  onSelectMemory: (memory: TrafficMemoryItem) => void;
  totalCount: number;
}

export const MemoryExplorerPanel: React.FC<MemoryExplorerPanelProps> = ({
  memories,
  selectedMemory,
  onSelectMemory,
  totalCount
}) => {
  const [zoneFilter, setZoneFilter] = useState('All');
  const [outcomeFilter, setOutcomeFilter] = useState('All');
  const [incidentFilter, setIncidentFilter] = useState('All');
  const [search, setSearch] = useState('');

  const filtered = memories.filter(m => {
    if (zoneFilter !== 'All' && !m.zone.toLowerCase().includes(zoneFilter.toLowerCase())) return false;
    if (outcomeFilter !== 'All' && m.outcome !== outcomeFilter) return false;
    if (incidentFilter !== 'All' && m.incident !== incidentFilter) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return m.location.toLowerCase().includes(q) || m.context.toLowerCase().includes(q) || m.intervention.toLowerCase().includes(q);
    }
    return true;
  });

  const successfulCount = memories.filter(m => m.outcome === 'Successful').length;
  const successRate = totalCount > 0 ? Math.round((successfulCount / totalCount) * 100) : 0;

  return (
    <div className="w-[340px] xl:w-[400px] bg-[#0B1929] border-l border-[#203752] flex flex-col justify-between h-full shrink-0 select-none overflow-y-auto z-20">
      <div className="p-4 space-y-4">
        {/* Header */}
        <div className="pb-3 border-b border-[#203752]">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded bg-[#8B6FE8]/20 text-[#8B6FE8] flex items-center justify-center">
                <Database className="w-4 h-4" />
              </div>
              <h2 className="text-sm font-bold tracking-tight text-[#F1F5F9]">Memory Explorer</h2>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#8B6FE8]/15 text-[#8B6FE8] border border-[#8B6FE8]/30 font-semibold">
              {totalCount} MEMORIES
            </span>
          </div>
          <p className="text-[11px] text-[#8EA3BA] mt-1">
            Browse and audit persistent Hindsight traffic experiences across Hyderabad.
          </p>
        </div>

        {/* Top Stats Banner */}
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="p-2 rounded bg-[#081522] border border-[#203752]">
            <div className="text-[9px] uppercase text-[#8EA3BA]">Total Experiences</div>
            <div className="text-xs font-bold text-[#F1F5F9] font-mono mt-0.5">{totalCount}</div>
          </div>
          <div className="p-2 rounded bg-[#081522] border border-[#203752]">
            <div className="text-[9px] uppercase text-[#8EA3BA]">Resolved</div>
            <div className="text-xs font-bold text-[#20B77A] font-mono mt-0.5">{successfulCount}</div>
          </div>
          <div className="p-2 rounded bg-[#081522] border border-[#203752]">
            <div className="text-[9px] uppercase text-[#8EA3BA]">Efficacy</div>
            <div className="text-xs font-bold text-[#2F80ED] font-mono mt-0.5">{successRate}%</div>
          </div>
        </div>

        {/* Search & Filters */}
        <div className="space-y-2 bg-[#081522] p-2.5 rounded-lg border border-[#203752]">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-[#8EA3BA] absolute left-2.5 top-2.5 pointer-events-none" />
            <input
              type="text"
              placeholder="Filter by keyword or intervention..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-[#102238] border border-[#203752] rounded pl-8 pr-2.5 py-1.5 text-xs text-[#F1F5F9] focus:outline-none focus:border-[#2F80ED]"
            />
          </div>

          <div className="grid grid-cols-3 gap-1.5 text-[10px]">
            <select
              value={zoneFilter}
              onChange={(e) => setZoneFilter(e.target.value)}
              className="bg-[#102238] border border-[#203752] text-[#8EA3BA] rounded p-1 focus:outline-none"
            >
              <option value="All">All Zones</option>
              <option value="Secunderabad">Secunderabad</option>
              <option value="Begumpet">Begumpet</option>
              <option value="Ameerpet">Ameerpet</option>
              <option value="Banjara">Banjara Hills</option>
              <option value="HITEC">HITEC City</option>
            </select>

            <select
              value={incidentFilter}
              onChange={(e) => setIncidentFilter(e.target.value)}
              className="bg-[#102238] border border-[#203752] text-[#8EA3BA] rounded p-1 focus:outline-none"
            >
              <option value="All">All Incidents</option>
              <option value="Accident">Accident</option>
              <option value="Peak Congestion">Congestion</option>
              <option value="Waterlogging">Waterlogging</option>
              <option value="Signal Failure">Signal Fail</option>
              <option value="Construction">Construction</option>
            </select>

            <select
              value={outcomeFilter}
              onChange={(e) => setOutcomeFilter(e.target.value)}
              className="bg-[#102238] border border-[#203752] text-[#8EA3BA] rounded p-1 focus:outline-none"
            >
              <option value="All">All Outcomes</option>
              <option value="Successful">Successful</option>
              <option value="Partially successful">Partial</option>
              <option value="Failed">Failed</option>
            </select>
          </div>
        </div>

        {/* Selected Memory Inspection Detail Card */}
        {selectedMemory && (
          <div className="p-3 rounded-lg bg-[#102238] border-2 border-[#8B6FE8] space-y-2 shadow-lg">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-[#8B6FE8] uppercase flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" />
                Selected Ground Truth Memory
              </span>
              <span className={`px-1.5 py-0.2 rounded text-[10px] font-semibold ${
                selectedMemory.outcome === 'Successful' ? 'bg-[#20B77A]/20 text-[#20B77A]' :
                selectedMemory.outcome === 'Failed' ? 'bg-[#EF5B5B]/20 text-[#EF5B5B]' : 'bg-[#E8A52D]/20 text-[#E8A52D]'
              }`}>
                {selectedMemory.outcome}
              </span>
            </div>

            <div className="text-xs font-bold text-[#F1F5F9]">{selectedMemory.location}</div>
            <div className="text-[11px] text-[#8EA3BA] flex flex-wrap gap-1 items-center">
              <span>{selectedMemory.day}, {selectedMemory.time}</span>
              <span>•</span>
              <span className="text-[#2F80ED]">{selectedMemory.weather}</span>
              <span>•</span>
              <span>{selectedMemory.incident}</span>
            </div>

            <div className="p-2 rounded bg-[#081522] border border-[#203752] text-[11px] space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[#8EA3BA]">Intervention:</span>
                <span className="font-semibold text-[#F1F5F9]">{selectedMemory.intervention}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#8EA3BA]">Delay Metric:</span>
                <span className="font-mono text-[#20B77A]">
                  {selectedMemory.delayBeforeMin}m → {selectedMemory.delayAfterMin}m (-{selectedMemory.delayBeforeMin - selectedMemory.delayAfterMin}m)
                </span>
              </div>
            </div>

            <p className="text-[11px] text-[#8EA3BA] italic leading-relaxed">
              "{selectedMemory.context}"
            </p>
          </div>
        )}

        {/* Memories List */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-[#8EA3BA]">
            <span className="font-semibold uppercase tracking-wider text-[10px]">Historical Records ({filtered.length})</span>
            <span className="text-[10px]">Click to inspect</span>
          </div>

          <div className="space-y-1.5 max-h-[460px] overflow-y-auto pr-1">
            {filtered.map(mem => {
              const isSelected = selectedMemory?.id === mem.id;
              return (
                <div
                  key={mem.id}
                  onClick={() => onSelectMemory(mem)}
                  className={`p-2.5 rounded border text-xs cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-[#102238] border-[#8B6FE8] ring-1 ring-[#8B6FE8]'
                      : 'bg-[#081522] border-[#203752] hover:border-[#8EA3BA]/40'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold text-[#F1F5F9] truncate max-w-[190px]">{mem.location}</span>
                    <span className={`px-1.5 py-0.2 rounded text-[9px] font-semibold ${
                      mem.outcome === 'Successful' ? 'bg-[#20B77A]/20 text-[#20B77A]' :
                      mem.outcome === 'Failed' ? 'bg-[#EF5B5B]/20 text-[#EF5B5B]' : 'bg-[#E8A52D]/20 text-[#E8A52D]'
                    }`}>
                      {mem.outcome}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-[#8EA3BA]">
                    <span>{mem.day} · {mem.time} · {mem.weather}</span>
                    <span className="text-[#2F80ED] font-mono">{mem.delayBeforeMin}m → {mem.delayAfterMin}m</span>
                  </div>

                  <div className="mt-1 pt-1 border-t border-[#203752]/50 text-[10px] flex items-center justify-between text-[#8EA3BA]">
                    <span>Action: <strong className="text-[#F1F5F9]">{mem.intervention}</strong></span>
                    <span className="text-[#8B6FE8]">{mem.source.includes('Live') ? 'Live Retained' : 'Retained'}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
