import React, { useState } from 'react';
import { TrafficMemoryItem } from '../../types/traffic.ts';
import { 
  Database, 
  Search, 
  Filter, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Clock, 
  MapPin, 
  Calendar, 
  Sparkles, 
  ArrowRight, 
  Map as MapIcon,
  Compass,
  Layers,
  ChevronRight
} from 'lucide-react';

interface MemoryLocationsViewProps {
  memories: TrafficMemoryItem[];
  selectedMemory: TrafficMemoryItem | null;
  onSelectAndLocateOnMap: (memory: TrafficMemoryItem) => void;
  totalCount: number;
  onNavigate: (tab: 'overview' | 'traffic-ops' | 'emergency' | 'map' | 'memory' | 'intelligence' | 'demo') => void;
}

export const MemoryLocationsView: React.FC<MemoryLocationsViewProps> = ({
  memories,
  selectedMemory,
  onSelectAndLocateOnMap,
  totalCount,
  onNavigate
}) => {
  const [zoneFilter, setZoneFilter] = useState('All');
  const [outcomeFilter, setOutcomeFilter] = useState('All');
  const [incidentFilter, setIncidentFilter] = useState('All');
  const [search, setSearch] = useState('');

  const filtered = memories.filter(m => {
    if (zoneFilter !== 'All' && !m.zone.toLowerCase().includes(zoneFilter.toLowerCase())) return false;
    if (outcomeFilter !== 'All' && m.outcome !== outcomeFilter) return false;
    if (incidentFilter !== 'All' && m.incident !== incidentFilter) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        m.location.toLowerCase().includes(q) || 
        m.context.toLowerCase().includes(q) || 
        m.intervention.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const successfulCount = memories.filter(m => m.outcome === 'Successful').length;
  const successRate = totalCount > 0 ? Math.round((successfulCount / totalCount) * 100) : 0;

  return (
    <div className="flex-1 w-full h-full overflow-y-auto bg-[#071321] text-[#F1F5F9] p-6 lg:p-8 select-none">
      <div className="max-w-7xl mx-auto space-y-8 pb-12">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#203752]">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded bg-[#8B6FE8]/15 text-[#8B6FE8] text-xs font-mono font-bold border border-[#8B6FE8]/30">
                EPISODIC MEMORY DATABASE
              </span>
              <span className="text-xs text-[#8EA3BA] uppercase tracking-wider">
                Geographic Knowledge Base
              </span>
            </div>
            <h1 className="text-2xl lg:text-3xl font-bold text-white mt-1">
              Hyderabad Memory Locations & Learned Experiences
            </h1>
            <p className="text-sm text-[#8EA3BA] mt-1">
              Every card represents a real historical traffic intervention retained in Hindsight vector storage with its ground-truth outcome.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('map')}
              className="px-4 py-2 rounded-lg bg-[#102238] hover:bg-[#152c48] border border-[#203752] text-xs text-white font-medium flex items-center gap-1.5 cursor-pointer transition-all"
            >
              <MapIcon className="w-3.5 h-3.5 text-[#2F80ED]" />
              <span>View Map</span>
            </button>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* SUMMARY STATS CARDS */}
        {/* ------------------------------------------------------------- */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-4 rounded-xl bg-[#091728] border border-[#203752] space-y-1">
            <div className="text-xs text-[#8EA3BA]">Total Episodic Records</div>
            <div className="text-2xl font-bold font-mono text-[#8B6FE8]">{totalCount}</div>
            <div className="text-[11px] text-[#8EA3BA]">Persistent across restarts</div>
          </div>

          <div className="p-4 rounded-xl bg-[#091728] border border-[#203752] space-y-1">
            <div className="text-xs text-[#8EA3BA]">Overall Success Rate</div>
            <div className="text-2xl font-bold font-mono text-[#20B77A]">{successRate}%</div>
            <div className="text-[11px] text-[#20B77A]">{successfulCount} proven interventions</div>
          </div>

          <div className="p-4 rounded-xl bg-[#091728] border border-[#203752] space-y-1">
            <div className="text-xs text-[#8EA3BA]">Active Hotspot Locations</div>
            <div className="text-2xl font-bold font-mono text-white">8 Intersections</div>
            <div className="text-[11px] text-[#8EA3BA]">Ameerpet, HITEC, Secunderabad+</div>
          </div>

          <div className="p-4 rounded-xl bg-[#091728] border border-[#203752] space-y-1">
            <div className="text-xs text-[#8EA3BA]">Average Delay Saved</div>
            <div className="text-2xl font-bold font-mono text-[#E8A52D]">-18.4 min</div>
            <div className="text-[11px] text-[#8EA3BA]">During peak rush hours</div>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* FILTER & SEARCH TOOLBAR */}
        {/* ------------------------------------------------------------- */}
        <div className="p-4 rounded-xl bg-[#091728] border border-[#203752] flex flex-col md:flex-row items-center gap-4">
          {/* Search Input */}
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#8EA3BA]" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search memory records by location or intervention..."
              className="w-full pl-9 pr-3 py-2 rounded-lg bg-[#071321] border border-[#203752] text-white text-xs focus:border-[#8B6FE8] focus:outline-none"
            />
          </div>

          {/* Filters */}
          <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
            {/* Zone Filter */}
            <select
              value={zoneFilter}
              onChange={e => setZoneFilter(e.target.value)}
              className="px-3 py-2 rounded-lg bg-[#071321] border border-[#203752] text-xs text-white focus:outline-none"
            >
              <option value="All">All Zones</option>
              <option value="Ameerpet">Ameerpet</option>
              <option value="HITEC">HITEC City</option>
              <option value="Secunderabad">Secunderabad</option>
              <option value="Banjara">Banjara Hills</option>
              <option value="Begumpet">Begumpet</option>
            </select>

            {/* Outcome Filter */}
            <select
              value={outcomeFilter}
              onChange={e => setOutcomeFilter(e.target.value)}
              className="px-3 py-2 rounded-lg bg-[#071321] border border-[#203752] text-xs text-white focus:outline-none"
            >
              <option value="All">All Outcomes</option>
              <option value="Successful">Successful</option>
              <option value="Partially successful">Partially successful</option>
              <option value="Failed">Failed</option>
            </select>

            {/* Incident Filter */}
            <select
              value={incidentFilter}
              onChange={e => setIncidentFilter(e.target.value)}
              className="px-3 py-2 rounded-lg bg-[#071321] border border-[#203752] text-xs text-white focus:outline-none"
            >
              <option value="All">All Incidents</option>
              <option value="Accident">Accident</option>
              <option value="Waterlogging">Waterlogging</option>
              <option value="Peak Congestion">Peak Congestion</option>
            </select>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* MEMORY CARDS GRID */}
        {/* ------------------------------------------------------------- */}
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs text-[#8EA3BA]">
            <span>Showing {filtered.length} of {memories.length} historical experiences</span>
            <span>Click "Locate on Map" to open coordinates on the full map</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map(mem => {
              const isSelected = selectedMemory?.id === mem.id;
              const isSuccess = mem.outcome === 'Successful';
              const isPartial = mem.outcome === 'Partially successful';

              return (
                <div
                  key={mem.id}
                  className={`rounded-xl border p-5 flex flex-col justify-between transition-all space-y-4 ${
                    isSelected
                      ? 'bg-[#0e2136] border-[#8B6FE8] shadow-lg shadow-[#8B6FE8]/10'
                      : 'bg-[#091728] border-[#203752] hover:border-[#8B6FE8]/50'
                  }`}
                >
                  <div className="space-y-3">
                    {/* Header */}
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className={`w-2 h-2 rounded-full ${
                            isSuccess ? 'bg-[#20B77A]' : isPartial ? 'bg-[#E8A52D]' : 'bg-[#EF5B5B]'
                          }`}></span>
                          <span className="text-[10px] font-mono text-[#8EA3BA] uppercase">
                            {mem.zone}
                          </span>
                        </div>
                        <h4 className="font-bold text-white text-sm mt-0.5">{mem.location}</h4>
                      </div>

                      <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                        isSuccess
                          ? 'bg-[#20B77A]/20 text-[#20B77A] border border-[#20B77A]/30'
                          : isPartial
                          ? 'bg-[#E8A52D]/20 text-[#E8A52D] border border-[#E8A52D]/30'
                          : 'bg-[#EF5B5B]/20 text-[#EF5B5B] border border-[#EF5B5B]/30'
                      }`}>
                        {mem.outcome}
                      </span>
                    </div>

                    {/* Context & Weather */}
                    <div className="p-2.5 rounded-lg bg-[#071321] border border-[#203752] text-xs space-y-1">
                      <div className="flex justify-between text-[#8EA3BA]">
                        <span>Conditions:</span>
                        <strong className="text-white">{mem.day} · {mem.time}</strong>
                      </div>
                      <div className="flex justify-between text-[#8EA3BA]">
                        <span>Weather & Event:</span>
                        <span className="text-[#2F80ED] font-semibold">{mem.weather} · {mem.incident}</span>
                      </div>
                    </div>

                    {/* Action Taken */}
                    <div className="space-y-1">
                      <div className="text-[10px] font-bold text-[#8EA3BA] uppercase tracking-wider">
                        Action Taken:
                      </div>
                      <div className="text-xs font-semibold text-white">
                        {mem.intervention}
                      </div>
                      <div className="text-xs font-mono text-[#20B77A]">
                        {mem.delayBeforeMin} min delay → {mem.delayAfterMin} min delay ({mem.delayAfterMin - mem.delayBeforeMin} min)
                      </div>
                    </div>

                    {/* Context / Learning */}
                    <div className="p-3 rounded-lg bg-[#071321]/80 border border-[#203752]/70 text-xs text-[#8EA3BA] italic leading-relaxed">
                      "{mem.context}"
                    </div>
                  </div>

                  {/* Locate on Map Action */}
                  <div className="pt-2 border-t border-[#203752] flex items-center justify-between">
                    <span className="text-[10px] font-mono text-[#8EA3BA]">
                      {mem.coordinates[1].toFixed(4)}°N, {mem.coordinates[0].toFixed(4)}°E
                    </span>
                    <button
                      onClick={() => onSelectAndLocateOnMap(mem)}
                      className="px-3 py-1.5 rounded-lg bg-[#8B6FE8]/20 hover:bg-[#8B6FE8]/30 text-[#8B6FE8] border border-[#8B6FE8]/40 text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-all"
                    >
                      <MapPin className="w-3.5 h-3.5" />
                      <span>Locate on Map</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
