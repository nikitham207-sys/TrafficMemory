import React from 'react';
import { 
  Sparkles, 
  ArrowRight, 
  Activity, 
  Ambulance, 
  Database, 
  Cpu, 
  MapPin, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Clock, 
  Compass, 
  ShieldCheck, 
  TrendingUp, 
  Play,
  RotateCcw,
  Zap,
  Layers,
  Map as MapIcon
} from 'lucide-react';
import { SystemStats } from '../../types/traffic.ts';

interface OverviewViewProps {
  stats: SystemStats | null;
  onNavigate: (tab: 'overview' | 'traffic-ops' | 'emergency' | 'map' | 'memory' | 'intelligence' | 'demo') => void;
  onPlayAmeerpetScenario: () => void;
  onPlayEmergencyScenario: () => void;
}

export const OverviewView: React.FC<OverviewViewProps> = ({
  stats,
  onNavigate,
  onPlayAmeerpetScenario,
  onPlayEmergencyScenario
}) => {
  return (
    <div className="flex-1 w-full h-full overflow-y-auto bg-[#071321] text-[#F1F5F9] p-6 lg:p-8 select-none">
      <div className="max-w-7xl mx-auto space-y-8 pb-12">
        {/* Hero Section */}
        <div className="relative rounded-2xl bg-gradient-to-br from-[#0c2035] via-[#091726] to-[#06101c] border border-[#203752] p-6 lg:p-8 overflow-hidden shadow-xl">
          <div className="absolute -right-20 -top-20 w-80 h-80 bg-[#2F80ED]/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute right-10 bottom-0 w-60 h-60 bg-[#8B6FE8]/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="space-y-3 max-w-3xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#2F80ED]/15 border border-[#2F80ED]/30 text-[#2F80ED] text-xs font-semibold tracking-wide">
                <Sparkles className="w-3.5 h-3.5" />
                <span>HYDERABAD URBAN MOBILITY · HINDSIGHT EPISODIC REASONING</span>
              </div>
              <h1 className="text-3xl lg:text-4xl font-extrabold text-[#F1F5F9] tracking-tight leading-tight">
                TrafficMemory: An AI Agent that <span className="text-[#2F80ED]">remembers</span> what actually works on the road.
              </h1>
              <p className="text-sm lg:text-base text-[#8EA3BA] leading-relaxed">
                Standard traffic LLMs and heuristic routers guess in the dark, recommending generic diversions that worsen gridlock. 
                TrafficMemory uses <strong className="text-white font-semibold">Episodic Hindsight</strong> to recall past weather, accident, and intervention outcomes across Hyderabad — changing agent decisions based on proven historical success.
              </p>
            </div>

            {/* Quick Action Buttons */}
            <div className="flex flex-col sm:flex-row lg:flex-col gap-3 shrink-0">
              <button
                onClick={onPlayAmeerpetScenario}
                className="px-5 py-3 rounded-xl bg-gradient-to-r from-[#2F80ED] to-[#1E6FD9] hover:from-[#3a8bf0] hover:to-[#2277e3] text-white font-semibold text-sm shadow-lg shadow-[#2F80ED]/25 flex items-center justify-center gap-2 cursor-pointer transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>Play Live Ameerpet Demo</span>
              </button>
              <button
                onClick={() => onNavigate('map')}
                className="px-5 py-3 rounded-xl bg-[#102238] hover:bg-[#152c48] border border-[#203752] hover:border-[#2F80ED]/50 text-[#F1F5F9] font-medium text-sm flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <MapIcon className="w-4 h-4 text-[#2F80ED]" />
                <span>Open Full-Screen Map</span>
              </button>
            </div>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* STEP 6 — BEFORE vs AFTER (THE MAIN HACKATHON STORY) */}
        {/* ------------------------------------------------------------- */}
        <div className="rounded-2xl bg-[#091728] border-2 border-[#2F80ED]/40 p-6 lg:p-8 space-y-6 shadow-2xl relative">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-4 border-b border-[#203752]">
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 rounded bg-[#E8A52D]/20 text-[#E8A52D] text-xs font-mono font-bold tracking-wider border border-[#E8A52D]/30">
                  STEP 6 — PROVEN CORE VALUE
                </span>
                <span className="text-xs font-semibold text-[#8EA3BA] uppercase tracking-wider">
                  The Hackathon Story
                </span>
              </div>
              <h2 className="text-2xl font-bold text-white mt-1">
                Show a BEFORE vs AFTER: How Hindsight Transforms Agent Behavior
              </h2>
            </div>
            <button
              onClick={onPlayAmeerpetScenario}
              className="px-4 py-2 rounded-lg bg-[#2F80ED]/20 hover:bg-[#2F80ED]/30 text-[#2F80ED] border border-[#2F80ED]/40 text-xs font-semibold flex items-center gap-2 cursor-pointer transition-all"
            >
              <span>Test This On Live Map</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* WITHOUT MEMORY (GENERIC AGENT) */}
            <div className="rounded-xl bg-[#0e1c2c] border border-[#EF5B5B]/40 p-6 space-y-4 relative flex flex-col justify-between">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-[#EF5B5B]/15 border border-[#EF5B5B]/30 flex items-center justify-center text-[#EF5B5B]">
                      <XCircle className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-xs font-mono font-bold text-[#EF5B5B] uppercase tracking-wider">
                        Without Memory
                      </span>
                      <h3 className="text-base font-bold text-white">Generic Traffic Agent</h3>
                    </div>
                  </div>
                  <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-[#EF5B5B]/10 text-[#EF5B5B] border border-[#EF5B5B]/20">
                    Standard LLM
                  </span>
                </div>

                {/* Scenario details */}
                <div className="p-3 rounded-lg bg-[#071321] border border-[#203752] space-y-1.5 text-xs">
                  <div className="flex justify-between text-[#8EA3BA]">
                    <span>Location:</span>
                    <strong className="text-white">Ameerpet Cross Roads</strong>
                  </div>
                  <div className="flex justify-between text-[#8EA3BA]">
                    <span>Conditions:</span>
                    <span className="text-[#EF5B5B] font-semibold">Rain + Accident (6:30 PM Peak)</span>
                  </div>
                </div>

                {/* Agent Response */}
                <div className="p-4 rounded-lg bg-[#142334] border border-[#EF5B5B]/30 space-y-2">
                  <div className="text-[11px] font-semibold text-[#8EA3BA] uppercase tracking-wider">
                    Agent Output:
                  </div>
                  <blockquote className="text-base italic text-white/90 border-l-2 border-[#EF5B5B] pl-3 py-1 font-serif">
                    "Consider signal retiming or diversion."
                  </blockquote>
                  <div className="text-xs text-[#EF5B5B] font-medium pt-1">
                    ⚠ Generic. No confidence. Does not know that diverting in heavy rain floods Balkampet road.
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-[#203752]/70 text-[11px] text-[#8EA3BA]">
                Outcome: Trial-and-error traffic management causing secondary bottleneck delays.
              </div>
            </div>

            {/* WITH TRAFFICMEMORY (HINDSIGHT-POWERED AGENT) */}
            <div className="rounded-xl bg-[#0e1c2c] border border-[#20B77A]/50 p-6 space-y-4 relative flex flex-col justify-between shadow-lg shadow-[#20B77A]/5">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-[#20B77A]/15 border border-[#20B77A]/30 flex items-center justify-center text-[#20B77A]">
                      <CheckCircle2 className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-xs font-mono font-bold text-[#20B77A] uppercase tracking-wider">
                        With TrafficMemory
                      </span>
                      <h3 className="text-base font-bold text-white">Hindsight Episodic Agent</h3>
                    </div>
                  </div>
                  <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-[#20B77A]/10 text-[#20B77A] border border-[#20B77A]/30 font-semibold">
                    6 Experiences Recalled
                  </span>
                </div>

                {/* Scenario details */}
                <div className="p-3 rounded-lg bg-[#071321] border border-[#203752] space-y-1.5 text-xs">
                  <div className="flex justify-between text-[#8EA3BA]">
                    <span>Location:</span>
                    <strong className="text-white">Ameerpet Cross Roads</strong>
                  </div>
                  <div className="flex justify-between text-[#8EA3BA]">
                    <span>Conditions:</span>
                    <span className="text-[#20B77A] font-semibold">Rain + Accident (6:30 PM Peak)</span>
                  </div>
                </div>

                {/* Historical Experience Recall Matrix */}
                <div className="p-4 rounded-lg bg-[#142334] border border-[#20B77A]/40 space-y-3">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-semibold text-[#8EA3BA] uppercase tracking-wider">
                      Recalled Historical Outcomes:
                    </span>
                    <span className="text-[#8B6FE8] font-mono font-semibold">Vector Memory</span>
                  </div>

                  <div className="space-y-2 text-xs">
                    <div className="flex items-center justify-between p-2 rounded bg-[#091728] border border-[#20B77A]/30">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-[#20B77A]" />
                        <span className="font-medium text-white">Signal retiming</span>
                      </div>
                      <span className="font-mono font-bold text-[#20B77A]">
                        4/6 successful (67%)
                      </span>
                    </div>

                    <div className="flex items-center justify-between p-2 rounded bg-[#091728] border border-[#EF5B5B]/30">
                      <div className="flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 text-[#E8A52D]" />
                        <span className="font-medium text-white">Diversion</span>
                      </div>
                      <span className="font-mono font-bold text-[#EF5B5B]">
                        2/6 successful (33%)
                      </span>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-[#203752] flex items-center justify-between">
                    <span className="text-xs font-semibold text-[#8EA3BA]">Recommendation:</span>
                    <span className="text-xs font-bold font-mono px-2 py-1 rounded bg-[#20B77A]/20 text-[#20B77A] border border-[#20B77A]/40">
                      Signal retiming (+40s Green Extension)
                    </span>
                  </div>
                </div>
              </div>

              {/* The Core Pitch */}
              <div className="p-3 rounded-lg bg-[#2F80ED]/10 border border-[#2F80ED]/30 text-xs text-[#F1F5F9] leading-relaxed">
                <span className="font-bold text-[#2F80ED]">Now the reader understands: </span>
                Hindsight isn't just storing information. It changes the agent's behavior based on previous outcomes. 
                <span className="italic text-white"> That's your strongest story.</span>
              </div>
            </div>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* SYSTEM KPI CARDS */}
        {/* ------------------------------------------------------------- */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-4 rounded-xl bg-[#091728] border border-[#203752] space-y-1">
            <div className="flex items-center justify-between text-xs text-[#8EA3BA]">
              <span>Retained Memories</span>
              <Database className="w-4 h-4 text-[#8B6FE8]" />
            </div>
            <div className="text-2xl font-bold font-mono text-white">
              {stats?.totalMemories || 24}
            </div>
            <div className="text-[11px] text-[#20B77A]">Persistent episodic records</div>
          </div>

          <div className="p-4 rounded-xl bg-[#091728] border border-[#203752] space-y-1">
            <div className="flex items-center justify-between text-xs text-[#8EA3BA]">
              <span>Hyderabad Zones</span>
              <MapPin className="w-4 h-4 text-[#2F80ED]" />
            </div>
            <div className="text-2xl font-bold font-mono text-white">
              6
            </div>
            <div className="text-[11px] text-[#8EA3BA]">Ameerpet, HITEC, Secunderabad+</div>
          </div>

          <div className="p-4 rounded-xl bg-[#091728] border border-[#203752] space-y-1">
            <div className="flex items-center justify-between text-xs text-[#8EA3BA]">
              <span>Emergency Wave Rate</span>
              <Ambulance className="w-4 h-4 text-[#20B77A]" />
            </div>
            <div className="text-2xl font-bold font-mono text-[#20B77A]">
              87.5%
            </div>
            <div className="text-[11px] text-[#8EA3BA]">Critical on-time hospital arrivals</div>
          </div>

          <div className="p-4 rounded-xl bg-[#091728] border border-[#203752] space-y-1">
            <div className="flex items-center justify-between text-xs text-[#8EA3BA]">
              <span>Avg Delay Reduction</span>
              <TrendingUp className="w-4 h-4 text-[#E8A52D]" />
            </div>
            <div className="text-2xl font-bold font-mono text-[#E8A52D]">
              -18.4 min
            </div>
            <div className="text-[11px] text-[#8EA3BA]">Per congested arterial corridor</div>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* PAGES NAVIGATION CARDS */}
        {/* ------------------------------------------------------------- */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-white tracking-tight">
              Explore Dedicated Pages
            </h3>
            <span className="text-xs text-[#8EA3BA]">
              Click any section to inspect full specifications without clutter
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* Page: Traffic Conditions */}
            <div 
              onClick={() => onNavigate('traffic-ops')}
              className="group p-5 rounded-xl bg-[#091728] hover:bg-[#0c1f36] border border-[#203752] hover:border-[#2F80ED]/50 transition-all cursor-pointer space-y-3"
            >
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-lg bg-[#2F80ED]/15 text-[#2F80ED] flex items-center justify-center">
                  <Activity className="w-5 h-5" />
                </div>
                <span className="text-xs font-mono text-[#2F80ED] group-hover:translate-x-1 transition-transform flex items-center gap-1">
                  Open Page <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
              <div>
                <h4 className="font-bold text-white text-base">Traffic Conditions</h4>
                <p className="text-xs text-[#8EA3BA] mt-1 leading-relaxed">
                  Full specifications & features: simulate rain, accidents, weather choke points, and analyze with map generation.
                </p>
              </div>
              <div className="text-[11px] font-mono text-[#8EA3BA]/80 pt-2 border-t border-[#203752]">
                ⚡ Analyze button automatically triggers full map
              </div>
            </div>

            {/* Page: Emergency Routing */}
            <div 
              onClick={() => onNavigate('emergency')}
              className="group p-5 rounded-xl bg-[#091728] hover:bg-[#0c1f36] border border-[#203752] hover:border-[#EF5B5B]/50 transition-all cursor-pointer space-y-3"
            >
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-lg bg-[#EF5B5B]/15 text-[#EF5B5B] flex items-center justify-center">
                  <Ambulance className="w-5 h-5" />
                </div>
                <span className="text-xs font-mono text-[#EF5B5B] group-hover:translate-x-1 transition-transform flex items-center gap-1">
                  Open Page <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
              <div>
                <h4 className="font-bold text-white text-base">Emergency Corridors</h4>
                <p className="text-xs text-[#8EA3BA] mt-1 leading-relaxed">
                  Interlinked with live traffic ops: automatically discovers best routes avoiding choked corridors to major hospitals.
                </p>
              </div>
              <div className="text-[11px] font-mono text-[#8EA3BA]/80 pt-2 border-t border-[#203752]">
                🚑 Green wave preemption to Apollo, KIMS & NIMS
              </div>
            </div>

            {/* Page: Full Map View */}
            <div 
              onClick={() => onNavigate('map')}
              className="group p-5 rounded-xl bg-[#091728] hover:bg-[#0c1f36] border border-[#203752] hover:border-[#20B77A]/50 transition-all cursor-pointer space-y-3"
            >
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-lg bg-[#20B77A]/15 text-[#20B77A] flex items-center justify-center">
                  <MapIcon className="w-5 h-5" />
                </div>
                <span className="text-xs font-mono text-[#20B77A] group-hover:translate-x-1 transition-transform flex items-center gap-1">
                  Open Page <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
              <div>
                <h4 className="font-bold text-white text-base">Dedicated Map View</h4>
                <p className="text-xs text-[#8EA3BA] mt-1 leading-relaxed">
                  Full-screen un-cluttered Hyderabad map canvas with live incident markers, corridors, hospitals, and dynamic overlays.
                </p>
              </div>
              <div className="text-[11px] font-mono text-[#8EA3BA]/80 pt-2 border-t border-[#203752]">
                🗺 Zero sidebars crowding the screen
              </div>
            </div>

            {/* Page: Memory Locations */}
            <div 
              onClick={() => onNavigate('memory')}
              className="group p-5 rounded-xl bg-[#091728] hover:bg-[#0c1f36] border border-[#203752] hover:border-[#8B6FE8]/50 transition-all cursor-pointer space-y-3"
            >
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-lg bg-[#8B6FE8]/15 text-[#8B6FE8] flex items-center justify-center">
                  <Database className="w-5 h-5" />
                </div>
                <span className="text-xs font-mono text-[#8B6FE8] group-hover:translate-x-1 transition-transform flex items-center gap-1">
                  Open Page <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
              <div>
                <h4 className="font-bold text-white text-base">Memory Locations</h4>
                <p className="text-xs text-[#8EA3BA] mt-1 leading-relaxed">
                  Explore the 24+ retained incident memories across Hyderabad, outcomes, and locate them directly on the map.
                </p>
              </div>
              <div className="text-[11px] font-mono text-[#8EA3BA]/80 pt-2 border-t border-[#203752]">
                📍 Filter by zone, weather & outcome
              </div>
            </div>

            {/* Page: Intelligence & Reflection */}
            <div 
              onClick={() => onNavigate('intelligence')}
              className="group p-5 rounded-xl bg-[#091728] hover:bg-[#0c1f36] border border-[#203752] hover:border-[#2F80ED]/50 transition-all cursor-pointer space-y-3"
            >
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-lg bg-[#2F80ED]/15 text-[#2F80ED] flex items-center justify-center">
                  <Cpu className="w-5 h-5" />
                </div>
                <span className="text-xs font-mono text-[#2F80ED] group-hover:translate-x-1 transition-transform flex items-center gap-1">
                  Open Page <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
              <div>
                <h4 className="font-bold text-white text-base">Intelligence & Learning</h4>
                <p className="text-xs text-[#8EA3BA] mt-1 leading-relaxed">
                  Agent self-reflection metrics, intervention success curves, vector similarity, and adaptive policy evolution.
                </p>
              </div>
              <div className="text-[11px] font-mono text-[#8EA3BA]/80 pt-2 border-t border-[#203752]">
                🧠 Closed-loop retain & recall architecture
              </div>
            </div>

            {/* Page: Demo Scenarios */}
            <div 
              onClick={() => onNavigate('demo')}
              className="group p-5 rounded-xl bg-[#091728] hover:bg-[#0c1f36] border border-[#203752] hover:border-[#E8A52D]/50 transition-all cursor-pointer space-y-3"
            >
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-lg bg-[#E8A52D]/15 text-[#E8A52D] flex items-center justify-center">
                  <Play className="w-5 h-5" />
                </div>
                <span className="text-xs font-mono text-[#E8A52D] group-hover:translate-x-1 transition-transform flex items-center gap-1">
                  Open Page <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
              <div>
                <h4 className="font-bold text-white text-base">Demo Scenarios</h4>
                <p className="text-xs text-[#8EA3BA] mt-1 leading-relaxed">
                  3 ready-to-test hackathon scenarios with 1-click execution that directly transition to the live map.
                </p>
              </div>
              <div className="text-[11px] font-mono text-[#8EA3BA]/80 pt-2 border-t border-[#203752]">
                ▶ Ameerpet, Apollo Green Wave & Gachibowli
              </div>
            </div>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* HOW THE HINDSIGHT LOOP WORKS */}
        {/* ------------------------------------------------------------- */}
        <div className="rounded-xl bg-[#091728] border border-[#203752] p-6 space-y-4">
          <h3 className="text-base font-bold text-white">How the Hindsight Loop Operates in Real Time</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
            <div className="p-3.5 rounded-lg bg-[#071321] border border-[#203752] space-y-1.5">
              <div className="font-mono text-[#2F80ED] font-bold">01. INGEST INCIDENT</div>
              <p className="text-[#8EA3BA]">
                Detects weather (Rain), time (6:30 PM Friday peak), zone (Ameerpet), and severity.
              </p>
            </div>
            <div className="p-3.5 rounded-lg bg-[#071321] border border-[#203752] space-y-1.5">
              <div className="font-mono text-[#8B6FE8] font-bold">02. RECALL EXPERIENCES</div>
              <p className="text-[#8EA3BA]">
                Queries vector memory for matching conditions. Recalls 6 past similar events and their recorded outcomes.
              </p>
            </div>
            <div className="p-3.5 rounded-lg bg-[#071321] border border-[#203752] space-y-1.5">
              <div className="font-mono text-[#20B77A] font-bold">03. RECOMMEND PROVEN ACTION</div>
              <p className="text-[#8EA3BA]">
                Discards failed diversion attempts (33% success). Selects signal retiming (67% success).
              </p>
            </div>
            <div className="p-3.5 rounded-lg bg-[#071321] border border-[#203752] space-y-1.5">
              <div className="font-mono text-[#E8A52D] font-bold">04. RETAIN OUTCOME</div>
              <p className="text-[#8EA3BA]">
                Dispatcher records ground truth (Successful / Failed). New outcome is retained, permanently updating the agent.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
