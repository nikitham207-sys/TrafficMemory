import React from 'react';
import { Database, Activity, ShieldAlert, Cpu, Sparkles, RefreshCw, Ambulance, Map as MapIcon, Compass } from 'lucide-react';
import { SystemStats } from '../../types/traffic.ts';

export type NavTab = 'overview' | 'traffic-ops' | 'emergency' | 'map' | 'memory' | 'intelligence' | 'demo';

interface TopNavProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  stats?: SystemStats | null;
  onResetSeed?: () => void;
  isResetting?: boolean;
}

export const TopNav: React.FC<TopNavProps> = ({
  currentTab,
  onSelectTab,
  stats,
  onResetSeed,
  isResetting
}) => {
  const tabs: { id: NavTab; label: string; icon?: React.ComponentType<{ className?: string }> }[] = [
    { id: 'overview', label: 'OVERVIEW', icon: Compass },
    { id: 'traffic-ops', label: 'TRAFFIC CONDITIONS', icon: Activity },
    { id: 'emergency', label: 'EMERGENCY', icon: Ambulance },
    { id: 'map', label: 'MAP VIEW', icon: MapIcon },
    { id: 'memory', label: 'MEMORY LOCATIONS', icon: Database },
    { id: 'intelligence', label: 'INTELLIGENCE', icon: Cpu },
    { id: 'demo', label: 'DEMO', icon: Sparkles },
  ];

  return (
    <header className="h-16 w-full bg-[#081522] border-b border-[#203752] flex items-center justify-between px-5 select-none shrink-0 z-30">
      {/* Brand & Subtitle */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => onSelectTab('overview')}>
          <div className="w-8 h-8 rounded bg-[#102238] border border-[#2F80ED]/40 flex items-center justify-center text-[#2F80ED] shadow-sm">
            <Cpu className="w-4 h-4 stroke-[2.2]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-base tracking-tight text-[#F1F5F9]">TrafficMemory</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded font-mono font-semibold bg-[#2F80ED]/15 text-[#2F80ED] border border-[#2F80ED]/30">
                v1.0 HYD
              </span>
            </div>
            <p className="text-[11px] text-[#8EA3BA] leading-none hidden xl:block">
              An AI agent that remembers what actually works on the road.
            </p>
          </div>
        </div>
      </div>

      {/* Center Navigation Tabs */}
      <nav className="flex items-center gap-1 bg-[#071321] p-1 rounded-lg border border-[#203752] overflow-x-auto">
        {tabs.map((tab) => {
          const isActive = currentTab === tab.id;
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              className={`px-3 py-1.5 text-xs font-semibold tracking-wider rounded-md transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                isActive
                  ? 'bg-[#2F80ED] text-white shadow-md'
                  : 'text-[#8EA3BA] hover:text-[#F1F5F9] hover:bg-[#102238]/60'
              }`}
            >
              {Icon && <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : 'text-[#8EA3BA]'}`} />}
              <span>{tab.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Right Badges & Controls */}
      <div className="flex items-center gap-2.5">
        {/* Synthetic Data Disclaimer Badge */}
        <div className="hidden 2xl:flex items-center gap-1.5 px-2.5 py-1 bg-[#102238] border border-[#203752] rounded text-[11px] text-[#8EA3BA]">
          <span className="w-1.5 h-1.5 rounded-full bg-[#E8A52D]"></span>
          <span>DEMO MEMORY</span>
          <span className="text-[#8EA3BA]/50">|</span>
          <span className="text-[10px]">Hyderabad Metro</span>
        </div>

        {/* Memory Status Badge */}
        <div className="flex items-center gap-1.5 px-2.5 py-1 bg-[#102238] border border-[#203752] rounded text-[11px] font-mono">
          <span className={`w-2 h-2 rounded-full ${stats?.hindsightConnected ? 'bg-[#20B77A]' : 'bg-[#8B6FE8]'}`}></span>
          <span className="text-[#F1F5F9] font-medium hidden sm:inline">
            {stats?.hindsightConnected ? 'HINDSIGHT LIVE' : 'VECTOR MEMORY'}
          </span>
          {stats && (
            <span className="text-[10px] text-[#8B6FE8] bg-[#8B6FE8]/15 px-1.5 py-0.5 rounded border border-[#8B6FE8]/30 font-semibold">
              {stats.totalMemories} Stored
            </span>
          )}
        </div>

        {/* Reset Memory / Seed Button */}
        {onResetSeed && (
          <button
            onClick={onResetSeed}
            disabled={isResetting}
            title="Reset memory layer to default seed state"
            className="p-1.5 rounded bg-[#102238] border border-[#203752] hover:border-[#8EA3BA] text-[#8EA3BA] hover:text-[#F1F5F9] transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isResetting ? 'animate-spin text-[#2F80ED]' : ''}`} />
          </button>
        )}
      </div>
    </header>
  );
};
