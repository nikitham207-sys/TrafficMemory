import React from 'react';
import { ZoneInfo } from '../../types/traffic.ts';
import { 
  Compass, 
  Layers, 
  MapPin, 
  AlertTriangle, 
  Cross, 
  Database, 
  Route, 
  CheckSquare, 
  Square, 
  Info,
  Activity
} from 'lucide-react';

interface SidebarProps {
  zones: ZoneInfo[];
  activeZoneId?: string;
  onSelectZone: (zone: ZoneInfo) => void;
  layers: {
    trafficFlow: boolean;
    incidents: boolean;
    hospitals: boolean;
    zones: boolean;
    memories: boolean;
    emergencyRoutes: boolean;
  };
  onToggleLayer: (layerKey: keyof SidebarProps['layers']) => void;
  onNavigateSection?: (section: string) => void;
  activeSection?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({
  zones,
  activeZoneId,
  onSelectZone,
  layers,
  onToggleLayer,
  onNavigateSection,
  activeSection = 'overview'
}) => {
  const quickSections = [
    { id: 'overview', label: 'Overview', icon: Compass },
    { id: 'traffic', label: 'Traffic Conditions', icon: Activity },
    { id: 'hospitals', label: 'Hospitals', icon: Cross },
    { id: 'incidents', label: 'Incidents', icon: AlertTriangle },
    { id: 'memories', label: 'Memory Locations', icon: Database },
    { id: 'routes', label: 'Emergency Routes', icon: Route },
  ];

  return (
    <aside className="w-[220px] bg-[#081522] border-r border-[#203752] flex flex-col justify-between shrink-0 select-none overflow-y-auto z-20">
      <div className="p-3.5 space-y-4">
        {/* City Title */}
        <div className="pb-3 border-b border-[#203752]">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold tracking-wider text-[#F1F5F9] uppercase">Hyderabad</span>
            <span className="w-2 h-2 rounded-full bg-[#20B77A] animate-pulse"></span>
          </div>
          <p className="text-[11px] text-[#8EA3BA]">Mobility Intelligence Network</p>
        </div>

        {/* Quick Views */}
        <div className="space-y-0.5">
          <span className="text-[10px] font-semibold uppercase tracking-wider text-[#8EA3BA]/80 px-2">Navigation</span>
          {quickSections.map(sec => {
            const Icon = sec.icon;
            const isCurrent = activeSection === sec.id;
            return (
              <button
                key={sec.id}
                onClick={() => onNavigateSection?.(sec.id)}
                className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded text-xs transition-colors cursor-pointer text-left ${
                  isCurrent
                    ? 'bg-[#102238] text-[#2F80ED] font-semibold border-l-2 border-[#2F80ED]'
                    : 'text-[#8EA3BA] hover:text-[#F1F5F9] hover:bg-[#102238]/50'
                }`}
              >
                <Icon className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">{sec.label}</span>
              </button>
            );
          })}
        </div>

        {/* Operational Zones List */}
        <div className="space-y-1 pt-1 border-t border-[#203752]/70">
          <div className="flex items-center justify-between px-2">
            <span className="text-[10px] font-semibold uppercase tracking-wider text-[#8EA3BA]/80">Operational Zones</span>
            <span className="text-[9px] text-[#2F80ED] font-mono">{zones.length}</span>
          </div>
          <div className="space-y-0.5">
            {zones.map(zone => {
              const isSelected = activeZoneId === zone.id;
              return (
                <button
                  key={zone.id}
                  onClick={() => onSelectZone(zone)}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded text-xs transition-all cursor-pointer text-left ${
                    isSelected
                      ? 'bg-[#102238] text-[#2F80ED] font-medium border border-[#2F80ED]/40'
                      : 'text-[#8EA3BA] hover:text-[#F1F5F9] hover:bg-[#102238]/50 border border-transparent'
                  }`}
                >
                  <span className="truncate">{zone.name}</span>
                  {zone.activeIncidentsCount > 0 && (
                    <span className="px-1 py-0.2 rounded text-[9px] bg-[#EF5B5B]/20 text-[#EF5B5B] font-mono">
                      {zone.activeIncidentsCount}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Map Layers Toggles */}
        <div className="space-y-1.5 pt-1 border-t border-[#203752]/70">
          <span className="text-[10px] font-semibold uppercase tracking-wider text-[#8EA3BA]/80 px-2">Map Layers</span>
          <div className="space-y-1">
            {[
              { key: 'trafficFlow' as const, label: 'Traffic Flow', color: '#20B77A' },
              { key: 'incidents' as const, label: 'Incidents', color: '#EF5B5B' },
              { key: 'hospitals' as const, label: 'Hospitals', color: '#20B77A' },
              { key: 'zones' as const, label: 'Operational Zones', color: '#2F80ED' },
              { key: 'memories' as const, label: 'Memory Locations', color: '#8B6FE8' },
              { key: 'emergencyRoutes' as const, label: 'Emergency Routes', color: '#E8A52D' },
            ].map(layer => {
              const enabled = layers[layer.key];
              return (
                <div
                  key={layer.key}
                  onClick={() => onToggleLayer(layer.key)}
                  className="flex items-center justify-between px-2.5 py-1 rounded text-xs text-[#8EA3BA] hover:text-[#F1F5F9] hover:bg-[#102238]/40 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: layer.color }}></span>
                    <span className="text-[11px]">{layer.label}</span>
                  </div>
                  {enabled ? (
                    <CheckSquare className="w-3.5 h-3.5 text-[#2F80ED]" />
                  ) : (
                    <Square className="w-3.5 h-3.5 text-[#203752]" />
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Footer Synthetic Disclaimer */}
      <div className="p-3 border-t border-[#203752] bg-[#071321]/60">
        <div className="flex items-start gap-1.5 text-[10px] text-[#8EA3BA]/80 leading-snug">
          <Info className="w-3.5 h-3.5 text-[#2F80ED] shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold text-[#8EA3BA] block">Synthetic traffic intelligence</span>
            Geographic map is for visualization only. Traffic data shown is synthetic.
          </div>
        </div>
      </div>
    </aside>
  );
};
