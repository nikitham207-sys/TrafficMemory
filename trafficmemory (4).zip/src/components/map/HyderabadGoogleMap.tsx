/// <reference types="@types/google.maps" />
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  APIProvider, 
  Map, 
  AdvancedMarker, 
  InfoWindow, 
  useMap 
} from '@vis.gl/react-google-maps';
import { 
  HospitalInfo, 
  IncidentMarker, 
  TrafficCorridor, 
  TrafficMemoryItem, 
  ZoneInfo, 
  EmergencyRouteOption 
} from '../../types/traffic.ts';
import { 
  AlertTriangle, 
  Cross, 
  Search, 
  Clock, 
  Sparkles,
  Flame,
  Activity,
  Sliders,
  Radio,
  Zap,
  CloudRain,
  Eye,
  EyeOff
} from 'lucide-react';

const GOOGLE_MAPS_API_KEY = 
  import.meta.env.VITE_GOOGLE_MAPS_API_KEY || 'AIzaSyA4FAoC8rTayxlyNix3XD12QOYafgZWkuI';

export interface HyderabadGoogleMapProps {
  zones: ZoneInfo[];
  hospitals: HospitalInfo[];
  incidents: IncidentMarker[];
  corridors: TrafficCorridor[];
  memories: TrafficMemoryItem[];
  emergencyRoutes?: EmergencyRouteOption[];
  activeZoneId?: string;
  selectedIncidentId?: string;
  selectedMemoryId?: string;
  layers: {
    trafficFlow: boolean;
    incidents: boolean;
    hospitals: boolean;
    zones: boolean;
    memories: boolean;
    emergencyRoutes: boolean;
  };
  onSelectIncident?: (incident: IncidentMarker) => void;
  onSelectHospital?: (hospital: HospitalInfo) => void;
  onSelectZone?: (zone: ZoneInfo) => void;
  onSelectMemory?: (memory: TrafficMemoryItem) => void;
  onAnalyzeIncident?: (incident: IncidentMarker) => void;
  focusedCoordinates?: [number, number] | null;
}

// Convert GeoJSON [lng, lat] to Google Maps LatLngLiteral
function toLatLng(coord: [number, number]): google.maps.LatLngLiteral {
  return { lat: coord[1], lng: coord[0] };
}

// Polyline component using Google Maps JS API
function GoogleMapPolyline({
  path,
  strokeColor,
  strokeOpacity = 0.9,
  strokeWeight = 4,
  zIndex = 1,
  onClick
}: {
  path: google.maps.LatLngLiteral[];
  strokeColor: string;
  strokeOpacity?: number;
  strokeWeight?: number;
  zIndex?: number;
  onClick?: () => void;
}) {
  const map = useMap();
  const polylineRef = useRef<google.maps.Polyline | null>(null);

  useEffect(() => {
    if (!map || typeof google === 'undefined' || !google.maps || !google.maps.Polyline) return;

    try {
      const polyline = new google.maps.Polyline({
        path,
        strokeColor,
        strokeOpacity,
        strokeWeight,
        zIndex,
        map
      });

      if (onClick) {
        polyline.addListener('click', onClick);
      }

      polylineRef.current = polyline;

      return () => {
        try {
          polyline.setMap(null);
        } catch {}
      };
    } catch (err) {
      console.warn('Polyline render skipped:', err);
    }
  }, [map, strokeColor, strokeOpacity, strokeWeight, zIndex, JSON.stringify(path)]);

  return null;
}

// Circle component for Zone Coverage visualization
function GoogleMapCircle({
  center,
  radius,
  fillColor,
  fillOpacity = 0.12,
  strokeColor,
  strokeOpacity = 0.5,
  strokeWeight = 1.5,
  zIndex = 1,
  onClick
}: {
  center: google.maps.LatLngLiteral;
  radius: number;
  fillColor: string;
  fillOpacity?: number;
  strokeColor: string;
  strokeOpacity?: number;
  strokeWeight?: number;
  zIndex?: number;
  onClick?: () => void;
}) {
  const map = useMap();

  useEffect(() => {
    if (!map || typeof google === 'undefined' || !google.maps || !google.maps.Circle) return;

    try {
      const circle = new google.maps.Circle({
        center,
        radius,
        fillColor,
        fillOpacity,
        strokeColor,
        strokeOpacity,
        strokeWeight,
        zIndex,
        map
      });

      if (onClick) {
        circle.addListener('click', onClick);
      }

      return () => {
        try {
          circle.setMap(null);
        } catch {}
      };
    } catch (err) {
      console.warn('Circle render skipped:', err);
    }
  }, [map, center.lat, center.lng, radius, fillColor, strokeColor, zIndex]);

  return null;
}

// Camera Controller for smooth panning and zooming
function MapCameraController({
  focusedCoordinates
}: {
  focusedCoordinates?: [number, number] | null;
}) {
  const map = useMap();

  useEffect(() => {
    if (!map || !focusedCoordinates) return;
    map.panTo(toLatLng(focusedCoordinates));
    map.setZoom(13.8);
  }, [map, focusedCoordinates]);

  return null;
}

// Dynamic Real-time Congestion Heatmap Overlay Component using Layered Thermal Density
function DynamicHeatmapLayer({
  corridors,
  incidents,
  enabled,
  radius = 36,
  opacity = 0.85,
  simMultiplier = 1.0,
  pulseTick = 0
}: {
  corridors: TrafficCorridor[];
  incidents: IncidentMarker[];
  enabled: boolean;
  radius?: number;
  opacity?: number;
  simMultiplier?: number;
  pulseTick?: number;
}) {
  if (!enabled) return null;

  // Pulse modulation: oscillation factor
  const pulseMod = 1 + Math.sin(pulseTick * 0.9) * 0.12;
  const effectiveRadius = radius * simMultiplier * pulseMod;

  const statusThermalColors = {
    Severe: '#EF5B5B',
    Heavy: '#E8A52D',
    Moderate: '#2F80ED',
    Smooth: '#20B77A'
  };

  return (
    <>
      {/* 1. BROAD THERMAL CORRIDOR GLOW BANDS */}
      {corridors.map((c) => {
        const path = c.coordinates.map(toLatLng);
        const color = statusThermalColors[c.status] || '#2F80ED';
        const weightFactor = c.status === 'Severe' ? 1.4 : c.status === 'Heavy' ? 1.1 : 0.8;

        return (
          <React.Fragment key={`thermal-corridor-${c.id}`}>
            {/* Outer soft dissipation halo */}
            <GoogleMapPolyline
              path={path}
              strokeColor={color}
              strokeOpacity={opacity * 0.18}
              strokeWeight={Math.round(effectiveRadius * 1.1 * weightFactor)}
              zIndex={1}
            />
            {/* Mid concentration thermal plume */}
            <GoogleMapPolyline
              path={path}
              strokeColor={color}
              strokeOpacity={opacity * 0.38}
              strokeWeight={Math.round(effectiveRadius * 0.55 * weightFactor)}
              zIndex={2}
            />
            {/* Core high-intensity congestion track */}
            <GoogleMapPolyline
              path={path}
              strokeColor={color}
              strokeOpacity={opacity * 0.75}
              strokeWeight={Math.round(Math.max(6, effectiveRadius * 0.22 * weightFactor))}
              zIndex={3}
            />
          </React.Fragment>
        );
      })}

      {/* 2. CONCENTRIC THERMAL CHOKE BLOBS AT INCIDENTS & JUNCTIONS */}
      {incidents.map((inc) => {
        const center = toLatLng(inc.coordinates);
        const isSevere = inc.severity === 'Severe';
        const baseRadiusMeters = (isSevere ? 1100 : 750) * (effectiveRadius / 36);
        const color = isSevere ? '#EF5B5B' : '#E8A52D';

        return (
          <React.Fragment key={`thermal-incident-${inc.id}`}>
            {/* Outer ambient thermal bloom */}
            <GoogleMapCircle
              center={center}
              radius={baseRadiusMeters * 1.5}
              fillColor={color}
              fillOpacity={opacity * 0.12}
              strokeColor={color}
              strokeOpacity={opacity * 0.25}
              strokeWeight={1}
              zIndex={2}
            />
            {/* Mid dense shock wave */}
            <GoogleMapCircle
              center={center}
              radius={baseRadiusMeters * 0.85}
              fillColor={color}
              fillOpacity={opacity * 0.25}
              strokeColor={color}
              strokeOpacity={opacity * 0.5}
              strokeWeight={1.5}
              zIndex={3}
            />
            {/* Core epicenter hot spot */}
            <GoogleMapCircle
              center={center}
              radius={baseRadiusMeters * 0.35}
              fillColor={color}
              fillOpacity={opacity * 0.45}
              strokeColor="#FFFFFF"
              strokeOpacity={opacity * 0.75}
              strokeWeight={2}
              zIndex={4}
            />
          </React.Fragment>
        );
      })}
    </>
  );
}

// Google Native Traffic Layer Component
function GoogleTrafficLayer({ enabled }: { enabled: boolean }) {
  const map = useMap();
  const layerRef = useRef<any>(null);

  useEffect(() => {
    if (!map || typeof google === 'undefined' || !google.maps || !google.maps.TrafficLayer || !enabled) {
      if (layerRef.current) {
        try {
          layerRef.current.setMap(null);
        } catch {}
        layerRef.current = null;
      }
      return;
    }

    try {
      const trafficLayer = new google.maps.TrafficLayer();
      trafficLayer.setMap(map);
      layerRef.current = trafficLayer;

      return () => {
        try {
          trafficLayer.setMap(null);
        } catch {}
        layerRef.current = null;
      };
    } catch (err) {
      console.warn('TrafficLayer initialization skipped:', err);
    }
  }, [map, enabled]);

  return null;
}

export const HyderabadGoogleMap: React.FC<HyderabadGoogleMapProps> = ({
  zones,
  hospitals,
  incidents,
  corridors,
  memories,
  emergencyRoutes,
  activeZoneId,
  selectedIncidentId,
  selectedMemoryId,
  layers,
  onSelectIncident,
  onSelectHospital,
  onSelectZone,
  onSelectMemory,
  onAnalyzeIncident,
  focusedCoordinates
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [mapTypeId, setMapTypeId] = useState<'roadmap' | 'satellite' | 'hybrid'>('roadmap');
  
  // Selected markers for InfoWindows
  const [activeIncidentPopup, setActiveIncidentPopup] = useState<IncidentMarker | null>(null);
  const [activeHospitalPopup, setActiveHospitalPopup] = useState<HospitalInfo | null>(null);
  const [activeMemoryPopup, setActiveMemoryPopup] = useState<TrafficMemoryItem | null>(null);

  // Dynamic Real-time Traffic Heatmap & Congestion Simulation State
  const [heatmapEnabled, setHeatmapEnabled] = useState(true);
  const [googleTrafficEnabled, setGoogleTrafficEnabled] = useState(false);
  const [heatmapRadius, setHeatmapRadius] = useState(38);
  const [heatmapOpacity, setHeatmapOpacity] = useState(0.85);
  const [simPreset, setSimPreset] = useState<'normal' | 'peak' | 'rain' | 'offpeak'>('peak');
  const [isSimulating, setIsSimulating] = useState(true);
  const [pulseTick, setPulseTick] = useState(0);
  const [showHeatmapControls, setShowHeatmapControls] = useState(false);

  // Real-time sensor pulse simulation interval
  useEffect(() => {
    if (!isSimulating) return;
    const interval = setInterval(() => {
      setPulseTick(p => p + 1);
    }, 2200);
    return () => clearInterval(interval);
  }, [isSimulating]);

  // Compute dynamic congestion multiplier from preset and sensor fluctuation
  const simMultiplier = useMemo(() => {
    const base = 
      simPreset === 'rain' ? 1.75 :
      simPreset === 'peak' ? 1.45 :
      simPreset === 'offpeak' ? 0.65 : 1.0;
    // Oscillate ±7% to simulate live vehicle flow
    const oscillation = Math.sin(pulseTick * 0.8) * 0.07;
    return base + oscillation;
  }, [simPreset, pulseTick]);

  // Sync external selection with popup
  useEffect(() => {
    if (selectedIncidentId) {
      const match = incidents.find(i => i.id === selectedIncidentId);
      if (match) setActiveIncidentPopup(match);
    }
  }, [selectedIncidentId, incidents]);

  useEffect(() => {
    if (selectedMemoryId) {
      const match = memories.find(m => m.id === selectedMemoryId);
      if (match) setActiveMemoryPopup(match);
    }
  }, [selectedMemoryId, memories]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    const q = searchQuery.toLowerCase();
    const matchedZone = zones.find(z => z.name.toLowerCase().includes(q) || z.corridors.some(c => c.toLowerCase().includes(q)));
    if (matchedZone) {
      onSelectZone?.(matchedZone);
      return;
    }

    const matchedHosp = hospitals.find(h => h.name.toLowerCase().includes(q));
    if (matchedHosp) {
      onSelectHospital?.(matchedHosp);
      return;
    }

    const matchedInc = incidents.find(i => i.location.toLowerCase().includes(q));
    if (matchedInc) {
      onSelectIncident?.(matchedInc);
      setActiveIncidentPopup(matchedInc);
    }
  };

  const statusColors = {
    Severe: '#EF5B5B',
    Heavy: '#E8A52D',
    Moderate: '#2F80ED',
    Smooth: '#20B77A'
  };

  return (
    <div className="relative w-full h-full bg-[#071321] overflow-hidden select-none">
      <APIProvider apiKey={GOOGLE_MAPS_API_KEY} libraries={['places', 'geometry', 'marker']}>
        <Map
          mapId="DEMO_MAP_ID"
          internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
          defaultCenter={{ lat: 17.4250, lng: 78.4700 }}
          defaultZoom={12.1}
          gestureHandling="greedy"
          disableDefaultUI={false}
          mapTypeId={mapTypeId}
          style={{ width: '100%', height: '100%' }}
        >
          <MapCameraController focusedCoordinates={focusedCoordinates} />

          {/* DYNAMIC REAL-TIME TRAFFIC CONGESTION HEATMAP OVERLAY */}
          <DynamicHeatmapLayer
            corridors={corridors}
            incidents={incidents}
            enabled={heatmapEnabled}
            radius={heatmapRadius}
            opacity={heatmapOpacity}
            simMultiplier={simMultiplier}
            pulseTick={pulseTick}
          />

          {/* GOOGLE MAPS NATIVE REAL-TIME TRAFFIC LAYER */}
          <GoogleTrafficLayer enabled={googleTrafficEnabled} />

          {/* 1. CONNECTED TRAFFIC CORRIDORS */}
          {layers.trafficFlow && corridors.map((corridor) => {
            const path = corridor.coordinates.map(toLatLng);
            const color = statusColors[corridor.status] || '#2F80ED';
            return (
              <React.Fragment key={corridor.id}>
                {/* Glow underlay */}
                <GoogleMapPolyline
                  path={path}
                  strokeColor={color}
                  strokeOpacity={0.25}
                  strokeWeight={9}
                  zIndex={2}
                />
                {/* Main arterial line */}
                <GoogleMapPolyline
                  path={path}
                  strokeColor={color}
                  strokeOpacity={0.9}
                  strokeWeight={4}
                  zIndex={3}
                />
              </React.Fragment>
            );
          })}

          {/* 2. CONNECTED EMERGENCY ROUTES */}
          {layers.emergencyRoutes && emergencyRoutes && emergencyRoutes.map((route) => {
            const path = route.coordinates.map(toLatLng);
            const isRec = route.isRecommended;
            return (
              <React.Fragment key={route.routeId}>
                {/* Glowing underlay for recommended path */}
                {isRec && (
                  <GoogleMapPolyline
                    path={path}
                    strokeColor="#20B77A"
                    strokeOpacity={0.35}
                    strokeWeight={11}
                    zIndex={5}
                  />
                )}
                <GoogleMapPolyline
                  path={path}
                  strokeColor={isRec ? '#20B77A' : '#EF5B5B'}
                  strokeOpacity={isRec ? 1.0 : 0.65}
                  strokeWeight={isRec ? 5 : 3}
                  zIndex={isRec ? 6 : 4}
                />
                {/* Waypoint Markers */}
                {path.map((pos, idx) => (
                  <AdvancedMarker
                    key={`${route.routeId}-pt-${idx}`}
                    position={pos}
                    zIndex={isRec ? 7 : 4}
                  >
                    <div 
                      className={`w-2.5 h-2.5 rounded-full border-2 ${
                        isRec ? 'bg-[#20B77A] border-white shadow-sm shadow-[#20B77A]' : 'bg-[#EF5B5B] border-[#0B1929]'
                      }`}
                      title={`${route.name} segment ${idx + 1}`}
                    />
                  </AdvancedMarker>
                ))}
              </React.Fragment>
            );
          })}

          {/* 3. OPERATIONAL ZONES (Connected Coverage Circles) */}
          {layers.zones && zones.map((zone) => {
            const isActive = zone.id === activeZoneId;
            return (
              <React.Fragment key={zone.id}>
                <GoogleMapCircle
                  center={toLatLng(zone.center)}
                  radius={1800}
                  fillColor={isActive ? '#2F80ED' : '#172B40'}
                  fillOpacity={isActive ? 0.18 : 0.08}
                  strokeColor={isActive ? '#2F80ED' : '#2A4360'}
                  strokeOpacity={isActive ? 0.8 : 0.4}
                  strokeWeight={isActive ? 2 : 1}
                  zIndex={1}
                  onClick={() => onSelectZone?.(zone)}
                />
                <AdvancedMarker
                  position={toLatLng(zone.center)}
                  zIndex={8}
                  onClick={() => onSelectZone?.(zone)}
                >
                  <div className={`px-2 py-0.5 rounded text-[10px] font-semibold border backdrop-blur-sm cursor-pointer transition-all ${
                    isActive 
                      ? 'bg-[#2F80ED] text-white border-white shadow-md' 
                      : 'bg-[#0B1929]/80 text-[#8EA3BA] border-[#203752] hover:border-[#2F80ED]'
                  }`}>
                    {zone.name}
                  </div>
                </AdvancedMarker>
              </React.Fragment>
            );
          })}

          {/* 4. ACTIVE INCIDENTS */}
          {layers.incidents && incidents.map((inc) => {
            const isSelected = inc.id === selectedIncidentId;
            const isSevere = inc.severity === 'Severe';
            return (
              <AdvancedMarker
                key={inc.id}
                position={toLatLng(inc.coordinates)}
                zIndex={isSelected ? 30 : 20}
                onClick={() => {
                  onSelectIncident?.(inc);
                  setActiveIncidentPopup(inc);
                }}
              >
                <div className={`relative flex items-center justify-center cursor-pointer transition-transform duration-150 ${
                  isSelected ? 'scale-125' : 'hover:scale-110'
                }`}>
                  {/* Outer pulse */}
                  <span className={`absolute w-8 h-8 rounded-full opacity-75 animate-ping ${
                    isSevere ? 'bg-[#EF5B5B]' : 'bg-[#E8A52D]'
                  }`} />
                  {/* Pin container */}
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center shadow-lg border-2 ${
                    isSevere 
                      ? 'bg-[#EF5B5B] border-white text-white' 
                      : 'bg-[#E8A52D] border-white text-[#071321]'
                  }`}>
                    <AlertTriangle className="w-4 h-4 fill-current stroke-current" />
                  </div>
                </div>
              </AdvancedMarker>
            );
          })}

          {/* 5. HOSPITALS & TRAUMA CENTERS */}
          {layers.hospitals && hospitals.map((hosp) => (
            <AdvancedMarker
              key={hosp.id}
              position={toLatLng(hosp.coordinates)}
              zIndex={15}
              onClick={() => {
                onSelectHospital?.(hosp);
                setActiveHospitalPopup(hosp);
              }}
            >
              <div className="flex items-center gap-1 bg-[#0B1929]/90 border border-[#203752] rounded-md px-1.5 py-0.5 shadow-md cursor-pointer hover:border-[#20B77A] transition-all">
                <div className="w-4 h-4 rounded bg-[#EF5B5B] flex items-center justify-center text-white">
                  <Cross className="w-2.5 h-2.5 fill-white stroke-white" />
                </div>
                <span className="text-[10px] text-[#F1F5F9] font-medium max-w-[80px] truncate">
                  {hosp.name.replace(' Hospitals', '').replace(' Hospital', '')}
                </span>
              </div>
            </AdvancedMarker>
          ))}

          {/* 6. HISTORICAL MEMORIES HOTSPOTS */}
          {layers.memories && memories.map((mem) => {
            const isSelected = mem.id === selectedMemoryId;
            const isSuccess = mem.success;
            return (
              <AdvancedMarker
                key={mem.id}
                position={toLatLng(mem.coordinates)}
                zIndex={isSelected ? 25 : 10}
                onClick={() => {
                  onSelectMemory?.(mem);
                  setActiveMemoryPopup(mem);
                }}
              >
                <div 
                  className={`w-3.5 h-3.5 rounded-full border-2 cursor-pointer transition-transform ${
                    isSuccess 
                      ? 'bg-[#8B6FE8] border-white' 
                      : 'bg-[#F2994A] border-white'
                  } ${isSelected ? 'scale-150 ring-2 ring-[#8B6FE8]' : 'hover:scale-125'}`}
                  title={`${mem.location} (${mem.intervention} -> ${mem.outcome})`}
                />
              </AdvancedMarker>
            );
          })}

          {/* INCIDENT INFO WINDOW */}
          {activeIncidentPopup && (
            <InfoWindow
              position={toLatLng(activeIncidentPopup.coordinates)}
              onCloseClick={() => setActiveIncidentPopup(null)}
              pixelOffset={[0, -20]}
            >
              <div className="bg-[#0B1929] text-[#F1F5F9] p-2.5 rounded-md min-w-[240px] max-w-[280px] font-sans">
                <div className="flex items-center justify-between mb-1.5">
                  <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                    activeIncidentPopup.severity === 'Severe' 
                      ? 'bg-[#EF5B5B]/20 text-[#EF5B5B] border border-[#EF5B5B]/30' 
                      : 'bg-[#E8A52D]/20 text-[#E8A52D] border border-[#E8A52D]/30'
                  }`}>
                    {activeIncidentPopup.severity.toUpperCase()} · {activeIncidentPopup.incident.toUpperCase()}
                  </span>
                  <span className="text-[11px] text-[#8EA3BA] flex items-center gap-1">
                    <Clock className="w-3 h-3" /> {activeIncidentPopup.similarMemoriesCount} memories
                  </span>
                </div>
                
                <h4 className="text-xs font-semibold text-white mb-1">
                  {activeIncidentPopup.location}
                </h4>
                <p className="text-[11px] text-[#8EA3BA] mb-2 leading-relaxed">
                  {activeIncidentPopup.description}
                </p>

                <div className="bg-[#102238] rounded p-1.5 mb-2 text-[10px] border border-[#203752]">
                  <span className="text-[#8EA3BA]">Best Historic Intervention: </span>
                  <span className="text-[#20B77A] font-semibold">{activeIncidentPopup.bestIntervention}</span>
                  <span className="text-[#8EA3BA] ml-1">({activeIncidentPopup.bestInterventionSuccessRatio})</span>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-[#203752]">
                  <span className="text-[10px] text-[#8EA3BA]">Connected to Hindsight</span>
                  <button
                    onClick={() => {
                      onAnalyzeIncident?.(activeIncidentPopup);
                      setActiveIncidentPopup(null);
                    }}
                    className="flex items-center gap-1 px-2.5 py-1 bg-[#2F80ED] hover:bg-[#2563EB] text-white text-[11px] font-medium rounded transition-colors"
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>Analyze Situation</span>
                  </button>
                </div>
              </div>
            </InfoWindow>
          )}

          {/* HOSPITAL INFO WINDOW */}
          {activeHospitalPopup && (
            <InfoWindow
              position={toLatLng(activeHospitalPopup.coordinates)}
              onCloseClick={() => setActiveHospitalPopup(null)}
              pixelOffset={[0, -15]}
            >
              <div className="bg-[#0B1929] text-[#F1F5F9] p-2.5 rounded-md min-w-[220px] font-sans">
                <div className="flex items-center gap-1.5 text-[#20B77A] text-[10px] font-bold mb-1">
                  <Cross className="w-3 h-3" />
                  <span>EMERGENCY TRAUMA FACILITY</span>
                </div>
                <h4 className="text-xs font-semibold text-white mb-1">
                  {activeHospitalPopup.name}
                </h4>
                <div className="text-[11px] text-[#8EA3BA] space-y-1 mb-2">
                  <div>Tier: <span className="text-[#F1F5F9] font-medium">{activeHospitalPopup.traumaLevel}</span></div>
                  <div>ICU Beds Available: <span className="text-[#20B77A] font-bold">{activeHospitalPopup.icuBedsAvailable}</span></div>
                  <div>Hotline: <span className="text-[#2F80ED] font-mono">{activeHospitalPopup.emergencyContact}</span></div>
                </div>
              </div>
            </InfoWindow>
          )}

          {/* MEMORY INFO WINDOW */}
          {activeMemoryPopup && (
            <InfoWindow
              position={toLatLng(activeMemoryPopup.coordinates)}
              onCloseClick={() => setActiveMemoryPopup(null)}
              pixelOffset={[0, -10]}
            >
              <div className="bg-[#0B1929] text-[#F1F5F9] p-2.5 rounded-md min-w-[240px] max-w-[290px] font-sans">
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                    activeMemoryPopup.success 
                      ? 'bg-[#20B77A]/20 text-[#20B77A]' 
                      : 'bg-[#EF5B5B]/20 text-[#EF5B5B]'
                  }`}>
                    {activeMemoryPopup.outcome.toUpperCase()} INTERVENTION
                  </span>
                  <span className="text-[10px] text-[#8EA3BA] font-mono">
                    {activeMemoryPopup.day} {activeMemoryPopup.time}
                  </span>
                </div>
                <h4 className="text-xs font-semibold text-white mb-1">
                  {activeMemoryPopup.location}
                </h4>
                <div className="text-[11px] text-[#8EA3BA] mb-2 leading-relaxed">
                  <span className="text-white font-medium">{activeMemoryPopup.intervention}</span>: {activeMemoryPopup.context}
                </div>
                <div className="flex items-center justify-between text-[11px] pt-1.5 border-t border-[#203752]">
                  <span className="text-[#8EA3BA]">Delay Impact:</span>
                  <span className="font-semibold text-white">
                    {activeMemoryPopup.delayBeforeMin}m → {activeMemoryPopup.delayAfterMin}m
                    <span className={activeMemoryPopup.delayAfterMin < activeMemoryPopup.delayBeforeMin ? 'text-[#20B77A] ml-1' : 'text-[#EF5B5B] ml-1'}>
                      ({activeMemoryPopup.delayAfterMin < activeMemoryPopup.delayBeforeMin ? '-' : '+'}
                      {Math.abs(activeMemoryPopup.delayBeforeMin - activeMemoryPopup.delayAfterMin)}m)
                    </span>
                  </span>
                </div>
              </div>
            </InfoWindow>
          )}
        </Map>
      </APIProvider>

      {/* TOP FLOATING SEARCH & MAP TYPE CONTROLS */}
      <div className="absolute top-4 left-4 right-4 z-10 flex items-center justify-between pointer-events-none">
        {/* Search Input */}
        <form onSubmit={handleSearch} className="pointer-events-auto flex items-center bg-[#0B1929]/95 backdrop-blur-md border border-[#203752] rounded-md px-3 py-1.5 w-76 shadow-xl">
          <Search className="w-4 h-4 text-[#8EA3BA] mr-2 shrink-0" />
          <input
            type="text"
            placeholder="Search Hyderabad junction, hospital, or zone..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-transparent text-xs text-[#F1F5F9] focus:outline-none placeholder:text-[#8EA3BA]/60"
          />
        </form>

        {/* Map Type Switcher & Live Coordinate Badge */}
        <div className="pointer-events-auto flex items-center gap-1.5 bg-[#0B1929]/95 backdrop-blur-md border border-[#203752] rounded-md p-1 shadow-xl">
          <div className="flex items-center rounded overflow-hidden border border-[#203752]/60 p-0.5">
            <button
              onClick={() => setMapTypeId('roadmap')}
              className={`px-2 py-0.5 text-[10px] font-medium rounded transition-colors ${
                mapTypeId === 'roadmap' ? 'bg-[#2F80ED] text-white' : 'text-[#8EA3BA] hover:text-white'
              }`}
            >
              Google Map
            </button>
            <button
              onClick={() => setMapTypeId('satellite')}
              className={`px-2 py-0.5 text-[10px] font-medium rounded transition-colors ${
                mapTypeId === 'satellite' ? 'bg-[#2F80ED] text-white' : 'text-[#8EA3BA] hover:text-white'
              }`}
            >
              Satellite
            </button>
            <button
              onClick={() => setMapTypeId('hybrid')}
              className={`px-2 py-0.5 text-[10px] font-medium rounded transition-colors ${
                mapTypeId === 'hybrid' ? 'bg-[#2F80ED] text-white' : 'text-[#8EA3BA] hover:text-white'
              }`}
            >
              Hybrid
            </button>
          </div>
          <span className="text-[10px] text-[#8EA3BA] px-2 font-mono hidden sm:inline-block">
            17.4250° N, 78.4700° E
          </span>
        </div>
      </div>

      {/* FLOATING TRAFFIC HEATMAP & SENSOR DOCK (Top-Right below Map Types) */}
      <div className="absolute top-16 right-4 z-10 pointer-events-auto flex flex-col items-end gap-2">
        <div className="bg-[#0B1929]/95 backdrop-blur-md border border-[#203752] rounded-lg p-2.5 shadow-2xl w-80 text-xs">
          {/* Header */}
          <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#203752]">
            <div className="flex items-center gap-1.5">
              <Flame className={`w-4 h-4 ${heatmapEnabled ? 'text-[#EF5B5B] animate-pulse' : 'text-[#8EA3BA]'}`} />
              <span className="font-semibold text-white">Dynamic Traffic Overlays</span>
            </div>
            <div className="flex items-center gap-1">
              <span className={`w-2 h-2 rounded-full ${isSimulating ? 'bg-[#20B77A] animate-ping' : 'bg-[#8EA3BA]'}`} />
              <span className="text-[10px] text-[#8EA3BA] font-mono">
                {isSimulating ? `LIVE ${(simMultiplier * 100).toFixed(0)}%` : 'PAUSED'}
              </span>
            </div>
          </div>

          {/* Layer Toggle Pills */}
          <div className="grid grid-cols-2 gap-1.5 mb-2.5">
            <button
              onClick={() => setHeatmapEnabled(!heatmapEnabled)}
              className={`flex items-center justify-between px-2.5 py-1.5 rounded-md border text-[11px] font-medium transition-all ${
                heatmapEnabled 
                  ? 'bg-[#EF5B5B]/15 border-[#EF5B5B]/50 text-white shadow-sm' 
                  : 'bg-[#102238] border-[#203752] text-[#8EA3BA] hover:text-white'
              }`}
            >
              <span className="flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 text-[#EF5B5B]" />
                <span>Congestion Heatmap</span>
              </span>
              <span className={`w-1.5 h-1.5 rounded-full ${heatmapEnabled ? 'bg-[#EF5B5B]' : 'bg-[#8EA3BA]/40'}`} />
            </button>

            <button
              onClick={() => setGoogleTrafficEnabled(!googleTrafficEnabled)}
              className={`flex items-center justify-between px-2.5 py-1.5 rounded-md border text-[11px] font-medium transition-all ${
                googleTrafficEnabled 
                  ? 'bg-[#2F80ED]/15 border-[#2F80ED]/50 text-white shadow-sm' 
                  : 'bg-[#102238] border-[#203752] text-[#8EA3BA] hover:text-white'
              }`}
            >
              <span className="flex items-center gap-1">
                <Activity className="w-3.5 h-3.5 text-[#2F80ED]" />
                <span>Google Traffic</span>
              </span>
              <span className={`w-1.5 h-1.5 rounded-full ${googleTrafficEnabled ? 'bg-[#2F80ED]' : 'bg-[#8EA3BA]/40'}`} />
            </button>
          </div>

          {/* Simulation Presets */}
          <div className="mb-2">
            <div className="flex items-center justify-between text-[10px] text-[#8EA3BA] mb-1">
              <span>Traffic Congestion Scenario:</span>
              <button 
                onClick={() => setShowHeatmapControls(!showHeatmapControls)}
                className="text-[#2F80ED] hover:underline flex items-center gap-0.5"
              >
                <Sliders className="w-2.5 h-2.5" />
                <span>{showHeatmapControls ? 'Hide Density' : 'Tune Density'}</span>
              </button>
            </div>
            <div className="grid grid-cols-4 gap-1">
              {[
                { id: 'peak', label: 'Peak Rush', icon: Zap },
                { id: 'rain', label: 'Monsoon', icon: CloudRain },
                { id: 'normal', label: 'Normal', icon: Activity },
                { id: 'offpeak', label: 'Off-Peak', icon: Clock }
              ].map(p => (
                <button
                  key={p.id}
                  onClick={() => setSimPreset(p.id as any)}
                  className={`px-1.5 py-1 rounded text-[10px] font-medium flex items-center justify-center gap-1 border transition-all ${
                    simPreset === p.id 
                      ? 'bg-[#2F80ED] text-white border-white shadow-sm' 
                      : 'bg-[#102238] text-[#8EA3BA] border-[#203752] hover:text-white hover:border-[#2F80ED]/50'
                  }`}
                >
                  <p.icon className="w-2.5 h-2.5" />
                  <span>{p.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Expandable Radius & Opacity Tuning */}
          {showHeatmapControls && (
            <div className="pt-2 border-t border-[#203752] space-y-2 text-[10px] text-[#8EA3BA]">
              <div>
                <div className="flex justify-between mb-0.5">
                  <span>Heatmap Radius</span>
                  <span className="font-mono text-white">{heatmapRadius}px</span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="60"
                  value={heatmapRadius}
                  onChange={(e) => setHeatmapRadius(Number(e.target.value))}
                  className="w-full accent-[#EF5B5B] h-1 bg-[#102238] rounded cursor-pointer"
                />
              </div>
              <div>
                <div className="flex justify-between mb-0.5">
                  <span>Heatmap Opacity</span>
                  <span className="font-mono text-white">{Math.round(heatmapOpacity * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0.3"
                  max="1.0"
                  step="0.05"
                  value={heatmapOpacity}
                  onChange={(e) => setHeatmapOpacity(Number(e.target.value))}
                  className="w-full accent-[#EF5B5B] h-1 bg-[#102238] rounded cursor-pointer"
                />
              </div>
            </div>
          )}

          {/* Simulation Pulse Status footer */}
          <div className="flex items-center justify-between pt-1.5 mt-1 border-t border-[#203752]/60 text-[10px] text-[#8EA3BA]">
            <span className="flex items-center gap-1">
              <Radio className="w-3 h-3 text-[#20B77A] animate-pulse" />
              <span>Sensors updating dynamically</span>
            </span>
            <button
              onClick={() => setIsSimulating(!isSimulating)}
              className="text-[#2F80ED] hover:text-white"
            >
              {isSimulating ? 'Pause Stream' : 'Resume'}
            </button>
          </div>
        </div>
      </div>

      {/* MAP LEGEND OVERLAY (Bottom-Left) */}
      <div className="absolute bottom-4 left-4 z-10 pointer-events-auto bg-[#0B1929]/95 backdrop-blur-md border border-[#203752] rounded-md p-2.5 shadow-xl flex items-center gap-3 text-[11px] text-[#8EA3BA]">
        <div className="flex items-center gap-1.5">
          <span className="w-3 h-1 rounded bg-[#20B77A]"></span>
          <span>Smooth</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-3 h-1 rounded bg-[#2F80ED]"></span>
          <span>Moderate</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-3 h-1 rounded bg-[#E8A52D]"></span>
          <span>Heavy</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-3 h-1 rounded bg-[#EF5B5B]"></span>
          <span>Severe Choke</span>
        </div>
        <div className="h-3 w-px bg-[#203752]"></div>
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-[#8B6FE8]"></span>
          <span>Memory Point</span>
        </div>
        {heatmapEnabled && (
          <>
            <div className="h-3 w-px bg-[#203752]"></div>
            <div className="flex items-center gap-1.5">
              <span className="w-10 h-2 rounded bg-gradient-to-r from-[#20B77A] via-[#E8A52D] to-[#EF5B5B]"></span>
              <span>Heatmap Density</span>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
