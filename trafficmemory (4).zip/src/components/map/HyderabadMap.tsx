import React, { useEffect, useRef, useState } from 'react';
import * as maplibregl from 'maplibre-gl';
import type { FeatureCollection } from 'geojson';
import { HospitalInfo, IncidentMarker, TrafficCorridor, TrafficMemoryItem, ZoneInfo, EmergencyRouteOption } from '../../types/traffic.ts';
import { AlertTriangle, Plus, Cross, Navigation, Layers, Search, MapPin, ZoomIn, ZoomOut, Compass } from 'lucide-react';

interface HyderabadMapProps {
  zones: ZoneInfo[];
  hospitals: HospitalInfo[];
  incidents: IncidentMarker[];
  corridors: TrafficCorridor[];
  memories: TrafficMemoryItem[];
  emergencyRoutes?: EmergencyRouteOption[];
  activeZoneId?: string;
  selectedIncidentId?: string;
  selectedMemoryId?: string;
  layers: {
    trafficFlow: boolean;
    incidents: boolean;
    hospitals: boolean;
    zones: boolean;
    memories: boolean;
    emergencyRoutes: boolean;
  };
  onSelectIncident?: (incident: IncidentMarker) => void;
  onSelectHospital?: (hospital: HospitalInfo) => void;
  onSelectZone?: (zone: ZoneInfo) => void;
  onSelectMemory?: (memory: TrafficMemoryItem) => void;
  onAnalyzeIncident?: (incident: IncidentMarker) => void;
  focusedCoordinates?: [number, number] | null;
}

export const HyderabadMap: React.FC<HyderabadMapProps> = ({
  zones,
  hospitals,
  incidents,
  corridors,
  memories,
  emergencyRoutes,
  activeZoneId,
  selectedIncidentId,
  selectedMemoryId,
  layers,
  onSelectIncident,
  onSelectHospital,
  onSelectZone,
  onSelectMemory,
  onAnalyzeIncident,
  focusedCoordinates
}) => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const mapRef = useRef<maplibregl.Map | null>(null);
  const markersRef = useRef<maplibregl.Marker[]>([]);
  const popupRef = useRef<maplibregl.Popup | null>(null);
  const [mapLoaded, setMapLoaded] = useState(false);
  const [mapError, setMapError] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Initialize MapLibre
  useEffect(() => {
    if (!mapContainer.current) return;

    try {
      // Explicitly set the worker URL to the local endpoint
      try {
        maplibregl.setWorkerUrl('/maplibre-gl-worker.mjs');
      } catch {
        // workerUrl already configured or in-flight
      }

      const map = new maplibregl.Map({
        container: mapContainer.current,
        style: {
          version: 8,
          sources: {
            'carto-dark': {
              type: 'raster',
              tiles: [
                'https://a.basemaps.cartocdn.com/rastertiles/dark_all/{z}/{x}/{y}.png',
                'https://b.basemaps.cartocdn.com/rastertiles/dark_all/{z}/{x}/{y}.png',
                'https://c.basemaps.cartocdn.com/rastertiles/dark_all/{z}/{x}/{y}.png'
              ],
              tileSize: 256,
              attribution: '&copy; CartoDB &copy; OpenStreetMap'
            }
          },
          layers: [
            {
              id: 'carto-dark-layer',
              type: 'raster',
              source: 'carto-dark',
              minzoom: 0,
              maxzoom: 19
            }
          ]
        },
        center: [78.4700, 17.4250], // Centered over Begumpet / Ameerpet / Hussain Sagar
        zoom: 12.1,
        attributionControl: false
      });

      map.addControl(new maplibregl.NavigationControl({ showCompass: false }), 'bottom-right');

      map.on('load', () => {
        mapRef.current = map;
        setMapLoaded(true);
      });

      // Avoid passing raw event 'e' to console because e.target contains a circular Map reference
      map.on('error', (e) => {
        const msg = (e && typeof e === 'object' && 'error' in e && (e as any).error?.message) 
          || (typeof e === 'string' ? e : 'Tile stream notification');
        console.warn('MapLibre notice:', msg);
      });

      return () => {
        map.remove();
        mapRef.current = null;
      };
    } catch (err: any) {
      console.error('Failed to initialize MapLibre:', err?.message || String(err));
      setMapError(true);
    }
  }, []);

  // Update map center when focusedCoordinates change
  useEffect(() => {
    if (mapRef.current && focusedCoordinates) {
      mapRef.current.flyTo({
        center: focusedCoordinates,
        zoom: 13.5,
        speed: 1.2,
        curve: 1.4,
        essential: true
      });
    }
  }, [focusedCoordinates]);

  // Update GeoJSON Layers for Corridors and Emergency Routes
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapLoaded) return;

    // Traffic Corridors Layer
    const corridorGeoJson: FeatureCollection = {
      type: 'FeatureCollection',
      features: layers.trafficFlow ? corridors.map(c => ({
        type: 'Feature',
        properties: {
          id: c.id,
          name: c.name,
          status: c.status,
          speed: c.currentSpeedKmh,
          color: c.status === 'Severe' ? '#EF5B5B' : c.status === 'Heavy' ? '#E8A52D' : c.status === 'Moderate' ? '#2F80ED' : '#20B77A'
        },
        geometry: {
          type: 'LineString',
          coordinates: c.coordinates
        }
      })) : []
    };

    if (map.getSource('traffic-corridors')) {
      (map.getSource('traffic-corridors') as maplibregl.GeoJSONSource).setData(corridorGeoJson);
    } else {
      map.addSource('traffic-corridors', {
        type: 'geojson',
        data: corridorGeoJson
      });

      map.addLayer({
        id: 'traffic-corridors-casing',
        type: 'line',
        source: 'traffic-corridors',
        layout: { 'line-join': 'round', 'line-cap': 'round' },
        paint: {
          'line-color': '#071321',
          'line-width': 7,
          'line-opacity': 0.8
        }
      });

      map.addLayer({
        id: 'traffic-corridors-lines',
        type: 'line',
        source: 'traffic-corridors',
        layout: { 'line-join': 'round', 'line-cap': 'round' },
        paint: {
          'line-color': ['get', 'color'],
          'line-width': 4,
          'line-opacity': 0.95
        }
      });
    }

    // Emergency Routes Layer
    const emergencyGeoJson: FeatureCollection = {
      type: 'FeatureCollection',
      features: (layers.emergencyRoutes && emergencyRoutes) ? emergencyRoutes.map(r => ({
        type: 'Feature',
        properties: {
          id: r.routeId,
          name: r.name,
          isRecommended: r.isRecommended,
          color: r.isRecommended ? '#20B77A' : '#EF5B5B',
          dash: r.isRecommended ? [1, 0] : [2, 2]
        },
        geometry: {
          type: 'LineString',
          coordinates: r.coordinates
        }
      })) : []
    };

    if (map.getSource('emergency-routes')) {
      (map.getSource('emergency-routes') as maplibregl.GeoJSONSource).setData(emergencyGeoJson);
    } else {
      map.addSource('emergency-routes', {
        type: 'geojson',
        data: emergencyGeoJson
      });

      map.addLayer({
        id: 'emergency-routes-casing',
        type: 'line',
        source: 'emergency-routes',
        layout: { 'line-join': 'round', 'line-cap': 'round' },
        paint: {
          'line-color': '#0B1929',
          'line-width': 8,
          'line-opacity': 0.9
        }
      });

      map.addLayer({
        id: 'emergency-routes-lines',
        type: 'line',
        source: 'emergency-routes',
        layout: { 'line-join': 'round', 'line-cap': 'round' },
        paint: {
          'line-color': ['get', 'color'],
          'line-width': 4.5,
          'line-dasharray': ['case', ['get', 'isRecommended'], ['literal', [1, 0]], ['literal', [2, 1.5]]]
        }
      });
    }
  }, [mapLoaded, layers.trafficFlow, layers.emergencyRoutes, corridors, emergencyRoutes]);

  // Update HTML Markers (Incidents, Hospitals, Zones, Memories)
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapLoaded) return;

    // Clear existing markers
    markersRef.current.forEach(m => m.remove());
    markersRef.current = [];

    // 1. Zone Center Markers
    if (layers.zones) {
      zones.forEach(zone => {
        const el = document.createElement('div');
        el.className = 'group cursor-pointer';
        const isSelected = activeZoneId === zone.id;
        el.innerHTML = `
          <div class="px-2 py-1 rounded text-[10px] font-semibold tracking-wider flex items-center gap-1 border transition-all ${
            isSelected 
              ? 'bg-[#2F80ED]/30 text-[#2F80ED] border-[#2F80ED]' 
              : 'bg-[#0B1929]/80 text-[#8EA3BA] border-[#203752] hover:border-[#2F80ED]/60 hover:text-white'
          }">
            <span class="w-1.5 h-1.5 rounded-full ${isSelected ? 'bg-[#2F80ED]' : 'bg-[#8EA3BA]'}"></span>
            ${zone.name.toUpperCase()}
          </div>
        `;
        el.addEventListener('click', (e) => {
          e.stopPropagation();
          onSelectZone?.(zone);
        });

        const marker = new maplibregl.Marker({ element: el })
          .setLngLat(zone.center)
          .addTo(map);
        markersRef.current.push(marker);
      });
    }

    // 2. Hospital Markers
    if (layers.hospitals) {
      hospitals.forEach(hosp => {
        const el = document.createElement('div');
        el.className = 'cursor-pointer transform hover:scale-110 transition-transform';
        el.innerHTML = `
          <div class="w-7 h-7 rounded-full bg-[#102238] border-2 border-[#20B77A] flex items-center justify-center shadow-lg text-[#20B77A]">
            <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24">
              <path d="M19 10.5h-5.5V5h-3v5.5H5v3h5.5V19h3v-5.5H19v-3z"/>
            </svg>
          </div>
        `;
        el.addEventListener('click', (e) => {
          e.stopPropagation();
          onSelectHospital?.(hosp);
        });

        const marker = new maplibregl.Marker({ element: el })
          .setLngLat(hosp.coordinates)
          .addTo(map);
        markersRef.current.push(marker);
      });
    }

    // 3. Incident Markers
    if (layers.incidents) {
      incidents.forEach(inc => {
        const el = document.createElement('div');
        el.className = 'cursor-pointer transform hover:scale-110 transition-transform';
        const isSelected = selectedIncidentId === inc.id;
        const color = inc.severity === 'Critical' ? '#EF5B5B' : inc.severity === 'Severe' ? '#E8A52D' : '#2F80ED';

        el.innerHTML = `
          <div class="relative flex items-center justify-center">
            <div class="w-7 h-7 rounded-full flex items-center justify-center border ${
              isSelected ? 'border-white bg-[#EF5B5B]' : 'border-[#203752] bg-[#102238]'
            } shadow-md" style="color: ${color}">
              <svg class="w-4 h-4 stroke-current stroke-2 fill-none" viewBox="0 0 24 24">
                <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
                <line x1="12" y1="9" x2="12" y2="13"/>
                <line x1="12" y1="17" x2="12.01" y2="17"/>
              </svg>
            </div>
            <span class="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full border border-[#071321]" style="background-color: ${color}"></span>
          </div>
        `;

        el.addEventListener('click', (e) => {
          e.stopPropagation();
          onSelectIncident?.(inc);

          // Show popup matching the reference screenshot:
          // AMEERPET
          // Accident · Severe · Friday, 6:30 PM · Rain
          // 6 similar memories
          // Best intervention: Signal retiming · 4 / 6 successful
          // [ Analyze ]
          if (popupRef.current) popupRef.current.remove();

          const popupHtml = document.createElement('div');
          popupHtml.className = 'w-64 text-xs font-sans space-y-2 p-1';
          popupHtml.innerHTML = `
            <div class="flex items-center justify-between border-b border-[#203752] pb-1.5">
              <span class="font-bold text-sm tracking-wide text-[#F1F5F9]">${inc.location.toUpperCase()}</span>
              <span class="px-1.5 py-0.5 rounded text-[10px] font-semibold ${
                inc.severity === 'Critical' ? 'bg-[#EF5B5B]/20 text-[#EF5B5B]' : 'bg-[#E8A52D]/20 text-[#E8A52D]'
              }">${inc.severity}</span>
            </div>
            <div class="text-[#8EA3BA] flex flex-wrap gap-1 items-center">
              <span>${inc.incident}</span>
              <span>•</span>
              <span>${inc.day}, ${inc.time}</span>
              <span>•</span>
              <span class="text-[#2F80ED]">${inc.weather}</span>
            </div>
            <div class="bg-[#102238] p-2 rounded border border-[#203752] space-y-1">
              <div class="text-[11px] text-[#8B6FE8] font-medium flex items-center justify-between">
                <span>Hindsight Recall</span>
                <span class="font-bold">${inc.similarMemoriesCount} similar memories</span>
              </div>
              <div class="text-[11px] text-[#F1F5F9]">
                Best: <span class="font-semibold text-[#20B77A]">${inc.bestIntervention}</span>
                <span class="text-[#8EA3BA] text-[10px] ml-1">(${inc.bestInterventionSuccessRatio})</span>
              </div>
            </div>
            <button id="btn-popup-analyze-${inc.id}" class="w-full mt-2 py-1.5 px-3 bg-[#2F80ED] hover:bg-[#2563EB] text-white font-medium text-xs rounded transition-colors flex items-center justify-center gap-1.5 cursor-pointer">
              <span>Analyze Situation</span>
              <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
            </button>
          `;

          const analyzeBtn = popupHtml.querySelector(`#btn-popup-analyze-${inc.id}`);
          if (analyzeBtn) {
            analyzeBtn.addEventListener('click', () => {
              onAnalyzeIncident?.(inc);
              popupRef.current?.remove();
            });
          }

          popupRef.current = new maplibregl.Popup({ offset: 18, closeButton: true })
            .setLngLat(inc.coordinates)
            .setDOMContent(popupHtml)
            .addTo(map);
        });

        const marker = new maplibregl.Marker({ element: el })
          .setLngLat(inc.coordinates)
          .addTo(map);
        markersRef.current.push(marker);
      });
    }

    // 4. Memory Markers (Purple indicators)
    if (layers.memories) {
      memories.slice(0, 30).forEach(mem => {
        const el = document.createElement('div');
        el.className = 'cursor-pointer transform hover:scale-125 transition-transform';
        const isSelected = selectedMemoryId === mem.id;
        el.innerHTML = `
          <div class="w-3 h-3 rounded-full ${isSelected ? 'bg-[#8B6FE8] ring-2 ring-white scale-125' : 'bg-[#8B6FE8]/70 border border-[#8B6FE8]'} shadow-sm"></div>
        `;
        el.addEventListener('click', (e) => {
          e.stopPropagation();
          onSelectMemory?.(mem);
        });

        const marker = new maplibregl.Marker({ element: el })
          .setLngLat(mem.coordinates)
          .addTo(map);
        markersRef.current.push(marker);
      });
    }
  }, [mapLoaded, layers, zones, hospitals, incidents, memories, activeZoneId, selectedIncidentId, selectedMemoryId]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim() || !mapRef.current) return;

    const query = searchQuery.toLowerCase();
    const matchedZone = zones.find(z => z.name.toLowerCase().includes(query) || z.corridors.some(c => c.toLowerCase().includes(query)));
    if (matchedZone) {
      mapRef.current.flyTo({ center: matchedZone.center, zoom: 13.5 });
      onSelectZone?.(matchedZone);
      return;
    }

    const matchedHosp = hospitals.find(h => h.name.toLowerCase().includes(query));
    if (matchedHosp) {
      mapRef.current.flyTo({ center: matchedHosp.coordinates, zoom: 14 });
      onSelectHospital?.(matchedHosp);
      return;
    }

    const matchedInc = incidents.find(i => i.location.toLowerCase().includes(query));
    if (matchedInc) {
      mapRef.current.flyTo({ center: matchedInc.coordinates, zoom: 14 });
      onSelectIncident?.(matchedInc);
    }
  };

  return (
    <div className="relative w-full h-full bg-[#071321] overflow-hidden select-none">
      {/* Map Container */}
      <div ref={mapContainer} className="w-full h-full" />

      {/* Map Error Fallback */}
      {mapError && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-[#071321]/95 text-[#F1F5F9] p-6 text-center">
          <div className="w-12 h-12 rounded-full bg-[#102238] border border-[#203752] flex items-center justify-center mb-3">
            <Compass className="w-6 h-6 text-[#2F80ED]" />
          </div>
          <h3 className="text-sm font-semibold mb-1">Hyderabad Mobility Network Visualization</h3>
          <p className="text-xs text-[#8EA3BA] max-w-md mb-4">
            WebGL acceleration initialized. If map canvas was interrupted in your browser session, reload to restore live tile streaming.
          </p>
          <button
            onClick={() => window.location.reload()}
            className="px-3 py-1.5 bg-[#2F80ED] hover:bg-[#2563EB] text-xs font-medium rounded text-white transition-colors"
          >
            Refresh Cartography Engine
          </button>
        </div>
      )}

      {/* Top Map Floating Bar: Search & Quick Layer Filters */}
      <div className="absolute top-4 left-4 right-4 z-10 flex items-center justify-between pointer-events-none">
        {/* Search Input */}
        <form onSubmit={handleSearch} className="pointer-events-auto flex items-center bg-[#0B1929]/90 backdrop-blur-sm border border-[#203752] rounded-md px-3 py-1.5 w-72 shadow-lg">
          <Search className="w-4 h-4 text-[#8EA3BA] mr-2 shrink-0" />
          <input
            type="text"
            placeholder="Search location in Hyderabad..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-transparent text-xs text-[#F1F5F9] focus:outline-none placeholder:text-[#8EA3BA]/60"
          />
        </form>

        {/* Quick Map Controls */}
        <div className="pointer-events-auto flex items-center gap-1.5 bg-[#0B1929]/90 backdrop-blur-sm border border-[#203752] rounded-md p-1 shadow-lg">
          <div className="px-2 py-1 text-[11px] text-[#8EA3BA] font-medium border-r border-[#203752] flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-[#20B77A]"></span>
            <span>HYD METRO</span>
          </div>
          <span className="text-[10px] text-[#8EA3BA] px-2 font-mono">17.4065° N, 78.4772° E</span>
        </div>
      </div>

      {/* Map Legend Overlay at Bottom-Left */}
      <div className="absolute bottom-4 left-4 z-10 pointer-events-auto bg-[#0B1929]/90 backdrop-blur-sm border border-[#203752] rounded-md p-2.5 shadow-lg flex items-center gap-3 text-[11px] text-[#8EA3BA]">
        <div className="flex items-center gap-1.5">
          <span className="w-3 h-1 rounded bg-[#20B77A]"></span>
          <span>Smooth</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-3 h-1 rounded bg-[#2F80ED]"></span>
          <span>Moderate</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-3 h-1 rounded bg-[#E8A52D]"></span>
          <span>Heavy</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-3 h-1 rounded bg-[#EF5B5B]"></span>
          <span>Severe</span>
        </div>
        <div className="h-3 w-px bg-[#203752]"></div>
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-[#8B6FE8]"></span>
          <span>Memory Point</span>
        </div>
      </div>
    </div>
  );
};
