import React, { useState } from 'react';
import { HyderabadGoogleMap } from './HyderabadGoogleMap.tsx';
import { 
  ZoneInfo, 
  HospitalInfo, 
  IncidentMarker, 
  TrafficCorridor, 
  TrafficMemoryItem, 
  EmergencyRouteOption,
  AnalyzeResponse,
  EmergencyAnalysisResponse,
  OutcomeStatus
} from '../../types/traffic.ts';
import { 
  ArrowLeft, 
  Layers, 
  Sparkles, 
  Ambulance, 
  Activity, 
  CheckCircle2, 
  AlertTriangle, 
  RotateCcw, 
  ChevronDown, 
  ChevronUp, 
  MapPin, 
  Compass, 
  Clock,
  ShieldCheck,
  SendHorizontal
} from 'lucide-react';
import { RecordOutcomeModal } from '../traffic/RecordOutcomeModal.tsx';

interface DedicatedMapViewProps {
  zones: ZoneInfo[];
  hospitals: HospitalInfo[];
  incidents: IncidentMarker[];
  corridors: TrafficCorridor[];
  memories: TrafficMemoryItem[];
  emergencyRoutes?: EmergencyRouteOption[];
  activeZoneId?: string;
  selectedIncidentId?: string;
  selectedMemoryId?: string;
  layers: {
    trafficFlow: boolean;
    incidents: boolean;
    hospitals: boolean;
    zones: boolean;
    memories: boolean;
    emergencyRoutes: boolean;
  };
  onToggleLayer: (layerKey: keyof DedicatedMapViewProps['layers']) => void;
  onSelectIncident: (inc: IncidentMarker) => void;
  onSelectZone: (zone: ZoneInfo) => void;
  onSelectMemory: (mem: TrafficMemoryItem) => void;
  focusedCoordinates: [number, number] | null;
  analysis: AnalyzeResponse | null;
  emergencyAnalysis: EmergencyAnalysisResponse | null;
  selectedEmergencyRoute: EmergencyRouteOption | null;
  onNavigate: (tab: 'overview' | 'traffic-ops' | 'emergency' | 'map' | 'memory' | 'intelligence' | 'demo') => void;
  onRecordOutcome: (data: {
    outcome: OutcomeStatus;
    notes: string;
    delayBeforeMin: number;
    delayAfterMin: number;
  }) => Promise<void>;
}

export const DedicatedMapView: React.FC<DedicatedMapViewProps> = ({
  zones,
  hospitals,
  incidents,
  corridors,
  memories,
  emergencyRoutes,
  activeZoneId,
  selectedIncidentId,
  selectedMemoryId,
  layers,
  onToggleLayer,
  onSelectIncident,
  onSelectZone,
  onSelectMemory,
  focusedCoordinates,
  analysis,
  emergencyAnalysis,
  selectedEmergencyRoute,
  onNavigate,
  onRecordOutcome
}) => {
  const [showLayersMenu, setShowLayersMenu] = useState(false);
  const [hudCollapsed, setHudCollapsed] = useState(false);
  const [isRecordModalOpen, setIsRecordModalOpen] = useState(false);
  const [isSavingRecord, setIsSavingRecord] = useState(false);

  const activeZone = zones.find(z => z.id === activeZoneId) || zones[0];

  const handleRecordSubmit = async (data: {
    outcome: OutcomeStatus;
    notes: string;
    delayBeforeMin: number;
    delayAfterMin: number;
  }) => {
    setIsSavingRecord(true);
    try {
      await onRecordOutcome(data);
      setIsRecordModalOpen(false);
    } finally {
      setIsSavingRecord(false);
    }
  };

  return (
    <div className="relative w-full h-full flex flex-col overflow-hidden bg-[#071321] select-none">
      {/* ------------------------------------------------------------- */}
      {/* FLOATING TOP NAVIGATION HUD */}
      {/* ------------------------------------------------------------- */}
      <div className="absolute top-4 left-4 right-4 z-20 pointer-events-none flex items-center justify-between gap-3">
        {/* Left: Back & Navigation */}
        <div className="pointer-events-auto flex items-center gap-2">
          <button
            onClick={() => onNavigate('traffic-ops')}
            className="px-3.5 py-2 rounded-xl bg-[#091728]/95 hover:bg-[#102238] border border-[#203752] text-xs font-semibold text-white shadow-xl flex items-center gap-1.5 cursor-pointer backdrop-blur-md transition-all"
          >
            <ArrowLeft className="w-4 h-4 text-[#2F80ED]" />
            <span>Traffic Conditions</span>
          </button>

          <button
            onClick={() => onNavigate('emergency')}
            className="px-3.5 py-2 rounded-xl bg-[#091728]/95 hover:bg-[#102238] border border-[#203752] text-xs font-semibold text-[#EF5B5B] shadow-xl flex items-center gap-1.5 cursor-pointer backdrop-blur-md transition-all"
          >
            <Ambulance className="w-4 h-4" />
            <span>Emergency Route</span>
          </button>

          {/* Active Focus Pill */}
          <div className="hidden md:flex items-center gap-2 px-3 py-2 rounded-xl bg-[#091728]/95 border border-[#203752] text-xs font-mono text-white shadow-xl backdrop-blur-md">
            <span className="w-2 h-2 rounded-full bg-[#20B77A] animate-pulse"></span>
            <span className="text-[#8EA3BA]">Active Focus:</span>
            <span className="font-semibold text-white">
              {analysis?.eventReceived?.location || activeZone?.name || 'Hyderabad Metro'}
            </span>
          </div>
        </div>

        {/* Right: Zone Switcher & Layers Toggle */}
        <div className="pointer-events-auto flex items-center gap-2">
          {/* Quick Zone Picker */}
          <div className="hidden lg:flex items-center gap-1 px-1.5 py-1 rounded-xl bg-[#091728]/95 border border-[#203752] shadow-xl backdrop-blur-md">
            {zones.map(z => {
              const isSelected = activeZoneId === z.id;
              return (
                <button
                  key={z.id}
                  onClick={() => onSelectZone(z)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#2F80ED] text-white shadow-sm font-semibold'
                      : 'text-[#8EA3BA] hover:text-white'
                  }`}
                >
                  {z.name}
                </button>
              );
            })}
          </div>

          {/* Layers Toggle Button */}
          <div className="relative">
            <button
              onClick={() => setShowLayersMenu(!showLayersMenu)}
              className="px-3.5 py-2 rounded-xl bg-[#091728]/95 hover:bg-[#102238] border border-[#203752] text-xs font-semibold text-white shadow-xl flex items-center gap-2 cursor-pointer backdrop-blur-md transition-all"
            >
              <Layers className="w-4 h-4 text-[#2F80ED]" />
              <span>Layers</span>
              <ChevronDown className="w-3.5 h-3.5 text-[#8EA3BA]" />
            </button>

            {/* Layers Dropdown */}
            {showLayersMenu && (
              <div className="absolute right-0 mt-2 w-56 rounded-xl bg-[#091728] border border-[#203752] shadow-2xl p-3 space-y-2 z-30">
                <div className="text-[10px] font-bold text-[#8EA3BA] uppercase tracking-wider px-1">
                  Toggle Map Layers
                </div>
                {(
                  [
                    { key: 'trafficFlow', label: 'Traffic Flow Artery' },
                    { key: 'incidents', label: 'Live Incident Markers' },
                    { key: 'hospitals', label: 'Trauma Centers' },
                    { key: 'zones', label: 'Zone Boundaries' },
                    { key: 'memories', label: 'Retained Memory Pins' },
                    { key: 'emergencyRoutes', label: 'Green Corridors' },
                  ] as { key: keyof DedicatedMapViewProps['layers']; label: string }[]
                ).map(item => (
                  <label
                    key={item.key}
                    className="flex items-center justify-between p-1.5 rounded-lg hover:bg-[#102238] text-xs text-white cursor-pointer"
                  >
                    <span>{item.label}</span>
                    <input
                      type="checkbox"
                      checked={layers[item.key]}
                      onChange={() => onToggleLayer(item.key)}
                      className="rounded accent-[#2F80ED] cursor-pointer"
                    />
                  </label>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* FULL SCREEN GOOGLE MAP CANVAS */}
      {/* ------------------------------------------------------------- */}
      <div className="flex-1 w-full h-full relative">
        <HyderabadGoogleMap
          zones={zones}
          hospitals={hospitals}
          incidents={incidents}
          corridors={corridors}
          memories={memories}
          emergencyRoutes={emergencyAnalysis?.routes || emergencyRoutes}
          activeZoneId={activeZoneId}
          selectedIncidentId={selectedIncidentId}
          selectedMemoryId={selectedMemoryId}
          layers={layers}
          onSelectIncident={onSelectIncident}
          onSelectZone={onSelectZone}
          onSelectMemory={onSelectMemory}
          focusedCoordinates={focusedCoordinates}
        />
      </div>

      {/* ------------------------------------------------------------- */}
      {/* FLOATING BOTTOM INTELLIGENCE / DISPATCH HUD */}
      {/* ------------------------------------------------------------- */}
      <div className="absolute bottom-4 left-4 right-4 z-20 pointer-events-none flex justify-center">
        <div className="pointer-events-auto max-w-4xl w-full rounded-2xl bg-[#091728]/95 border-2 border-[#203752] shadow-2xl backdrop-blur-md overflow-hidden transition-all">
          {/* Header of HUD */}
          <div className="px-5 py-2.5 bg-[#071321]/80 border-b border-[#203752] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#20B77A] animate-pulse"></span>
              <span className="text-xs font-mono font-bold text-white uppercase tracking-wider">
                {emergencyAnalysis
                  ? 'EMERGENCY DISPATCH CORRIDOR ACTIVE'
                  : analysis
                  ? 'HINDSIGHT TRAFFIC ANALYSIS ACTIVE'
                  : 'HYDERABAD METROPOLITAN TRAFFIC MAP'}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setHudCollapsed(!hudCollapsed)}
                className="p-1 rounded text-[#8EA3BA] hover:text-white cursor-pointer"
                title={hudCollapsed ? 'Expand HUD' : 'Collapse HUD'}
              >
                {hudCollapsed ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Body of HUD */}
          {!hudCollapsed && (
            <div className="p-4 space-y-3">
              {emergencyAnalysis ? (
                // Emergency Route Active
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded bg-[#20B77A]/20 text-[#20B77A] text-xs font-mono font-bold">
                        {selectedEmergencyRoute?.isRecommended ? '★ BEST RECOMMENDED ROUTE' : 'SELECTED ROUTE'}
                      </span>
                      <span className="text-sm font-bold text-white">
                        {selectedEmergencyRoute?.name || 'Route B via Minister Road'}
                      </span>
                    </div>
                    <p className="text-xs text-[#8EA3BA]">
                      {selectedEmergencyRoute?.whyRecommended || 'Bypasses Ameerpet congestion. Avoids flooded bottlenecks.'}
                    </p>
                  </div>

                  <div className="flex items-center gap-4 shrink-0">
                    <div className="text-right">
                      <div className="text-xl font-bold font-mono text-[#20B77A]">
                        {selectedEmergencyRoute?.estimatedTimeMin || 14.2} min
                      </div>
                      <div className="text-[11px] text-[#8EA3BA]">
                        {selectedEmergencyRoute?.distanceKm || 11.5} km · {selectedEmergencyRoute?.historicalSuccessRate || 87}% On-Time
                      </div>
                    </div>
                    <button
                      onClick={() => onNavigate('emergency')}
                      className="px-4 py-2 rounded-xl bg-[#EF5B5B] hover:bg-[#f26c6c] text-white text-xs font-semibold cursor-pointer shadow-md transition-all"
                    >
                      Emergency Details
                    </button>
                  </div>
                </div>
              ) : analysis ? (
                // Traffic Analysis Active
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded bg-[#2F80ED]/20 text-[#2F80ED] text-xs font-mono font-bold">
                        HINDSIGHT INTERVENTION
                      </span>
                      <span className="text-sm font-bold text-white">
                        {analysis.recommendation.primaryAction}
                      </span>
                      <span className="text-xs text-[#20B77A] font-mono font-semibold">
                        ({Math.round((analysis.historicalEvidence?.confidenceScore || 0.85) * 100)}% Confidence)
                      </span>
                    </div>
                    <p className="text-xs text-[#8EA3BA] line-clamp-1">
                      {analysis.recommendation.explanation}
                    </p>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <button
                      onClick={() => setIsRecordModalOpen(true)}
                      className="px-3.5 py-2 rounded-xl bg-[#102238] hover:bg-[#152c48] border border-[#203752] text-xs font-medium text-white cursor-pointer transition-all"
                    >
                      Record Ground Truth
                    </button>
                    <button
                      onClick={() => onNavigate('traffic-ops')}
                      className="px-4 py-2 rounded-xl bg-[#2F80ED] hover:bg-[#3d8ef5] text-white text-xs font-semibold cursor-pointer shadow-md transition-all"
                    >
                      Traffic Specs & Details
                    </button>
                  </div>
                </div>
              ) : (
                // Default Map State
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="text-xs text-[#8EA3BA]">
                    Viewing real-time Hyderabad urban mobility. Click on any zone, corridor, or incident marker on the map to inspect details.
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => onNavigate('traffic-ops')}
                      className="px-3.5 py-1.5 rounded-lg bg-[#2F80ED] hover:bg-[#3d8ef5] text-white text-xs font-semibold cursor-pointer"
                    >
                      Analyze Incident
                    </button>
                    <button
                      onClick={() => onNavigate('emergency')}
                      className="px-3.5 py-1.5 rounded-lg bg-[#EF5B5B] hover:bg-[#f26c6c] text-white text-xs font-semibold cursor-pointer"
                    >
                      Calculate Ambulance Route
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Record Outcome Modal */}
      {analysis && (
        <RecordOutcomeModal
          isOpen={isRecordModalOpen}
          onClose={() => setIsRecordModalOpen(false)}
          onSubmit={handleRecordSubmit}
          incidentContext={{
            location: analysis.eventReceived.location,
            zone: analysis.eventReceived.location.includes('Ameerpet') ? 'Ameerpet' : 'Hyderabad Metro',
            day: analysis.eventReceived.day,
            time: analysis.eventReceived.time,
            weather: analysis.eventReceived.weather,
            incident: analysis.eventReceived.incident,
            severity: analysis.eventReceived.severity,
            intervention: analysis.recommendation.primaryAction
          }}
          isSaving={isSavingRecord}
        />
      )}
    </div>
  );
};
