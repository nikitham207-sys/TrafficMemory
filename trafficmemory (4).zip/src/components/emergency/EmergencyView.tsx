import React, { useState } from 'react';
import { 
  EmergencyAnalysisResponse, 
  EmergencyRouteOption, 
  HospitalInfo, 
  Weather,
  AnalyzeRequest
} from '../../types/traffic.ts';
import { 
  Ambulance, 
  Route, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  Navigation, 
  ShieldAlert, 
  Sparkles, 
  ArrowRight, 
  Database,
  MapPin,
  Map as MapIcon,
  Zap,
  Activity,
  PhoneCall
} from 'lucide-react';

interface EmergencyViewProps {
  hospitals: HospitalInfo[];
  emergencyAnalysis: EmergencyAnalysisResponse | null;
  isLoading: boolean;
  onFindRouteAndShowMap: (data: {
    origin: string;
    destinationHospitalId: string;
    urgency: 'Critical' | 'Urgent' | 'Standard';
    weather: Weather;
  }) => void;
  onSelectRoute: (route: EmergencyRouteOption) => void;
  selectedRouteId?: string;
  activeTrafficForm?: AnalyzeRequest;
  onNavigate: (tab: 'overview' | 'traffic-ops' | 'emergency' | 'map' | 'memory' | 'intelligence' | 'demo') => void;
}

export const EmergencyView: React.FC<EmergencyViewProps> = ({
  hospitals,
  emergencyAnalysis,
  isLoading,
  onFindRouteAndShowMap,
  onSelectRoute,
  selectedRouteId,
  activeTrafficForm,
  onNavigate
}) => {
  const [origin, setOrigin] = useState('Secunderabad Junction / Paradise');
  const [hospitalId, setHospitalId] = useState(hospitals[0]?.id || 'hosp-apollo');
  const [urgency, setUrgency] = useState<'Critical' | 'Urgent' | 'Standard'>('Critical');
  const [weather, setWeather] = useState<Weather>(activeTrafficForm?.weather || 'Rain');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onFindRouteAndShowMap({
      origin,
      destinationHospitalId: hospitalId,
      urgency,
      weather
    });
  };

  const selectedHospital = hospitals.find(h => h.id === hospitalId) || hospitals[0];

  return (
    <div className="flex-1 w-full h-full overflow-y-auto bg-[#071321] text-[#F1F5F9] p-6 lg:p-8 select-none">
      <div className="max-w-7xl mx-auto space-y-8 pb-12">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#203752]">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded bg-[#EF5B5B]/15 text-[#EF5B5B] text-xs font-mono font-bold border border-[#EF5B5B]/30">
                CRITICAL DISPATCH
              </span>
              <span className="text-xs text-[#8EA3BA] uppercase tracking-wider">
                Interlinked with Traffic Ops
              </span>
            </div>
            <h1 className="text-2xl lg:text-3xl font-bold text-white mt-1">
              Emergency Green Wave & Best Route Engine
            </h1>
            <p className="text-sm text-[#8EA3BA] mt-1">
              Guaranteed green corridor preemption to Hyderabad emergency centers, avoiding live traffic bottlenecks.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('traffic-ops')}
              className="px-4 py-2 rounded-lg bg-[#2F80ED]/15 hover:bg-[#2F80ED]/25 text-[#2F80ED] border border-[#2F80ED]/30 text-xs font-semibold flex items-center gap-2 cursor-pointer transition-all"
            >
              <Activity className="w-4 h-4" />
              <span>Back to Traffic Conditions</span>
            </button>
            <button
              onClick={() => onNavigate('map')}
              className="px-4 py-2 rounded-lg bg-[#102238] hover:bg-[#152c48] border border-[#203752] text-xs text-white font-medium flex items-center gap-1.5 cursor-pointer transition-all"
            >
              <MapIcon className="w-3.5 h-3.5 text-[#2F80ED]" />
              <span>View Map</span>
            </button>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* INTERLINKED LIVE TRAFFIC OPS STATUS BANNER */}
        {/* ------------------------------------------------------------- */}
        <div className="p-5 rounded-xl bg-gradient-to-r from-[#170e1a] via-[#10192e] to-[#0a1d30] border-2 border-[#20B77A]/40 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#20B77A]/15 border border-[#20B77A]/30 text-[#20B77A] flex items-center justify-center shrink-0 mt-0.5">
              <Zap className="w-5 h-5" />
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-[#20B77A] uppercase tracking-wider">
                  Live Interlink Active
                </span>
                <span className="text-[11px] px-2 py-0.2 rounded-full bg-[#20B77A]/20 text-[#20B77A] font-semibold">
                  Traffic Ops Synchronized
                </span>
              </div>
              <h4 className="text-sm font-bold text-white">
                Current Bottleneck Detected: {activeTrafficForm?.location || 'Ameerpet Cross Roads'} ({activeTrafficForm?.incident || 'Accident'} · {activeTrafficForm?.weather || 'Rain'})
              </h4>
              <p className="text-xs text-[#8EA3BA] max-w-3xl leading-relaxed">
                Because Traffic Ops reported a <strong className="text-white">{activeTrafficForm?.severity || 'Severe'}</strong> incident in <strong className="text-white">{activeTrafficForm?.zone || 'Ameerpet'}</strong>, 
                the emergency engine automatically penalizes the Ameerpet-Punjagutta arterial and reroutes ambulances via Minister Road / Jubilee Hills link to guarantee zero standstill delay.
              </p>
            </div>
          </div>

          <div className="shrink-0 flex items-center gap-2">
            <button
              onClick={() => onNavigate('traffic-ops')}
              className="px-3.5 py-2 rounded-lg bg-[#2F80ED]/20 hover:bg-[#2F80ED]/30 text-[#2F80ED] border border-[#2F80ED]/40 text-xs font-semibold cursor-pointer transition-all"
            >
              Tune Traffic Ops →
            </button>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* ROUTE DISPATCH FORM & COMPARISON */}
        {/* ------------------------------------------------------------- */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Dispatch Configurator Form */}
          <div className="lg:col-span-5 rounded-xl bg-[#091728] border border-[#203752] p-6 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-[#203752]">
              <div className="flex items-center gap-2">
                <Ambulance className="w-4 h-4 text-[#EF5B5B]" />
                <h3 className="text-base font-bold text-white">Emergency Route Parameters</h3>
              </div>
              <span className="text-xs font-mono text-[#EF5B5B]">108 DISPATCH</span>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Origin */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#8EA3BA] uppercase tracking-wider">
                  Pickup Origin
                </label>
                <select
                  value={origin}
                  onChange={e => setOrigin(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#071321] border border-[#203752] text-white text-xs focus:border-[#2F80ED] focus:outline-none"
                >
                  <option value="Secunderabad Junction / Paradise">Secunderabad Junction / Paradise</option>
                  <option value="Ameerpet Cross Roads">Ameerpet Cross Roads</option>
                  <option value="HITEC City Cyber Towers">HITEC City Cyber Towers</option>
                  <option value="Gachibowli ORR Junction">Gachibowli ORR Junction</option>
                  <option value="Begumpet Flyover North">Begumpet Flyover North</option>
                  <option value="Charminar South">Charminar South</option>
                </select>
              </div>

              {/* Destination Hospital */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[#8EA3BA] uppercase tracking-wider">
                  Destination Emergency Hospital
                </label>
                <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                  {hospitals.map(h => {
                    const isSelected = hospitalId === h.id;
                    return (
                      <div
                        key={h.id}
                        onClick={() => setHospitalId(h.id)}
                        className={`p-2.5 rounded-lg border transition-all cursor-pointer flex items-center justify-between ${
                          isSelected
                            ? 'bg-[#102238] border-[#2F80ED] text-white shadow-sm'
                            : 'bg-[#071321] border-[#203752] text-[#8EA3BA] hover:text-white hover:border-[#203752]/90'
                        }`}
                      >
                        <div className="truncate">
                          <div className="font-semibold text-xs text-white truncate">{h.name}</div>
                          <div className="text-[10px] text-[#8EA3BA]">{h.traumaLevel} · {h.zone}</div>
                        </div>
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded font-semibold bg-[#20B77A]/15 text-[#20B77A]">
                          {h.icuBedsAvailable} ICU Beds
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Urgency & Weather */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-[#8EA3BA] uppercase tracking-wider">
                    Triage Urgency
                  </label>
                  <select
                    value={urgency}
                    onChange={e => setUrgency(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-lg bg-[#071321] border border-[#203752] text-white text-xs focus:border-[#2F80ED] focus:outline-none"
                  >
                    <option value="Critical">Critical (Code Red)</option>
                    <option value="Urgent">Urgent (Code Amber)</option>
                    <option value="Standard">Standard Transit</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-[#8EA3BA] uppercase tracking-wider">
                    Current Weather
                  </label>
                  <select
                    value={weather}
                    onChange={e => setWeather(e.target.value as Weather)}
                    className="w-full px-3 py-2 rounded-lg bg-[#071321] border border-[#203752] text-white text-xs focus:border-[#2F80ED] focus:outline-none"
                  >
                    <option value="Rain">Rain (Wet Tarmac)</option>
                    <option value="Heavy Rain">Heavy Rain (Monsoon)</option>
                    <option value="Clear">Clear Road</option>
                    <option value="Fog">Dense Fog</option>
                  </select>
                </div>
              </div>

              {/* Submit Action */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-[#20B77A] to-[#168e5e] hover:from-[#25c986] hover:to-[#1aa16b] text-white font-bold text-sm shadow-lg shadow-[#20B77A]/25 flex items-center justify-center gap-2 cursor-pointer transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50"
                >
                  <Route className="w-4 h-4 fill-white" />
                  <span>
                    {isLoading ? 'Calculating Best Route...' : '🚑 Calculate Best Route & View on Map'}
                  </span>
                </button>
                <p className="text-[11px] text-[#8EA3BA] text-center mt-2">
                  Selects the fastest corridor with verified signal preemption and automatically navigates to the map.
                </p>
              </div>
            </form>
          </div>

          {/* Right Column: Best Route Analysis & Alternatives */}
          <div className="lg:col-span-7 space-y-4">
            {emergencyAnalysis ? (
              <div className="space-y-4">
                {/* Hospital Header card */}
                {selectedHospital && (
                  <div className="p-4 rounded-xl bg-[#091728] border border-[#203752] flex items-center justify-between">
                    <div>
                      <div className="text-xs text-[#8EA3BA]">Target Trauma Center:</div>
                      <h3 className="text-base font-bold text-white">{selectedHospital.name}</h3>
                      <div className="text-xs text-[#20B77A] mt-0.5">
                        {selectedHospital.traumaLevel} · {selectedHospital.icuBedsAvailable} ICU Beds Available
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <a
                        href={`tel:${selectedHospital.emergencyContact}`}
                        className="px-3 py-1.5 rounded-lg bg-[#102238] border border-[#203752] text-xs font-mono text-white flex items-center gap-1.5"
                      >
                        <PhoneCall className="w-3.5 h-3.5 text-[#20B77A]" />
                        <span>{selectedHospital.emergencyContact}</span>
                      </a>
                    </div>
                  </div>
                )}

                {/* Best Route Comparison */}
                <div className="rounded-xl bg-[#091728] border border-[#203752] p-6 space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-[#203752]">
                    <div>
                      <h3 className="text-base font-bold text-white">Route Alternatives & Preemption</h3>
                      <p className="text-xs text-[#8EA3BA]">Hindsight route evaluation against live congestion</p>
                    </div>
                    <button
                      onClick={() => onNavigate('map')}
                      className="px-4 py-2 rounded-lg bg-[#2F80ED] hover:bg-[#3d8ef5] text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-sm"
                    >
                      <MapIcon className="w-3.5 h-3.5" />
                      <span>Display Selected Route on Map</span>
                    </button>
                  </div>

                  <div className="space-y-3">
                    {emergencyAnalysis.routes.map(r => {
                      const isSelected = (selectedRouteId || emergencyAnalysis.routes.find(x => x.isRecommended)?.routeId) === r.routeId;
                      return (
                        <div
                          key={r.routeId}
                          onClick={() => onSelectRoute(r)}
                          className={`p-4 rounded-xl border transition-all cursor-pointer space-y-3 ${
                            r.isRecommended
                              ? isSelected
                                ? 'bg-[#0d2238] border-2 border-[#20B77A] shadow-md'
                                : 'bg-[#0a1a2b] border border-[#20B77A]/50'
                              : isSelected
                              ? 'bg-[#102238] border-2 border-[#2F80ED]'
                              : 'bg-[#071321] border border-[#203752] opacity-80 hover:opacity-100'
                          }`}
                        >
                          <div className="flex items-start justify-between gap-3">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                                  r.isRecommended 
                                    ? 'bg-[#20B77A]/20 text-[#20B77A] border border-[#20B77A]/40' 
                                    : 'bg-[#8EA3BA]/15 text-[#8EA3BA]'
                                }`}>
                                  {r.isRecommended ? '★ BEST RECOMMENDED ROUTE' : 'ALTERNATIVE ROUTE'}
                                </span>
                                <span className="text-xs font-bold text-white">{r.name}</span>
                              </div>
                              <p className="text-xs text-[#8EA3BA]">{r.whyRecommended}</p>
                            </div>

                            <div className="text-right shrink-0">
                              <div className="text-xl font-bold font-mono text-white">
                                {r.estimatedTimeMin} min
                              </div>
                              <div className="text-[11px] text-[#8EA3BA]">{r.distanceKm} km</div>
                            </div>
                          </div>

                          <div className="grid grid-cols-3 gap-2 pt-2 border-t border-[#203752]/70 text-[11px] font-mono">
                            <div className="text-[#8EA3BA]">
                              Via: <strong className="text-white">{r.via.join(' → ')}</strong>
                            </div>
                            <div className="text-[#8EA3BA]">
                              Bottlenecks: <strong className={r.riskBottlenecks.length === 0 ? 'text-[#20B77A]' : 'text-[#EF5B5B]'}>
                                {r.riskBottlenecks.length === 0 ? '0 Choke Points' : `${r.riskBottlenecks.length} Risk Points`}
                              </strong>
                            </div>
                            <div className="text-[#8EA3BA] text-right">
                              Success Rate: <strong className="text-[#20B77A]">{r.historicalSuccessRate}%</strong>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Why Hindsight Chose This Route */}
                  <div className="p-3.5 rounded-lg bg-[#071321] border border-[#203752] text-xs text-[#8EA3BA] space-y-1">
                    <span className="font-bold text-white">💡 Hindsight Dispatch Strategy: </span>
                    <span>
                      Standard GPS navigation systems suggest the Begumpet-Punjagutta arterial because it is marginally shorter. However, Hindsight historical telemetry confirms that during wet evening peak hours, Ameerpet backs up significantly. Route B avoids the Ameerpet bottleneck and ensures maximum on-time probability.
                    </span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="rounded-xl bg-[#091728] border border-[#203752] p-8 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-[#102238] border border-[#203752] flex items-center justify-center mx-auto text-[#EF5B5B]">
                  <Ambulance className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-bold text-white">No Route Calculated Yet</h4>
                <p className="text-xs text-[#8EA3BA] max-w-md mx-auto">
                  Select the pickup origin and destination hospital on the left, then click <strong>Calculate Best Route & View on Map</strong> to view the real-time green wave pathway.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
