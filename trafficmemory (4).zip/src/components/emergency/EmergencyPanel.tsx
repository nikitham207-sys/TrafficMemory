import React, { useState } from 'react';
import { EmergencyAnalysisResponse, EmergencyRouteOption, HospitalInfo, Weather } from '../../types/traffic.ts';
import { 
  Ambulance, 
  Route, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  Navigation, 
  ShieldAlert, 
  Sparkles,
  ArrowRight,
  Database
} from 'lucide-react';

interface EmergencyPanelProps {
  hospitals: HospitalInfo[];
  emergencyAnalysis: EmergencyAnalysisResponse | null;
  isLoading: boolean;
  onFindRoute: (data: {
    origin: string;
    destinationHospitalId: string;
    urgency: 'Critical' | 'Urgent' | 'Standard';
    weather: Weather;
  }) => void;
  onSelectRoute?: (route: EmergencyRouteOption) => void;
  selectedRouteId?: string;
}

export const EmergencyPanel: React.FC<EmergencyPanelProps> = ({
  hospitals,
  emergencyAnalysis,
  isLoading,
  onFindRoute,
  onSelectRoute,
  selectedRouteId
}) => {
  const [origin, setOrigin] = useState('Secunderabad Junction / Paradise');
  const [hospitalId, setHospitalId] = useState(hospitals[0]?.id || 'hosp-apollo');
  const [urgency, setUrgency] = useState<'Critical' | 'Urgent' | 'Standard'>('Critical');
  const [weather, setWeather] = useState<Weather>('Rain');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onFindRoute({
      origin,
      destinationHospitalId: hospitalId,
      urgency,
      weather
    });
  };

  const selectedHospital = hospitals.find(h => h.id === hospitalId) || hospitals[0];

  return (
    <div className="w-[340px] xl:w-[380px] bg-[#0B1929] border-l border-[#203752] flex flex-col justify-between h-full shrink-0 select-none overflow-y-auto z-20">
      <div className="p-4 space-y-4">
        {/* Header */}
        <div className="pb-3 border-b border-[#203752]">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded bg-[#EF5B5B]/20 text-[#EF5B5B] flex items-center justify-center">
                <Ambulance className="w-4 h-4" />
              </div>
              <h2 className="text-sm font-bold tracking-tight text-[#F1F5F9]">Emergency Routing</h2>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#EF5B5B]/20 text-[#EF5B5B] border border-[#EF5B5B]/40 font-semibold animate-pulse">
              DISPATCH
            </span>
          </div>
          <p className="text-[11px] text-[#8EA3BA] mt-1">
            Historical corridor performance under similar conditions, not just shortest path.
          </p>
        </div>

        {/* Input Parameters */}
        <form onSubmit={handleSubmit} className="space-y-2.5 bg-[#081522] p-3 rounded-lg border border-[#203752]">
          <div>
            <label className="block text-[10px] font-semibold text-[#8EA3BA] uppercase tracking-wider mb-1">
              Incident Origin
            </label>
            <select
              value={origin}
              onChange={(e) => setOrigin(e.target.value)}
              className="w-full bg-[#102238] border border-[#203752] rounded px-2.5 py-1.5 text-xs text-[#F1F5F9] focus:outline-none focus:border-[#2F80ED]"
            >
              <option value="Secunderabad Junction / Paradise">Secunderabad Junction / Paradise</option>
              <option value="Ameerpet Cross Roads">Ameerpet Cross Roads</option>
              <option value="Cyber Towers Junction">Cyber Towers Junction</option>
              <option value="Begumpet Flyover">Begumpet Flyover</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-semibold text-[#8EA3BA] uppercase tracking-wider mb-1">
              Destination Hospital
            </label>
            <select
              value={hospitalId}
              onChange={(e) => setHospitalId(e.target.value)}
              className="w-full bg-[#102238] border border-[#203752] rounded px-2.5 py-1.5 text-xs text-[#F1F5F9] focus:outline-none focus:border-[#2F80ED]"
            >
              {hospitals.map(h => (
                <option key={h.id} value={h.id}>
                  {h.name} ({h.traumaLevel.split('&')[0]})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[10px] font-semibold text-[#8EA3BA] uppercase tracking-wider mb-1">
                Urgency Level
              </label>
              <select
                value={urgency}
                onChange={(e) => setUrgency(e.target.value as any)}
                className="w-full bg-[#102238] border border-[#203752] rounded px-2 py-1.5 text-xs text-[#F1F5F9] focus:outline-none focus:border-[#2F80ED]"
              >
                <option value="Critical">Critical (P1)</option>
                <option value="Urgent">Urgent (P2)</option>
                <option value="Standard">Standard (P3)</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-semibold text-[#8EA3BA] uppercase tracking-wider mb-1">
                Weather Condition
              </label>
              <select
                value={weather}
                onChange={(e) => setWeather(e.target.value as Weather)}
                className="w-full bg-[#102238] border border-[#203752] rounded px-2 py-1.5 text-xs text-[#F1F5F9] focus:outline-none focus:border-[#2F80ED]"
              >
                <option value="Rain">Rain</option>
                <option value="Clear">Clear</option>
                <option value="Fog">Fog</option>
                <option value="Heavy Rain">Heavy Rain</option>
              </select>
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full mt-2 py-2 px-3 bg-[#EF5B5B] hover:bg-[#DC2626] disabled:bg-[#203752] text-white font-medium text-xs rounded transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md"
          >
            {isLoading ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                <span>Recalling Route Memories...</span>
              </>
            ) : (
              <>
                <span>Find Best Emergency Route</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </>
            )}
          </button>
        </form>

        {/* Selected Hospital Info */}
        {selectedHospital && (
          <div className="p-2.5 rounded bg-[#102238] border border-[#203752] text-xs space-y-1">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-[#F1F5F9]">{selectedHospital.name}</span>
              <span className="text-[10px] text-[#20B77A] font-semibold font-mono">
                {selectedHospital.icuBedsAvailable} ICU beds free
              </span>
            </div>
            <div className="text-[11px] text-[#8EA3BA]">{selectedHospital.traumaLevel}</div>
          </div>
        )}

        {/* Analysis Output */}
        {emergencyAnalysis && (
          <div className="space-y-3 pt-1">
            {/* Hindsight Summary Banner */}
            <div className="p-3 rounded bg-[#102238] border border-[#20B77A]/50 space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-[#20B77A] flex items-center gap-1.5 uppercase tracking-wide">
                  <CheckCircle2 className="w-4 h-4" />
                  Recommended Route: Route B
                </span>
                <span className="text-[10px] text-[#8B6FE8] font-mono">
                  {emergencyAnalysis.hindsightSummary.totalPastEmergencyTrips} Past Trips Recalled
                </span>
              </div>
              <p className="text-xs text-[#F1F5F9] leading-relaxed">
                {emergencyAnalysis.hindsightSummary.reason}
              </p>
            </div>

            {/* Route Comparison Cards */}
            <div className="space-y-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#8EA3BA]">
                Historical Route Comparison
              </span>

              {emergencyAnalysis.routes.map(route => {
                const isSelected = selectedRouteId === route.routeId || (!selectedRouteId && route.isRecommended);
                return (
                  <div
                    key={route.routeId}
                    onClick={() => onSelectRoute?.(route)}
                    className={`p-3 rounded-lg border cursor-pointer transition-all ${
                      route.isRecommended
                        ? 'bg-[#102238] border-[#20B77A] shadow-md ring-1 ring-[#20B77A]/30'
                        : 'bg-[#081522] border-[#203752] hover:border-[#8EA3BA]/40 opacity-80'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="flex items-center gap-1.5">
                        <span className={`text-xs font-bold ${route.isRecommended ? 'text-[#20B77A]' : 'text-[#8EA3BA]'}`}>
                          {route.name.split('—')[0]}
                        </span>
                        {route.isRecommended && (
                          <span className="px-1.5 py-0.2 rounded text-[9px] font-semibold bg-[#20B77A]/20 text-[#20B77A]">
                            FASTEST HISTORICAL
                          </span>
                        )}
                      </div>
                      <span className="text-xs font-bold text-[#F1F5F9] font-mono">
                        ~{route.estimatedTimeMin} min ({route.distanceKm} km)
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-1 py-1.5 my-1.5 border-y border-[#203752]/70 text-center">
                      <div>
                        <div className="text-[9px] text-[#8EA3BA] uppercase">Past Trips</div>
                        <div className="text-xs font-semibold text-[#F1F5F9] font-mono">{route.historicalTrips}</div>
                      </div>
                      <div>
                        <div className="text-[9px] text-[#8EA3BA] uppercase">Avg Time</div>
                        <div className="text-xs font-semibold text-[#F1F5F9] font-mono">{route.avgHistoricalTimeMin}m</div>
                      </div>
                      <div>
                        <div className="text-[9px] text-[#8EA3BA] uppercase">Success Rate</div>
                        <div className={`text-xs font-semibold font-mono ${route.historicalSuccessRate >= 80 ? 'text-[#20B77A]' : 'text-[#EF5B5B]'}`}>
                          {route.historicalSuccessRate}%
                        </div>
                      </div>
                    </div>

                    <div className="space-y-1 text-[11px] text-[#8EA3BA]">
                      <div>
                        <span className="text-[#8EA3BA]/70">Corridor: </span>
                        <span>{route.via.join(' → ')}</span>
                      </div>
                      {route.riskBottlenecks.length > 0 && (
                        <div className="text-[10px] text-[#EF5B5B]/90 flex items-center gap-1 pt-0.5">
                          <AlertTriangle className="w-3 h-3 shrink-0" />
                          <span>{route.riskBottlenecks[0]}</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
