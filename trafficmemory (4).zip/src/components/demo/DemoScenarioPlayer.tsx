import React from 'react';
import { Play, Sparkles, AlertTriangle, Ambulance, History, CheckCircle2, ArrowRight } from 'lucide-react';
import { AnalyzeRequest, Weather, IncidentType, Severity } from '../../types/traffic.ts';

interface DemoScenarioPlayerProps {
  onPlayScenario1: () => void;
  onPlayScenario2: () => void;
  onPlayScenario3: () => void;
}

export const DemoScenarioPlayer: React.FC<DemoScenarioPlayerProps> = ({
  onPlayScenario1,
  onPlayScenario2,
  onPlayScenario3
}) => {
  const scenarios = [
    {
      id: 1,
      number: 'SCENARIO 01',
      title: 'Rain + Evening Accident at Ameerpet Cross Roads',
      badge: 'TRAFFIC OPS',
      badgeColor: 'text-[#2F80ED] bg-[#2F80ED]/15 border-[#2F80ED]/30',
      description: 'Friday 6:30 PM thunderstorm triggers bus collision near Maitrivanam. Standard heuristic suggests static diversion, but Hindsight recalls 6 past incidents where diversion flooded Balkampet, recommending signal retiming (67% success).',
      expectedAction: 'Apply Signal Retiming First',
      onPlay: onPlayScenario1,
      icon: AlertTriangle,
      iconColor: 'text-[#EF5B5B]'
    },
    {
      id: 2,
      number: 'SCENARIO 02',
      title: 'Critical Ambulance Corridor (Secunderabad → Apollo)',
      badge: 'EMERGENCY DISPATCH',
      badgeColor: 'text-[#EF5B5B] bg-[#EF5B5B]/15 border-[#EF5B5B]/30',
      description: 'Critical patient transit during peak wet conditions. Standard GPS navigation suggests the shorter Begumpet-Panjagutta arterial (Route A), but Hindsight history proves Route B (via Minister Road) is 8.2 minutes faster with an 87.5% critical on-time rate.',
      expectedAction: 'Route B — Recommended Hindsight Path',
      onPlay: onPlayScenario2,
      icon: Ambulance,
      iconColor: 'text-[#20B77A]'
    },
    {
      id: 3,
      number: 'SCENARIO 03',
      title: 'Failed Intervention Learning: Foggy Monday at Gachibowli',
      badge: 'ADAPTIVE LEARNING',
      badgeColor: 'text-[#8B6FE8] bg-[#8B6FE8]/15 border-[#8B6FE8]/30',
      description: 'Dense fog and heavy IT rush at Gachibowli ORR junction. Previous attempts to retime signals failed due to saturated downstream slip roads. The agent leverages stored failures to pivot to Traffic Diversion via Nanakramguda rotary.',
      expectedAction: 'Pivot to Traffic Diversion via Nanakramguda',
      onPlay: onPlayScenario3,
      icon: History,
      iconColor: 'text-[#E8A52D]'
    }
  ];

  return (
    <div className="w-[340px] xl:w-[420px] bg-[#0B1929] border-l border-[#203752] flex flex-col justify-between h-full shrink-0 select-none overflow-y-auto z-20">
      <div className="p-4 space-y-4">
        {/* Header */}
        <div className="pb-3 border-b border-[#203752]">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded bg-[#2F80ED]/20 text-[#2F80ED] flex items-center justify-center">
                <Play className="w-4 h-4 fill-current" />
              </div>
              <h2 className="text-sm font-bold tracking-tight text-[#F1F5F9]">Interactive Demo Scenarios</h2>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#20B77A]/15 text-[#20B77A] border border-[#20B77A]/30 font-semibold">
              3 GUIDED FLOWS
            </span>
          </div>
          <p className="text-[11px] text-[#8EA3BA] mt-1">
            Experience the 60-second end-to-end demonstration of persistent traffic memory in action.
          </p>
        </div>

        {/* Scenarios List */}
        <div className="space-y-3">
          {scenarios.map(sc => {
            const Icon = sc.icon;
            return (
              <div
                key={sc.id}
                className="p-3.5 rounded-lg bg-[#081522] border border-[#203752] space-y-2.5 transition-all hover:border-[#2F80ED]/50"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold tracking-wider text-[#8EA3BA] uppercase font-mono">
                    {sc.number}
                  </span>
                  <span className={`text-[9px] font-semibold px-1.5 py-0.5 rounded border ${sc.badgeColor}`}>
                    {sc.badge}
                  </span>
                </div>

                <div className="flex items-start gap-2">
                  <Icon className={`w-4 h-4 mt-0.5 shrink-0 ${sc.iconColor}`} />
                  <h3 className="text-xs font-bold text-[#F1F5F9] leading-snug">{sc.title}</h3>
                </div>

                <p className="text-[11px] text-[#8EA3BA] leading-relaxed">
                  {sc.description}
                </p>

                <div className="p-2 rounded bg-[#102238] border border-[#203752] text-[11px] flex items-center justify-between">
                  <span className="text-[#8EA3BA]">Target Recommendation:</span>
                  <span className="font-semibold text-[#20B77A] text-[11px]">{sc.expectedAction}</span>
                </div>

                <button
                  type="button"
                  onClick={sc.onPlay}
                  className="w-full py-2 px-3 bg-[#2F80ED] hover:bg-[#2563EB] text-white font-medium text-xs rounded transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Play {sc.number}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
