import React from 'react';
import { 
  Play, 
  Sparkles, 
  AlertTriangle, 
  Ambulance, 
  History, 
  CheckCircle2, 
  ArrowRight, 
  MapPin, 
  Compass, 
  Clock, 
  Database,
  Map as MapIcon,
  Zap,
  TrendingUp
} from 'lucide-react';

interface DemoScenariosViewProps {
  onPlayScenario1: () => void;
  onPlayScenario2: () => void;
  onPlayScenario3: () => void;
  onNavigate: (tab: 'overview' | 'traffic-ops' | 'emergency' | 'map' | 'memory' | 'intelligence' | 'demo') => void;
}

export const DemoScenariosView: React.FC<DemoScenariosViewProps> = ({
  onPlayScenario1,
  onPlayScenario2,
  onPlayScenario3,
  onNavigate
}) => {
  const scenarios = [
    {
      id: 1,
      number: 'SCENARIO 01 · THE HACKATHON FLAGSHIP',
      title: 'Ameerpet Cross Roads: Friday Rain + Evening Accident',
      badge: 'BEFORE VS AFTER DEMO',
      badgeColor: 'text-[#2F80ED] bg-[#2F80ED]/15 border-[#2F80ED]/30',
      tagline: 'How Hindsight changes agent behavior based on past recorded outcomes.',
      context: 'Friday 6:30 PM thunderstorm triggers bus collision near Maitrivanam intersection.',
      dilemma: 'A standard LLM or naive rule-based system guesses: "Consider signal retiming or diversion." Diversion in heavy rain sends traffic into flooded Balkampet residential lanes, causing complete gridlock.',
      hindsightInsight: 'TrafficMemory recalls 6 similar past experiences: Signal retiming succeeded 4/6 times (67%), whereas diversion only succeeded 2/6 times (33%).',
      expectedAction: 'Signal Retiming (+40s Green Extension on Main Arterial)',
      expectedOutcome: '-18 min delay reduction, traffic cleared in 22 minutes.',
      onPlay: onPlayScenario1,
      icon: AlertTriangle,
      iconColor: 'text-[#EF5B5B]'
    },
    {
      id: 2,
      number: 'SCENARIO 02 · INTERLINKED DISPATCH',
      title: 'Critical Ambulance Corridor: Secunderabad → Apollo Jubilee Hills',
      badge: 'EMERGENCY GREEN WAVE',
      badgeColor: 'text-[#EF5B5B] bg-[#EF5B5B]/15 border-[#EF5B5B]/30',
      tagline: 'Interlinked with Traffic Ops to bypass active bottlenecks.',
      context: 'Cardiac code-red emergency transit from Paradise junction during peak monsoon rush.',
      dilemma: 'Standard GPS recommends Route A (Begumpet-Punjagutta) because it is 1.2 km shorter, but Traffic Ops detects an active severe bottleneck at Ameerpet.',
      hindsightInsight: 'Hindsight history proves Route B (via Minister Road) has 8 pre-coordinated traffic signals that switch to green wave upon ambulance transponder detection, arriving 8.2 minutes faster with 87.5% on-time probability.',
      expectedAction: 'Route B — Recommended Hindsight Green Wave Corridor',
      expectedOutcome: '14.2 min transit time vs 26.5 min on Route A (8.2 min saved).',
      onPlay: onPlayScenario2,
      icon: Ambulance,
      iconColor: 'text-[#20B77A]'
    },
    {
      id: 3,
      number: 'SCENARIO 03 · ADAPTIVE EVOLUTION',
      title: 'Failed Intervention Learning: Foggy Monday at Gachibowli ORR',
      badge: 'LEARNING FROM FAILURE',
      badgeColor: 'text-[#8B6FE8] bg-[#8B6FE8]/15 border-[#8B6FE8]/30',
      tagline: 'Never repeating the same mistake twice.',
      context: 'Dense morning fog and heavy IT rush hour at Gachibowli Outer Ring Road junction.',
      dilemma: 'Traffic engineers often default to signal retiming. However, past recorded incidents show signal retiming failed twice because downstream flyover ramps were saturated.',
      hindsightInsight: 'The agent inspects stored past failures and immediately pivots to Traffic Diversion via Nanakramguda rotary before secondary gridlock sets in.',
      expectedAction: 'Pivot to Traffic Diversion via Nanakramguda Rotary',
      expectedOutcome: 'Avoided gridlock, smooth queue discharge along service lanes.',
      onPlay: onPlayScenario3,
      icon: History,
      iconColor: 'text-[#E8A52D]'
    }
  ];

  return (
    <div className="flex-1 w-full h-full overflow-y-auto bg-[#071321] text-[#F1F5F9] p-6 lg:p-8 select-none">
      <div className="max-w-7xl mx-auto space-y-8 pb-12">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#203752]">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded bg-[#E8A52D]/15 text-[#E8A52D] text-xs font-mono font-bold border border-[#E8A52D]/30">
                INTERACTIVE DEMO PLAYLIST
              </span>
              <span className="text-xs text-[#8EA3BA] uppercase tracking-wider">
                1-Click Scenario Execution
              </span>
            </div>
            <h1 className="text-2xl lg:text-3xl font-bold text-white mt-1">
              Live Demonstration Scenarios
            </h1>
            <p className="text-sm text-[#8EA3BA] mt-1">
              Select any scenario below. Clicking <strong>Play Scenario & View on Map</strong> will execute the reasoning loop and automatically transition directly to the map with full visual markers.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('map')}
              className="px-4 py-2 rounded-lg bg-[#102238] hover:bg-[#152c48] border border-[#203752] text-xs text-white font-medium flex items-center gap-1.5 cursor-pointer transition-all"
            >
              <MapIcon className="w-3.5 h-3.5 text-[#2F80ED]" />
              <span>View Map</span>
            </button>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* SCENARIO CARDS */}
        {/* ------------------------------------------------------------- */}
        <div className="space-y-6">
          {scenarios.map(s => {
            const Icon = s.icon;
            return (
              <div
                key={s.id}
                className="rounded-2xl bg-[#091728] border-2 border-[#203752] hover:border-[#2F80ED]/50 transition-all p-6 lg:p-8 space-y-5 shadow-xl relative overflow-hidden"
              >
                {/* Top Row: Title, Badge, and Play Button */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#203752]">
                  <div className="flex items-start gap-3">
                    <div className={`w-10 h-10 rounded-xl bg-[#102238] border border-[#203752] flex items-center justify-center shrink-0 ${s.iconColor}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono font-bold text-[#8EA3BA] uppercase tracking-wider">
                          {s.number}
                        </span>
                        <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${s.badgeColor}`}>
                          {s.badge}
                        </span>
                      </div>
                      <h2 className="text-xl font-bold text-white mt-0.5">{s.title}</h2>
                      <p className="text-xs text-[#2F80ED] mt-0.5 font-medium">{s.tagline}</p>
                    </div>
                  </div>

                  {/* Big Play Scenario Button */}
                  <button
                    onClick={s.onPlay}
                    className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-[#2F80ED] to-[#1E6FD9] hover:from-[#3a8bf0] hover:to-[#2277e3] text-white font-bold text-sm shadow-lg shadow-[#2F80ED]/25 flex items-center justify-center gap-2.5 cursor-pointer transition-all hover:scale-[1.02] active:scale-[0.98] shrink-0"
                  >
                    <Play className="w-4 h-4 fill-white" />
                    <span>Play Scenario & View on Map</span>
                  </button>
                </div>

                {/* Scenario Context & Dilemma */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  {/* Dilemma with standard agent */}
                  <div className="p-4 rounded-xl bg-[#071321] border border-[#EF5B5B]/30 space-y-2">
                    <div className="flex items-center gap-1.5 text-[#EF5B5B] font-bold uppercase tracking-wider text-[11px]">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      <span>The Dilemma & Standard LLM Guess</span>
                    </div>
                    <p className="text-[#8EA3BA] leading-relaxed">
                      {s.dilemma}
                    </p>
                  </div>

                  {/* Hindsight Advantage */}
                  <div className="p-4 rounded-xl bg-[#071321] border border-[#20B77A]/30 space-y-2">
                    <div className="flex items-center gap-1.5 text-[#20B77A] font-bold uppercase tracking-wider text-[11px]">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>What TrafficMemory Hindsight Recalls</span>
                    </div>
                    <p className="text-[#8EA3BA] leading-relaxed">
                      {s.hindsightInsight}
                    </p>
                  </div>
                </div>

                {/* Footer action & impact */}
                <div className="p-3.5 rounded-xl bg-[#0e2136] border border-[#203752] flex flex-col md:flex-row md:items-center justify-between gap-2 text-xs">
                  <div>
                    <span className="text-[#8EA3BA]">Expected Policy Output: </span>
                    <strong className="text-white font-semibold">{s.expectedAction}</strong>
                  </div>
                  <div className="text-[#20B77A] font-mono font-semibold">
                    Target Impact: {s.expectedOutcome}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
