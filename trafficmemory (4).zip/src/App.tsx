import React, { useState, useEffect } from 'react';
import { TopNav, NavTab } from './components/layout/TopNav.tsx';
import { OverviewView } from './components/overview/OverviewView.tsx';
import { TrafficConditionsView } from './components/traffic/TrafficConditionsView.tsx';
import { EmergencyView } from './components/emergency/EmergencyView.tsx';
import { DedicatedMapView } from './components/map/DedicatedMapView.tsx';
import { MemoryLocationsView } from './components/memory/MemoryLocationsView.tsx';
import { IntelligenceView } from './components/intelligence/IntelligenceView.tsx';
import { DemoScenariosView } from './components/demo/DemoScenariosView.tsx';

import { api } from './services/api.ts';
import { 
  AnalyzeRequest, 
  AnalyzeResponse, 
  EmergencyAnalysisResponse, 
  EmergencyRouteOption, 
  HospitalInfo, 
  IncidentMarker, 
  OutcomeStatus, 
  SystemStats, 
  TrafficCorridor, 
  TrafficMemoryItem, 
  ZoneInfo 
} from './types/traffic.ts';

export default function App() {
  // Start on the dedicated Overview page as requested by user
  const [currentTab, setCurrentTab] = useState<NavTab>('overview');

  const [zones, setZones] = useState<ZoneInfo[]>([]);
  const [hospitals, setHospitals] = useState<HospitalInfo[]>([]);
  const [incidents, setIncidents] = useState<IncidentMarker[]>([]);
  const [corridors, setCorridors] = useState<TrafficCorridor[]>([]);
  const [memories, setMemories] = useState<TrafficMemoryItem[]>([]);
  const [stats, setStats] = useState<SystemStats | null>(null);

  // Selections & Map Focus
  const [activeZoneId, setActiveZoneId] = useState<string>('ameerpet');
  const [selectedIncidentId, setSelectedIncidentId] = useState<string>('inc-01');
  const [selectedMemory, setSelectedMemory] = useState<TrafficMemoryItem | null>(null);
  const [focusedCoordinates, setFocusedCoordinates] = useState<[number, number] | null>([78.4482, 17.4375]);

  // Map Layers Toggle State
  const [layers, setLayers] = useState({
    trafficFlow: true,
    incidents: true,
    hospitals: true,
    zones: true,
    memories: true,
    emergencyRoutes: true,
  });

  // Traffic Conditions State
  const [trafficForm, setTrafficForm] = useState<AnalyzeRequest>({
    location: 'Ameerpet Cross Roads',
    zone: 'Ameerpet',
    day: 'Friday',
    time: '6:30 PM',
    weather: 'Rain',
    incident: 'Accident',
    severity: 'Severe'
  });
  const [analysis, setAnalysis] = useState<AnalyzeResponse | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [lastRetainedMemory, setLastRetainedMemory] = useState<TrafficMemoryItem | null>(null);

  // Emergency Routing State (Interlinked with Traffic Ops)
  const [emergencyAnalysis, setEmergencyAnalysis] = useState<EmergencyAnalysisResponse | null>(null);
  const [isEmergencyLoading, setIsEmergencyLoading] = useState(false);
  const [selectedEmergencyRoute, setSelectedEmergencyRoute] = useState<EmergencyRouteOption | null>(null);

  // Reset State
  const [isResetting, setIsResetting] = useState(false);

  // Initial Data Fetch
  useEffect(() => {
    async function loadInitialData() {
      try {
        const [z, h, inc, c, mRes, s] = await Promise.all([
          api.getZones(),
          api.getHospitals(),
          api.getIncidents(),
          api.getCorridors(),
          api.getMemories(),
          api.getStats()
        ]);
        setZones(z);
        setHospitals(h);
        setIncidents(inc);
        setCorridors(c);
        setMemories(mRes.memories);
        setStats(s);

        // Pre-compute Ameerpet default analysis in background for instant availability
        try {
          const defaultAnalysis = await api.analyze({
            location: 'Ameerpet Cross Roads',
            zone: 'Ameerpet',
            day: 'Friday',
            time: '6:30 PM',
            weather: 'Rain',
            incident: 'Accident',
            severity: 'Severe'
          });
          setAnalysis(defaultAnalysis);
        } catch (e) {
          console.warn('Initial analysis prefill warning:', e);
        }

        // Pre-compute Emergency route in background for instant availability
        try {
          const defaultEmergency = await api.emergency({
            origin: 'Secunderabad Junction / Paradise',
            destinationHospitalId: 'hosp-apollo',
            urgency: 'Critical',
            weather: 'Rain'
          });
          setEmergencyAnalysis(defaultEmergency);
          const rec = defaultEmergency.routes.find(r => r.isRecommended) || defaultEmergency.routes[0];
          setSelectedEmergencyRoute(rec);
        } catch (e) {
          console.warn('Initial emergency prefill warning:', e);
        }
      } catch (err) {
        console.error('Failed to load initial data:', err);
      }
    }
    loadInitialData();
  }, []);

  // Layer Toggle
  const handleToggleLayer = (layerKey: keyof typeof layers) => {
    setLayers(prev => ({ ...prev, [layerKey]: !prev[layerKey] }));
  };

  // Zone Selection
  const handleSelectZone = (zone: ZoneInfo) => {
    setActiveZoneId(zone.id);
    setFocusedCoordinates(zone.center);
    setTrafficForm(prev => ({
      ...prev,
      zone: zone.name,
      location: `${zone.name} Cross Roads`
    }));
  };

  // Incident Selection
  const handleSelectIncident = (inc: IncidentMarker) => {
    setSelectedIncidentId(inc.id);
    setFocusedCoordinates(inc.coordinates);
    const matchedZone = zones.find(z => z.name.toLowerCase() === inc.zone.toLowerCase() || z.id === inc.zone.toLowerCase());
    if (matchedZone) setActiveZoneId(matchedZone.id);
  };

  // Run Traffic Analysis and navigate directly to Map View
  const handleRunAnalysisAndShowMap = async (form: AnalyzeRequest) => {
    setIsAnalyzing(true);
    setTrafficForm(form);
    const zoneQuery = (form.zone || '').toLowerCase();
    const matchedZone = zoneQuery ? zones.find(z => z.name.toLowerCase() === zoneQuery || zoneQuery.includes(z.name.toLowerCase())) : null;
    if (matchedZone) {
      setActiveZoneId(matchedZone.id);
      setFocusedCoordinates(matchedZone.center);
    }
    try {
      const res = await api.analyze(form);
      setAnalysis(res);
      // Directly take to map page per user specification!
      setCurrentTab('map');
    } catch (err) {
      console.error('Analysis failed:', err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Record Outcome
  const handleRecordOutcome = async (data: {
    outcome: OutcomeStatus;
    notes: string;
    delayBeforeMin: number;
    delayAfterMin: number;
  }) => {
    if (!analysis) return;
    try {
      const res = await api.recordOutcome({
        location: trafficForm.location,
        zone: trafficForm.zone || 'Ameerpet',
        day: trafficForm.day,
        time: trafficForm.time,
        weather: trafficForm.weather,
        incident: trafficForm.incident,
        severity: trafficForm.severity,
        intervention: analysis.recommendation.primaryAction,
        outcome: data.outcome,
        delayBeforeMin: data.delayBeforeMin,
        delayAfterMin: data.delayAfterMin,
        notes: data.notes
      });

      setLastRetainedMemory(res.retainedMemory);
      setStats(res.updatedStats);

      // Refresh memory list
      const memRes = await api.getMemories();
      setMemories(memRes.memories);
    } catch (err) {
      console.error('Failed to record outcome:', err);
    }
  };

  // Run Emergency Route Analysis and navigate directly to Map View
  const handleRunEmergencyAndShowMap = async (params: {
    origin: string;
    destinationHospitalId: string;
    urgency: 'Critical' | 'Urgent' | 'Standard';
    weather: any;
  }) => {
    setIsEmergencyLoading(true);
    try {
      const res = await api.emergency(params);
      setEmergencyAnalysis(res);
      const rec = res.routes.find(r => r.isRecommended) || res.routes[0];
      setSelectedEmergencyRoute(rec);
      if (res.hospital?.coordinates) {
        setFocusedCoordinates(res.hospital.coordinates);
      }
      // Directly take to map page per user specification!
      setCurrentTab('map');
    } catch (err) {
      console.error('Emergency route calculation failed:', err);
    } finally {
      setIsEmergencyLoading(false);
    }
  };

  // Select and locate a specific memory record directly on the map
  const handleSelectAndLocateMemoryOnMap = (mem: TrafficMemoryItem) => {
    setSelectedMemory(mem);
    setFocusedCoordinates(mem.coordinates);
    const matchedZone = zones.find(z => z.name.toLowerCase().includes(mem.zone.toLowerCase()));
    if (matchedZone) setActiveZoneId(matchedZone.id);
    setCurrentTab('map');
  };

  // Play Scenario 1 (Flagship Ameerpet Before vs After)
  const handlePlayScenario1 = async () => {
    const s1Form: AnalyzeRequest = {
      location: 'Ameerpet Cross Roads',
      zone: 'Ameerpet',
      day: 'Friday',
      time: '6:30 PM',
      weather: 'Rain',
      incident: 'Accident',
      severity: 'Severe'
    };
    setTrafficForm(s1Form);
    setFocusedCoordinates([78.4482, 17.4375]);
    setSelectedIncidentId('inc-01');
    await handleRunAnalysisAndShowMap(s1Form);
  };

  // Play Scenario 2 (Emergency Ambulance Corridor to Apollo)
  const handlePlayScenario2 = async () => {
    setFocusedCoordinates([78.4124, 17.4278]); // Apollo Jubilee Hills
    await handleRunEmergencyAndShowMap({
      origin: 'Secunderabad Junction / Paradise',
      destinationHospitalId: 'hosp-apollo',
      urgency: 'Critical',
      weather: 'Rain'
    });
  };

  // Play Scenario 3 (Gachibowli Fog Peak Hour)
  const handlePlayScenario3 = async () => {
    const s3Form: AnalyzeRequest = {
      location: 'Gachibowli ORR Junction',
      zone: 'HITEC City / Gachibowli',
      day: 'Monday',
      time: '8:45 AM',
      weather: 'Fog',
      incident: 'Peak Congestion',
      severity: 'Severe'
    };
    setTrafficForm(s3Form);
    setFocusedCoordinates([78.3635, 17.4402]);
    setSelectedIncidentId('inc-02');
    await handleRunAnalysisAndShowMap(s3Form);
  };

  // Reset Seed State
  const handleResetSeed = async () => {
    setIsResetting(true);
    try {
      const res = await api.resetMemories();
      setStats(res.stats);
      const memRes = await api.getMemories();
      setMemories(memRes.memories);
      setLastRetainedMemory(null);
    } catch (err) {
      console.error('Failed to reset seed:', err);
    } finally {
      setIsResetting(false);
    }
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-[#071321] text-[#F1F5F9] overflow-hidden select-none font-sans">
      {/* Top Bar with distinct page navigation */}
      <TopNav
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        stats={stats}
        onResetSeed={handleResetSeed}
        isResetting={isResetting}
      />

      {/* Main Page Body: Clean, dedicated full-view pages for each specification */}
      <main className="flex-1 w-full h-[calc(100vh-64px)] overflow-hidden relative">
        {/* PAGE 1: OVERVIEW (Hackathon Motto, Step 6 Before vs After, KPIs, Architecture) */}
        {currentTab === 'overview' && (
          <OverviewView
            stats={stats}
            onNavigate={setCurrentTab}
            onPlayAmeerpetScenario={handlePlayScenario1}
            onPlayEmergencyScenario={handlePlayScenario2}
          />
        )}

        {/* PAGE 2: TRAFFIC CONDITIONS (Specifications, features, incident configurator, analyze to map) */}
        {currentTab === 'traffic-ops' && (
          <TrafficConditionsView
            initialForm={trafficForm}
            analysis={analysis}
            isAnalyzing={isAnalyzing}
            onAnalyzeAndShowMap={handleRunAnalysisAndShowMap}
            onRecordOutcome={handleRecordOutcome}
            lastRetainedMemory={lastRetainedMemory}
            zones={zones}
            activeZoneId={activeZoneId}
            onZoneChange={handleSelectZone}
            onNavigate={setCurrentTab}
          />
        )}

        {/* PAGE 3: EMERGENCY (Interlinked with traffic conditions, best route finding, dispatch to map) */}
        {currentTab === 'emergency' && (
          <EmergencyView
            hospitals={hospitals}
            emergencyAnalysis={emergencyAnalysis}
            isLoading={isEmergencyLoading}
            onFindRouteAndShowMap={handleRunEmergencyAndShowMap}
            onSelectRoute={(route) => {
              setSelectedEmergencyRoute(route);
              if (route.coordinates?.[0]) {
                setFocusedCoordinates(route.coordinates[0]);
              }
            }}
            selectedRouteId={selectedEmergencyRoute?.routeId}
            activeTrafficForm={trafficForm}
            onNavigate={setCurrentTab}
          />
        )}

        {/* PAGE 4: MAP VIEW (Full-screen dedicated interactive map, zero clumsy sidebars) */}
        {currentTab === 'map' && (
          <DedicatedMapView
            zones={zones}
            hospitals={hospitals}
            incidents={incidents}
            corridors={corridors}
            memories={memories}
            emergencyRoutes={emergencyAnalysis?.routes}
            activeZoneId={activeZoneId}
            selectedIncidentId={selectedIncidentId}
            selectedMemoryId={selectedMemory?.id}
            layers={layers}
            onToggleLayer={handleToggleLayer}
            onSelectIncident={handleSelectIncident}
            onSelectZone={handleSelectZone}
            onSelectMemory={(mem) => {
              setSelectedMemory(mem);
              setFocusedCoordinates(mem.coordinates);
            }}
            focusedCoordinates={focusedCoordinates}
            analysis={analysis}
            emergencyAnalysis={emergencyAnalysis}
            selectedEmergencyRoute={selectedEmergencyRoute}
            onNavigate={setCurrentTab}
            onRecordOutcome={handleRecordOutcome}
          />
        )}

        {/* PAGE 5: MEMORY LOCATIONS (Episodic vector memory explorer with map locator) */}
        {currentTab === 'memory' && (
          <MemoryLocationsView
            memories={memories}
            selectedMemory={selectedMemory}
            onSelectAndLocateOnMap={handleSelectAndLocateMemoryOnMap}
            totalCount={memories.length}
            onNavigate={setCurrentTab}
          />
        )}

        {/* PAGE 6: INTELLIGENCE (Agent learning curves, intervention success matrix, reflection loops) */}
        {currentTab === 'intelligence' && (
          <IntelligenceView
            stats={stats}
            onNavigate={setCurrentTab}
          />
        )}

        {/* PAGE 7: DEMO SCENARIOS (3 rich interactive scenarios with 1-click execution to map) */}
        {currentTab === 'demo' && (
          <DemoScenariosView
            onPlayScenario1={handlePlayScenario1}
            onPlayScenario2={handlePlayScenario2}
            onPlayScenario3={handlePlayScenario3}
            onNavigate={setCurrentTab}
          />
        )}
      </main>
    </div>
  );
}
