import { TrafficMemoryItem, AnalyzeRequest, InterventionOutcomeStat, InterventionType, Weather, IncidentType, Severity } from '../types/traffic.ts';
import { SEED_HISTORICAL_MEMORIES, DEMO_EMERGENCY_ROUTES } from '../data/seedData.ts';

export interface MemoryService {
  isLiveHindsight(): boolean;
  getMode(): 'HINDSIGHT_LIVE' | 'DEMO_MOCK';
  getAllMemories(filter?: { zone?: string; location?: string; incident?: string; weather?: string; outcome?: string }): Promise<TrafficMemoryItem[]>;
  recallSimilarEvents(request: AnalyzeRequest): Promise<{
    recalled: TrafficMemoryItem[];
    statsByIntervention: InterventionOutcomeStat[];
    recommendedIntervention: InterventionType;
    confidenceScore: number;
    avgHistoricalDelay: number;
    similarityBasis: string;
  }>;
  retainEvent(memory: Omit<TrafficMemoryItem, 'id' | 'timestamp' | 'source'>): Promise<TrafficMemoryItem>;
  retainOutcome(memoryId: string, outcome: 'Successful' | 'Partially successful' | 'Failed', notes?: string): Promise<TrafficMemoryItem | null>;
  getStats(): Promise<{
    totalMemories: number;
    successfulInterventionsCount: number;
    failedInterventionsCount: number;
    interventionsSuccessRate: number;
    emergencyTripsRecorded: number;
    activeIncidentsCount: number;
    memoryRetainCount: number;
    memoryRecallCount: number;
    memoryMode: 'HINDSIGHT_LIVE' | 'DEMO_MOCK';
    hindsightConnected: boolean;
  }>;
  resetToSeed(): Promise<void>;
}

// In-Memory store that supports dynamic RETAIN and RECALL
class InProcessMemoryAdapter implements MemoryService {
  private memories: TrafficMemoryItem[] = [];
  private retainCount = 0;
  private recallCount = 0;
  private isConnected = false;
  private hindsightUrl?: string;
  private hindsightKey?: string;

  constructor() {
    this.memories = JSON.parse(JSON.stringify(SEED_HISTORICAL_MEMORIES));
    this.hindsightUrl = process.env.HINDSIGHT_URL;
    this.hindsightKey = process.env.HINDSIGHT_API_KEY;

    // Check if real Hindsight credentials exist
    if (this.hindsightUrl && this.hindsightKey && !this.hindsightKey.includes('MY_') && this.hindsightKey.length > 5) {
      this.testHindsightConnection();
    }
  }

  private async testHindsightConnection() {
    try {
      const res = await fetch(`${this.hindsightUrl}/v1/health`, {
        headers: { 'Authorization': `Bearer ${this.hindsightKey}` }
      });
      if (res.ok) {
        this.isConnected = true;
        console.log('[TrafficMemory] Connected to live Hindsight Vectorize service at', this.hindsightUrl);
      }
    } catch {
      this.isConnected = false;
    }
  }

  isLiveHindsight(): boolean {
    return this.isConnected;
  }

  getMode(): 'HINDSIGHT_LIVE' | 'DEMO_MOCK' {
    return this.isConnected ? 'HINDSIGHT_LIVE' : 'DEMO_MOCK';
  }

  async getAllMemories(filter?: { zone?: string; location?: string; incident?: string; weather?: string; outcome?: string }): Promise<TrafficMemoryItem[]> {
    let result = [...this.memories];

    if (filter?.zone && filter.zone !== 'All') {
      result = result.filter(m => m.zone.toLowerCase().includes(filter.zone!.toLowerCase()) || filter.zone!.toLowerCase().includes(m.zone.toLowerCase()));
    }
    if (filter?.location && filter.location !== 'All') {
      result = result.filter(m => m.location.toLowerCase().includes(filter.location!.toLowerCase()));
    }
    if (filter?.incident && filter.incident !== 'All') {
      result = result.filter(m => m.incident === filter.incident);
    }
    if (filter?.weather && filter.weather !== 'All') {
      result = result.filter(m => m.weather === filter.weather);
    }
    if (filter?.outcome && filter.outcome !== 'All') {
      result = result.filter(m => m.outcome === filter.outcome);
    }

    return result.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  async recallSimilarEvents(req: AnalyzeRequest): Promise<{
    recalled: TrafficMemoryItem[];
    statsByIntervention: InterventionOutcomeStat[];
    recommendedIntervention: InterventionType;
    confidenceScore: number;
    avgHistoricalDelay: number;
    similarityBasis: string;
  }> {
    this.recallCount++;

    // Scoring engine based on:
    // 1. Location / Zone similarity (weight 35)
    // 2. Incident Type match (weight 30)
    // 3. Weather match (weight 20)
    // 4. Day / Time peak similarity (weight 15)
    const scored = this.memories.map(item => {
      let score = 0;
      
      const locMatch = req.location && (item.location.toLowerCase().includes(req.location.toLowerCase()) || req.location.toLowerCase().includes(item.location.toLowerCase()));
      const zoneMatch = req.zone && (item.zone.toLowerCase().includes(req.zone.toLowerCase()) || req.zone.toLowerCase().includes(item.zone.toLowerCase()));
      if (locMatch) score += 35;
      else if (zoneMatch) score += 25;

      if (item.incident === req.incident) score += 30;
      if (item.weather === req.weather) score += 20;

      if (item.day === req.day) score += 10;
      if (req.time && item.time) {
        const isEvening1 = req.time.includes('PM');
        const isEvening2 = item.time.includes('PM');
        if (isEvening1 === isEvening2) score += 5;
      }

      if (item.severity === req.severity) score += 5;

      return { item, score };
    });

    // Sort by similarity score descending
    scored.sort((a, b) => b.score - a.score);

    // Pick top 6-8 relevant memories (minimum score >= 35)
    let recalled = scored
      .filter(s => s.score >= 35)
      .slice(0, 8)
      .map(s => s.item);

    // Ensure fallback if very few matches
    if (recalled.length < 3) {
      recalled = scored.slice(0, 6).map(s => s.item);
    }

    // Calculate historical statistics per intervention
    const interventions: InterventionType[] = ['Signal retiming', 'Traffic diversion', 'Manual traffic control', 'Corridor metering'];
    const statsByIntervention: InterventionOutcomeStat[] = interventions.map(interv => {
      const matchingAttempts = recalled.filter(m => m.intervention === interv);
      const totalAttempts = matchingAttempts.length;
      const successCount = matchingAttempts.filter(m => m.outcome === 'Successful').length;
      const partialCount = matchingAttempts.filter(m => m.outcome === 'Partially successful').length;
      const failCount = matchingAttempts.filter(m => m.outcome === 'Failed').length;
      const successRate = totalAttempts > 0 ? Math.round((successCount / totalAttempts) * 100) : 0;

      const totalDelayRed = matchingAttempts.reduce((acc, curr) => acc + Math.max(0, curr.delayBeforeMin - curr.delayAfterMin), 0);
      const avgDelayReductionMin = totalAttempts > 0 ? Number((totalDelayRed / totalAttempts).toFixed(1)) : 0;

      return {
        intervention: interv,
        totalAttempts,
        successCount,
        partialCount,
        failCount,
        successRate,
        avgDelayReductionMin
      };
    }).filter(stat => stat.totalAttempts > 0)
      .sort((a, b) => (b.successRate * 10 + b.totalAttempts) - (a.successRate * 10 + a.totalAttempts));

    // Recommend the highest performing intervention
    let recommendedIntervention: InterventionType = statsByIntervention.length > 0
      ? statsByIntervention[0].intervention
      : 'Signal retiming';

    // If highest has 0% success (e.g. failed in all attempts), pick second or manual
    if (statsByIntervention.length > 1 && statsByIntervention[0].successRate === 0) {
      const alternative = statsByIntervention.find(s => s.successRate > 0);
      if (alternative) {
        recommendedIntervention = alternative.intervention;
      }
    }

    const totalDelays = recalled.reduce((sum, item) => sum + item.delayBeforeMin, 0);
    const avgHistoricalDelay = recalled.length > 0 ? Number((totalDelays / recalled.length).toFixed(1)) : 15.0;

    const topStat = statsByIntervention.find(s => s.intervention === recommendedIntervention);
    const confidenceScore = topStat ? topStat.successRate : 65;

    const similarityBasis = `Matched ${recalled.length} historical events in ${req.location || 'corridor'} during ${req.day} ${req.time} (${req.weather}, ${req.incident})`;

    return {
      recalled,
      statsByIntervention,
      recommendedIntervention,
      confidenceScore,
      avgHistoricalDelay,
      similarityBasis
    };
  }

  async retainEvent(memoryInput: Omit<TrafficMemoryItem, 'id' | 'timestamp' | 'source'>): Promise<TrafficMemoryItem> {
    this.retainCount++;

    const newMemory: TrafficMemoryItem = {
      ...memoryInput,
      id: `mem-live-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString(),
      source: this.isConnected ? 'Hindsight Retained (Live)' : 'TrafficMemory Engine (Retained)'
    };

    // Prepend so newest appears first
    this.memories.unshift(newMemory);

    // If connected to real Hindsight service, dispatch retain payload
    if (this.isConnected && this.hindsightUrl && this.hindsightKey) {
      try {
        await fetch(`${this.hindsightUrl}/v1/memories`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${this.hindsightKey}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            collection: 'hyderabad_traffic',
            content: `${newMemory.location} | ${newMemory.day} ${newMemory.time} | ${newMemory.weather} | ${newMemory.incident} | ${newMemory.intervention} -> ${newMemory.outcome}`,
            metadata: newMemory
          })
        });
      } catch (err) {
        console.warn('[TrafficMemory] Hindsight live retain deferred to local store:', err);
      }
    }

    return newMemory;
  }

  async retainOutcome(memoryId: string, outcome: 'Successful' | 'Partially successful' | 'Failed', notes?: string): Promise<TrafficMemoryItem | null> {
    const existingIndex = this.memories.findIndex(m => m.id === memoryId);
    if (existingIndex >= 0) {
      const existing = this.memories[existingIndex];
      const updated: TrafficMemoryItem = {
        ...existing,
        outcome,
        success: outcome === 'Successful',
        context: notes ? `${existing.context} | Post-eval: ${notes}` : existing.context,
        delayAfterMin: outcome === 'Successful' ? Math.max(5, Math.round(existing.delayBeforeMin * 0.4)) : existing.delayBeforeMin + 3
      };
      this.memories[existingIndex] = updated;
      return updated;
    }
    return null;
  }

  async getStats() {
    const totalMemories = this.memories.length;
    const successfulInterventionsCount = this.memories.filter(m => m.outcome === 'Successful').length;
    const failedInterventionsCount = this.memories.filter(m => m.outcome === 'Failed').length;
    const interventionsSuccessRate = totalMemories > 0 ? Math.round((successfulInterventionsCount / totalMemories) * 100) : 0;
    
    // Calculate total emergency trips from all emergency routes
    let emergencyTripsRecorded = 0;
    Object.values(DEMO_EMERGENCY_ROUTES).forEach(routes => {
      routes.forEach(r => emergencyTripsRecorded += r.historicalTrips);
    });

    return {
      totalMemories,
      successfulInterventionsCount,
      failedInterventionsCount,
      interventionsSuccessRate,
      emergencyTripsRecorded,
      activeIncidentsCount: 5,
      memoryRetainCount: this.retainCount,
      memoryRecallCount: this.recallCount,
      memoryMode: this.getMode(),
      hindsightConnected: this.isConnected
    };
  }

  async resetToSeed() {
    this.memories = JSON.parse(JSON.stringify(SEED_HISTORICAL_MEMORIES));
    this.retainCount = 0;
    this.recallCount = 0;
  }
}

export const memoryService: MemoryService = new InProcessMemoryAdapter();
