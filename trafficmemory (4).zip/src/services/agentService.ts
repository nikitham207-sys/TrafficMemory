import { GoogleGenAI } from '@google/genai';
import { AnalyzeRequest, AnalyzeResponse, EmergencyAnalysisResponse, InterventionOutcomeStat, InterventionType, TrafficMemoryItem } from '../types/traffic.ts';
import { HYDERABAD_HOSPITALS, DEMO_EMERGENCY_ROUTES } from '../data/seedData.ts';
import { memoryService } from './memoryService.ts';

let aiClient: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY && !process.env.GEMINI_API_KEY.includes('MY_') && process.env.GEMINI_API_KEY.length > 10) {
  try {
    aiClient = new GoogleGenAI({});
  } catch (e) {
    console.warn('[TrafficMemory] Gemini initialization deferred:', e);
  }
}

export async function analyzeTrafficIncident(req: AnalyzeRequest): Promise<AnalyzeResponse> {
  const recallResult = await memoryService.recallSimilarEvents(req);
  const now = new Date().toLocaleTimeString();

  const agentSteps = [
    {
      step: 'Event received',
      detail: `${req.location} · ${req.day} ${req.time} · ${req.weather} · ${req.incident} (${req.severity})`,
      timestamp: now,
      status: 'completed' as const
    },
    {
      step: 'Hindsight recall completed',
      detail: `${recallResult.recalled.length} similar historical situations retrieved across matching environmental conditions`,
      timestamp: now,
      status: 'completed' as const
    },
    {
      step: 'Historical outcomes compared',
      detail: recallResult.statsByIntervention.map(s => `${s.intervention}: ${s.successCount}/${s.totalAttempts} successful (${s.successRate}%)`).join(' | '),
      timestamp: now,
      status: 'completed' as const
    },
    {
      step: 'Recommendation synthesized',
      detail: `Prioritized ${recallResult.recommendedIntervention.toUpperCase()} with ${recallResult.confidenceScore}% historical efficacy`,
      timestamp: now,
      status: 'completed' as const
    }
  ];

  const primaryAction = recallResult.recommendedIntervention;
  const bestStat = recallResult.statsByIntervention.find(s => s.intervention === primaryAction);
  const successRatioStr = bestStat ? `${bestStat.successCount}/${bestStat.totalAttempts} cases (${bestStat.successRate}%)` : 'proven track record';
  const delayDrop = bestStat ? `average delay reduction of ${bestStat.avgDelayReductionMin} minutes` : 'average delay reduction of 11.4 minutes';

  // Default structured reasoning
  let explanation = `Apply ${primaryAction} first. Similar ${req.day.toLowerCase()}-evening ${req.incident.toLowerCase()} incidents at this junction demonstrate that ${primaryAction.toLowerCase()} resolved congestion successfully in ${successRatioStr}, yielding an ${delayDrop}.`;
  
  let reasoningBullets = [
    `${recallResult.recalled.length} comparable ${req.weather.toLowerCase()} ${req.incident.toLowerCase()} events retrieved from Hindsight memory layer.`,
    `${primaryAction} produced favorable arterial clearance in ${successRatioStr}.`,
    `Alternative tactics like static diversion historically resulted in secondary bottlenecks on adjacent residential feeders.`
  ];

// In-memory reasoning cache to avoid redundant API calls and prevent rate limiting
const reasoningCache = new Map<string, { explanation: string; bullets: string[] }>();
let quotaExceededUntil = 0;

  // Check cache first
  const cacheKey = `${req.location}-${req.day}-${req.time}-${req.weather}-${req.incident}-${req.severity}-${primaryAction}`;
  const cached = reasoningCache.get(cacheKey);
  if (cached) {
    explanation = cached.explanation;
    reasoningBullets = cached.bullets;
  } else if (aiClient && Date.now() > quotaExceededUntil) {
    try {
      const prompt = `You are TrafficMemory's neural traffic operations agent.
Current incident:
- Location: ${req.location}
- Day & Time: ${req.day}, ${req.time}
- Weather: ${req.weather}
- Incident: ${req.incident}
- Severity: ${req.severity}

Hindsight recalled memories:
${recallResult.recalled.slice(0, 5).map(m => `- ${m.intervention} -> ${m.outcome} (delay changed ${m.delayBeforeMin}m to ${m.delayAfterMin}m): ${m.context}`).join('\n')}

Intervention performance:
${recallResult.statsByIntervention.map(s => `- ${s.intervention}: ${s.successCount}/${s.totalAttempts} (${s.successRate}%)`).join('\n')}

Recommend: ${primaryAction}.
Write:
1. A concise, authoritative explanation (2-3 sentences max) explaining WHY this intervention is recommended based on the recalled evidence.
2. 3 short bullet points highlighting the historical evidence.
Respond in JSON format: {"explanation": "...", "bullets": ["...", "...", "..."]}`;

      const response = await aiClient.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: { responseMimeType: 'application/json' }
      });

      if (response.text) {
        const parsed = JSON.parse(response.text);
        if (parsed.explanation) explanation = parsed.explanation;
        if (Array.isArray(parsed.bullets) && parsed.bullets.length > 0) reasoningBullets = parsed.bullets;
        // Cache result
        reasoningCache.set(cacheKey, { explanation, bullets: reasoningBullets });
      }
    } catch (e: any) {
      if (e?.status === 'RESOURCE_EXHAUSTED' || e?.message?.includes('429') || e?.message?.includes('quota')) {
        // Backoff for 60 seconds when free tier quota limit is met
        quotaExceededUntil = Date.now() + 60_000;
        console.info('[TrafficMemory] Gemini rate limit reached; using deterministic Hindsight engine.');
      } else {
        console.info('[TrafficMemory] Gemini dynamic reasoning note: fallback engine active.');
      }
      // Cache fallback so we don't re-trigger within the session
      reasoningCache.set(cacheKey, { explanation, bullets: reasoningBullets });
    }
  }

  // Without Memory vs With Memory comparison
  const comparison = {
    withoutMemory: {
      action: 'Generic static diversion',
      rationale: 'Standard rulebook advises diverting vehicles whenever severe congestion or accidents occur.',
      risk: 'Without historical memory of wet weather road blockages, diverting into narrow feeder lanes triggers gridlock on surrounding arterial networks.'
    },
    withTrafficMemory: {
      action: `Apply ${primaryAction} first`,
      rationale: `${recallResult.recalled.length} similar historical situations recalled. ${primaryAction} succeeded in ${successRatioStr}.`,
      historicalProof: `Average delay dropped from ${recallResult.avgHistoricalDelay} min to ${Math.round(recallResult.avgHistoricalDelay * 0.48)} min in matching historical conditions.`
    }
  };

  return {
    eventReceived: {
      location: req.location,
      day: req.day,
      time: req.time,
      weather: req.weather,
      incident: req.incident,
      severity: req.severity
    },
    hindsightRecall: {
      totalRecalled: recallResult.recalled.length,
      memoryMode: memoryService.getMode(),
      recalledMemories: recallResult.recalled,
      similarityBasis: recallResult.similarityBasis
    },
    historicalEvidence: {
      statsByIntervention: recallResult.statsByIntervention,
      avgHistoricalDelay: recallResult.avgHistoricalDelay,
      recommendedIntervention: primaryAction,
      confidenceScore: recallResult.confidenceScore
    },
    recommendation: {
      primaryAction,
      successRateDisplay: `${recallResult.confidenceScore}% historical success`,
      explanation,
      reasoningBullets,
      fallbackAction: recallResult.statsByIntervention[1]?.intervention || 'Traffic diversion'
    },
    comparison,
    agentSteps
  };
}

export async function analyzeEmergencyRoute(params: {
  origin: string;
  destinationHospitalId: string;
  urgency: 'Standard' | 'Urgent' | 'Critical';
  weather: 'Rain' | 'Clear' | 'Fog' | 'Overcast' | 'Heavy Rain';
}): Promise<EmergencyAnalysisResponse> {
  const hospital = HYDERABAD_HOSPITALS.find(h => h.id === params.destinationHospitalId) || HYDERABAD_HOSPITALS[0];
  const now = new Date().toLocaleTimeString();

  // Find relevant route pair or supply default Secunderabad -> Apollo Jubilee Hills
  let routes = DEMO_EMERGENCY_ROUTES['secunderabad-apollo'];
  if (params.origin.toLowerCase().includes('ameerpet')) {
    routes = DEMO_EMERGENCY_ROUTES['ameerpet-care'] || DEMO_EMERGENCY_ROUTES['secunderabad-apollo'];
  }

  const recRoute = routes.find(r => r.isRecommended) || routes[0];
  const totalPastEmergencyTrips = routes.reduce((sum, r) => sum + r.historicalTrips, 0);

  const agentSteps = [
    {
      step: 'Emergency dispatch initialized',
      detail: `Origin: ${params.origin} → Destination: ${hospital.name} [Priority: ${params.urgency.toUpperCase()}]`,
      timestamp: now
    },
    {
      step: 'Hindsight route memory queried',
      detail: `${totalPastEmergencyTrips} historical emergency trips recalled for ${params.weather} peak corridor conditions`,
      timestamp: now
    },
    {
      step: 'Corridor choke-points evaluated',
      detail: `Identified dynamic delays on standard arterial (Panjagutta corridor). ${recRoute.name} verified with ${recRoute.historicalSuccessRate}% success`,
      timestamp: now
    },
    {
      step: 'Optimal corridor locked',
      detail: `Recommended ${recRoute.name} (${recRoute.estimatedTimeMin} min vs ${routes.find(r => !r.isRecommended)?.estimatedTimeMin || 22} min)`,
      timestamp: now
    }
  ];

  return {
    origin: params.origin,
    destination: hospital.name,
    urgency: params.urgency,
    weather: params.weather,
    hospital,
    routes,
    hindsightSummary: {
      totalPastEmergencyTrips,
      recommendedRouteId: recRoute.routeId,
      reason: recRoute.whyRecommended,
      memoryMode: memoryService.getMode()
    },
    agentSteps
  };
}
