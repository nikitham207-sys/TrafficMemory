import { 
  AnalyzeRequest, 
  AnalyzeResponse, 
  EmergencyAnalysisResponse, 
  HospitalInfo, 
  IncidentMarker, 
  RecordOutcomeRequest, 
  SystemStats, 
  TrafficCorridor, 
  TrafficMemoryItem, 
  ZoneInfo 
} from '../types/traffic.ts';

const API_BASE = '/api';

export const api = {
  async getHealth() {
    const res = await fetch(`${API_BASE}/health`);
    if (!res.ok) throw new Error('Failed to fetch system health');
    return res.json();
  },

  async getStats(): Promise<SystemStats> {
    const res = await fetch(`${API_BASE}/stats`);
    if (!res.ok) throw new Error('Failed to fetch statistics');
    return res.json();
  },

  async getZones(): Promise<ZoneInfo[]> {
    const res = await fetch(`${API_BASE}/zones`);
    if (!res.ok) throw new Error('Failed to fetch zones');
    return res.json();
  },

  async getHospitals(): Promise<HospitalInfo[]> {
    const res = await fetch(`${API_BASE}/hospitals`);
    if (!res.ok) throw new Error('Failed to fetch hospitals');
    return res.json();
  },

  async getIncidents(): Promise<IncidentMarker[]> {
    const res = await fetch(`${API_BASE}/incidents`);
    if (!res.ok) throw new Error('Failed to fetch incidents');
    return res.json();
  },

  async getCorridors(): Promise<TrafficCorridor[]> {
    const res = await fetch(`${API_BASE}/corridors`);
    if (!res.ok) throw new Error('Failed to fetch corridors');
    return res.json();
  },

  async getMemories(filter?: { zone?: string; location?: string; incident?: string; weather?: string; outcome?: string }): Promise<{
    total: number;
    memoryMode: 'HINDSIGHT_LIVE' | 'DEMO_MOCK';
    memories: TrafficMemoryItem[];
  }> {
    const params = new URLSearchParams();
    if (filter?.zone) params.append('zone', filter.zone);
    if (filter?.location) params.append('location', filter.location);
    if (filter?.incident) params.append('incident', filter.incident);
    if (filter?.weather) params.append('weather', filter.weather);
    if (filter?.outcome) params.append('outcome', filter.outcome);

    const res = await fetch(`${API_BASE}/memories?${params.toString()}`);
    if (!res.ok) throw new Error('Failed to fetch memories');
    return res.json();
  },

  async analyze(data: AnalyzeRequest): Promise<AnalyzeResponse> {
    const res = await fetch(`${API_BASE}/analyze`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Analysis failed' }));
      throw new Error(err.error || 'Failed to analyze traffic situation');
    }
    return res.json();
  },

  async emergency(data: {
    origin: string;
    destinationHospitalId: string;
    urgency?: 'Standard' | 'Urgent' | 'Critical';
    weather?: string;
  }): Promise<EmergencyAnalysisResponse> {
    const res = await fetch(`${API_BASE}/emergency`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Emergency routing failed' }));
      throw new Error(err.error || 'Failed to calculate emergency route');
    }
    return res.json();
  },

  async recordOutcome(data: RecordOutcomeRequest): Promise<{
    success: boolean;
    message: string;
    retainedMemory: TrafficMemoryItem;
    updatedStats: SystemStats;
  }> {
    const res = await fetch(`${API_BASE}/outcomes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Outcome saving failed' }));
      throw new Error(err.error || 'Failed to persist outcome');
    }
    return res.json();
  },

  async resetMemories(): Promise<{ success: boolean; stats: SystemStats }> {
    const res = await fetch(`${API_BASE}/reset-memories`, { method: 'POST' });
    if (!res.ok) throw new Error('Failed to reset memories');
    return res.json();
  }
};
